var P_Tag = [];
var P_Par = [];
var P_Toc = [];
P_Tag[1]='<p class="c3">&nbsp;*</p>*';
P_Tag[2]='<p class="b2">&nbsp;*</p>*';
P_Tag[3]='<p class="c4">&nbsp;*</p>*';
P_Tag[4]='<p class="c3">&nbsp;*</p>*';
P_Tag[5]='<p class="g5">&nbsp;*<span class="font10" id="M1207_1">[Pg.1]</span></p>*';
P_Tag[6]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[7]='<p class="c3">&nbsp;*</p>*';
P_Tag[8]='<p class="g5">&nbsp;*</p>*';
P_Tag[9]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[10]='<p class="c3">&nbsp;*</p>*';
P_Tag[11]='<p class="g5">&nbsp;*</p>*';
P_Tag[12]='<p class="g5">&nbsp;*</p>*';
P_Tag[13]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[14]='<p class="b1">&nbsp;*</p>*';
P_Tag[15]='<p class="sc">&nbsp;*</p>*';
P_Tag[16]='<p class="b1">&nbsp;*</p>*';
P_Tag[17]='<p class="b1">&nbsp;*<span class="font10" id="M1207_2">[Pg.2]</span></p>*';
P_Tag[18]='<p class="b1">&nbsp;*</p>*';
P_Tag[19]='<p class="c3">&nbsp;*</p>*';
P_Tag[20]='<p class="sc">&nbsp;*</p>*';
P_Tag[21]='<p class="c3">&nbsp;*</p>*';
P_Tag[22]='<p class="c3">&nbsp;*</p>*';
P_Tag[23]='<p class="b1">&nbsp;*</p>*';
P_Tag[24]='<p class="c3">&nbsp;*</p>*';
P_Tag[25]='<p class="b1">&nbsp;*</p>*';
P_Tag[26]='<p class="c3">&nbsp;*</p>*';
P_Tag[27]='<p class="b1">&nbsp;*<span class="font10" id="M1207_3">[Pg.3]</span></p>*';
P_Tag[28]='<p class="c3">&nbsp;*</p>*';
P_Tag[29]='<p class="b1">&nbsp;*</p>*';
P_Tag[30]='<p class="b1">&nbsp;*</p>*';
P_Tag[31]='<p class="c3">&nbsp;*</p>*';
P_Tag[32]='<p class="sc">&nbsp;*</p>*';
P_Tag[33]='<p class="c3">&nbsp;*</p>*';
P_Tag[34]='<p class="c3">&nbsp;*</p>*';
P_Tag[35]='<p class="c3">&nbsp;*</p>*';
P_Tag[36]='<p class="b1">&nbsp;*</p>*';
P_Tag[37]='<p class="c3">&nbsp;*</p>*';
P_Tag[38]='<p class="b1">&nbsp;*</p>*';
P_Tag[39]='<p class="c3">&nbsp;*</p>*';
P_Tag[40]='<p class="b1">&nbsp;*<span class="font10" id="M1207_4">[Pg.4]</span></p>*';
P_Tag[41]='<p class="c3">&nbsp;*</p>*';
P_Tag[42]='<p class="b1">&nbsp;*</p>*';
P_Tag[43]='<p class="c3">&nbsp;*</p>*';
P_Tag[44]='<p class="b1">&nbsp;*</p>*';
P_Tag[45]='<p class="c3">&nbsp;*</p>*';
P_Tag[46]='<p class="b1">&nbsp;*</p>*';
P_Tag[47]='<p class="c3">&nbsp;*</p>*';
P_Tag[48]='<p class="b1">&nbsp;*</p>*';
P_Tag[49]='<p class="c3">&nbsp;*</p>*';
P_Tag[50]='<p class="b1">&nbsp;*<span class="font10" id="M1207_5">[Pg.5]</span></p>*';
P_Tag[51]='<p class="c3">&nbsp;*</p>*';
P_Tag[52]='<p class="b1">&nbsp;*</p>*';
P_Tag[53]='<p class="c3">&nbsp;*</p>*';
P_Tag[54]='<p class="b1">&nbsp;*</p>*';
P_Tag[55]='<p class="c3">&nbsp;*</p>*';
P_Tag[56]='<p class="b1">&nbsp;*<span class="font10" id="M1207_6">[Pg.6]</span></p>*';
P_Tag[57]='<p class="c3">&nbsp;*</p>*';
P_Tag[58]='<p class="b1">&nbsp;*</p>*';
P_Tag[59]='<p class="c3">&nbsp;*</p>*';
P_Tag[60]='<p class="b1">&nbsp;*<span class="font10" id="M1207_7">[Pg.7]</span></p>*';
P_Tag[61]='<p class="b1">&nbsp;*</p>*';
P_Tag[62]='<p class="c3">&nbsp;*</p>*';
P_Tag[63]='<p class="sc">&nbsp;*</p>*';
P_Tag[64]='<p class="c3">&nbsp;*</p>*';
P_Tag[65]='<p class="c3">&nbsp;*</p>*';
P_Tag[66]='<p class="c3">&nbsp;*</p>*';
P_Tag[67]='<p class="b1">&nbsp;*<span class="font10" id="M1207_8">[Pg.8]</span></p>*';
P_Tag[68]='<p class="c3">&nbsp;*</p>*';
P_Tag[69]='<p class="b1">&nbsp;*</p>*';
P_Tag[70]='<p class="b1">&nbsp;*</p>*';
P_Tag[71]='<p class="c3">&nbsp;*</p>*';
P_Tag[72]='<p class="sc">&nbsp;*</p>*';
P_Tag[73]='<p class="c3">&nbsp;*</p>*';
P_Tag[74]='<p class="c3">&nbsp;*</p>*';
P_Tag[75]='<p class="c3">&nbsp;*</p>*';
P_Tag[76]='<p class="b1">&nbsp;*</p>*';
P_Tag[77]='<p class="c3">&nbsp;*</p>*';
P_Tag[78]='<p class="b1">&nbsp;*</p>*';
P_Tag[79]='<p class="c3">&nbsp;*</p>*';
P_Tag[80]='<p class="b1">&nbsp;*<span class="font10" id="M1207_9">[Pg.9]</span></p>*';
P_Tag[81]='<p class="c3">&nbsp;*</p>*';
P_Tag[82]='<p class="b1">&nbsp;*</p>*';
P_Tag[83]='<p class="c3">&nbsp;*</p>*';
P_Tag[84]='<p class="b1">&nbsp;*</p>*';
P_Tag[85]='<p class="c3">&nbsp;*</p>*';
P_Tag[86]='<p class="b1">&nbsp;*</p>*';
P_Tag[87]='<p class="c3">&nbsp;*</p>*';
P_Tag[88]='<p class="b1">&nbsp;*</p>*';
P_Tag[89]='<p class="c3">&nbsp;*</p>*';
P_Tag[90]='<p class="b1">&nbsp;*</p>*';
P_Tag[91]='<p class="c3">&nbsp;*</p>*';
P_Tag[92]='<p class="b1">&nbsp;*<span class="font10" id="M1207_10">[Pg.10]</span></p>*';
P_Tag[93]='<p class="c3">&nbsp;*</p>*';
P_Tag[94]='<p class="b1">&nbsp;*<span class="font10" id="M1207_11">[Pg.11]</span></p>*';
P_Tag[95]='<p class="c3">&nbsp;*</p>*';
P_Tag[96]='<p class="c3">&nbsp;*</p>*';
P_Tag[97]='<p class="b1">&nbsp;*</p>*';
P_Tag[98]='<p class="c3">&nbsp;*</p>*';
P_Tag[99]='<p class="b1">&nbsp;*</p>*';
P_Tag[100]='<p class="c3">&nbsp;*</p>*';
P_Tag[101]='<p class="b1">&nbsp;*</p>*';
P_Tag[102]='<p class="c3">&nbsp;*</p>*';
P_Tag[103]='<p class="b1">&nbsp;*</p>*';
P_Tag[104]='<p class="c3">&nbsp;*</p>*';
P_Tag[105]='<p class="b1">&nbsp;*<span class="font10" id="M1207_12">[Pg.12]</span></p>*';
P_Tag[106]='<p class="c3">&nbsp;*</p>*';
P_Tag[107]='<p class="b1">&nbsp;*</p>*';
P_Tag[108]='<p class="c3">&nbsp;*</p>*';
P_Tag[109]='<p class="b1">&nbsp;*</p>*';
P_Tag[110]='<p class="c3">&nbsp;*</p>*';
P_Tag[111]='<p class="b1">&nbsp;*</p>*';
P_Tag[112]='<p class="c3">&nbsp;*</p>*';
P_Tag[113]='<p class="b1">&nbsp;*</p>*';
P_Tag[114]='<p class="c3">&nbsp;*</p>*';
P_Tag[115]='<p class="b1">&nbsp;*</p>*';
P_Tag[116]='<p class="c3">&nbsp;*</p>*';
P_Tag[117]='<p class="c3">&nbsp;*</p>*';
P_Tag[118]='<p class="b1">&nbsp;*</p>*';
P_Tag[119]='<p class="c3">&nbsp;*</p>*';
P_Tag[120]='<p class="b1">&nbsp;*<span class="font10" id="M1207_13">[Pg.13]</span></p>*';
P_Tag[121]='<p class="c3">&nbsp;*</p>*';
P_Tag[122]='<p class="b1">&nbsp;*</p>*';
P_Tag[123]='<p class="c3">&nbsp;*</p>*';
P_Tag[124]='<p class="b1">&nbsp;*</p>*';
P_Tag[125]='<p class="c3">&nbsp;*</p>*';
P_Tag[126]='<p class="b1">&nbsp;*</p>*';
P_Tag[127]='<p class="c3">&nbsp;*</p>*';
P_Tag[128]='<p class="b1">&nbsp;*</p>*';
P_Tag[129]='<p class="c3">&nbsp;*</p>*';
P_Tag[130]='<p class="b1">&nbsp;*</p>*';
P_Tag[131]='<p class="c3">&nbsp;*</p>*';
P_Tag[132]='<p class="b1">&nbsp;*<span class="font10" id="M1207_14">[Pg.14]</span></p>*';
P_Tag[133]='<p class="c3">&nbsp;*</p>*';
P_Tag[134]='<p class="b1">&nbsp;*</p>*';
P_Tag[135]='<p class="c3">&nbsp;*</p>*';
P_Tag[136]='<p class="b1">&nbsp;*</p>*';
P_Tag[137]='<p class="c3">&nbsp;*</p>*';
P_Tag[138]='<p class="b1">&nbsp;*</p>*';
P_Tag[139]='<p class="c3">&nbsp;*</p>*';
P_Tag[140]='<p class="sc">&nbsp;*</p>*';
P_Tag[141]='<p class="c3">&nbsp;*</p>*';
P_Tag[142]='<p class="c3">&nbsp;*</p>*';
P_Tag[143]='<p class="c3">&nbsp;*</p>*';
P_Tag[144]='<p class="b1">&nbsp;*</p>*';
P_Tag[145]='<p class="c3">&nbsp;*</p>*';
P_Tag[146]='<p class="b1">&nbsp;*</p>*';
P_Tag[147]='<p class="c3">&nbsp;*</p>*';
P_Tag[148]='<p class="b1">&nbsp;*<span class="font10" id="M1207_15">[Pg.15]</span></p>*';
P_Tag[149]='<p class="c3">&nbsp;*</p>*';
P_Tag[150]='<p class="b1">&nbsp;*</p>*';
P_Tag[151]='<p class="c3">&nbsp;*</p>*';
P_Tag[152]='<p class="b1">&nbsp;*</p>*';
P_Tag[153]='<p class="c3">&nbsp;*</p>*';
P_Tag[154]='<p class="b1">&nbsp;*</p>*';
P_Tag[155]='<p class="c3">&nbsp;*</p>*';
P_Tag[156]='<p class="b1">&nbsp;*</p>*';
P_Tag[157]='<p class="c3">&nbsp;*</p>*';
P_Tag[158]='<p class="b1">&nbsp;*</p>*';
P_Tag[159]='<p class="c3">&nbsp;*</p>*';
P_Tag[160]='<p class="b1">&nbsp;*</p>*';
P_Tag[161]='<p class="c3">&nbsp;*</p>*';
P_Tag[162]='<p class="b1">&nbsp;*</p>*';
P_Tag[163]='<p class="c3">&nbsp;*</p>*';
P_Tag[164]='<p class="c3">&nbsp;*</p>*';
P_Tag[165]='<p class="b1">&nbsp;*</p>*';
P_Tag[166]='<p class="c3">&nbsp;*</p>*';
P_Tag[167]='<p class="b1">&nbsp;*</p>*';
P_Tag[168]='<p class="c3">&nbsp;*</p>*';
P_Tag[169]='<p class="b1">&nbsp;*<span class="font10" id="M1207_16">[Pg.16]</span></p>*';
P_Tag[170]='<p class="c3">&nbsp;*</p>*';
P_Tag[171]='<p class="b1">&nbsp;*</p>*';
P_Tag[172]='<p class="c3">&nbsp;*</p>*';
P_Tag[173]='<p class="b1">&nbsp;*</p>*';
P_Tag[174]='<p class="c3">&nbsp;*</p>*';
P_Tag[175]='<p class="b1">&nbsp;*</p>*';
P_Tag[176]='<p class="c3">&nbsp;*</p>*';
P_Tag[177]='<p class="b1">&nbsp;*</p>*';
P_Tag[178]='<p class="c3">&nbsp;*</p>*';
P_Tag[179]='<p class="b1">&nbsp;*</p>*';
P_Tag[180]='<p class="c3">&nbsp;*</p>*';
P_Tag[181]='<p class="b1">&nbsp;*</p>*';
P_Tag[182]='<p class="c3">&nbsp;*</p>*';
P_Tag[183]='<p class="b1">&nbsp;*</p>*';
P_Tag[184]='<p class="c3">&nbsp;*</p>*';
P_Tag[185]='<p class="c3">&nbsp;*</p>*';
P_Tag[186]='<p class="b1">&nbsp;*<span class="font10" id="M1207_17">[Pg.17]</span></p>*';
P_Tag[187]='<p class="c3">&nbsp;*</p>*';
P_Tag[188]='<p class="b1">&nbsp;*</p>*';
P_Tag[189]='<p class="c3">&nbsp;*</p>*';
P_Tag[190]='<p class="b1">&nbsp;*</p>*';
P_Tag[191]='<p class="c3">&nbsp;*</p>*';
P_Tag[192]='<p class="b1">&nbsp;*</p>*';
P_Tag[193]='<p class="c3">&nbsp;*</p>*';
P_Tag[194]='<p class="b1">&nbsp;*</p>*';
P_Tag[195]='<p class="c3">&nbsp;*</p>*';
P_Tag[196]='<p class="b1">&nbsp;*</p>*';
P_Tag[197]='<p class="c3">&nbsp;*</p>*';
P_Tag[198]='<p class="b1">&nbsp;*</p>*';
P_Tag[199]='<p class="c3">&nbsp;*</p>*';
P_Tag[200]='<p class="b1">&nbsp;*</p>*';
P_Tag[201]='<p class="c3">&nbsp;*</p>*';
P_Tag[202]='<p class="b1">&nbsp;*<span class="font10" id="M1207_18">[Pg.18]</span></p>*';
P_Tag[203]='<p class="c3">&nbsp;*</p>*';
P_Tag[204]='<p class="b1">&nbsp;*</p>*';
P_Tag[205]='<p class="c3">&nbsp;*</p>*';
P_Tag[206]='<p class="c3">&nbsp;*</p>*';
P_Tag[207]='<p class="b1">&nbsp;*</p>*';
P_Tag[208]='<p class="c3">&nbsp;*</p>*';
P_Tag[209]='<p class="b1">&nbsp;*</p>*';
P_Tag[210]='<p class="c3">&nbsp;*</p>*';
P_Tag[211]='<p class="b1">&nbsp;*</p>*';
P_Tag[212]='<p class="c3">&nbsp;*</p>*';
P_Tag[213]='<p class="b1">&nbsp;*</p>*';
P_Tag[214]='<p class="c3">&nbsp;*</p>*';
P_Tag[215]='<p class="b1">&nbsp;*</p>*';
P_Tag[216]='<p class="c3">&nbsp;*</p>*';
P_Tag[217]='<p class="b1">&nbsp;*<span class="font10" id="M1207_19">[Pg.19]</span></p>*';
P_Tag[218]='<p class="c3">&nbsp;*</p>*';
P_Tag[219]='<p class="b1">&nbsp;*</p>*';
P_Tag[220]='<p class="c3">&nbsp;*</p>*';
P_Tag[221]='<p class="b1">&nbsp;*</p>*';
P_Tag[222]='<p class="c3">&nbsp;*</p>*';
P_Tag[223]='<p class="b1">&nbsp;*</p>*';
P_Tag[224]='<p class="c3">&nbsp;*</p>*';
P_Tag[225]='<p class="b1">&nbsp;*</p>*';
P_Tag[226]='<p class="c3">&nbsp;*</p>*';
P_Tag[227]='<p class="c3">&nbsp;*</p>*';
P_Tag[228]='<p class="b1">&nbsp;*</p>*';
P_Tag[229]='<p class="c3">&nbsp;*</p>*';
P_Tag[230]='<p class="b1">&nbsp;*</p>*';
P_Tag[231]='<p class="c3">&nbsp;*</p>*';
P_Tag[232]='<p class="b1">&nbsp;*<span class="font10" id="M1207_20">[Pg.20]</span></p>*';
P_Tag[233]='<p class="c3">&nbsp;*</p>*';
P_Tag[234]='<p class="b1">&nbsp;*</p>*';
P_Tag[235]='<p class="c3">&nbsp;*</p>*';
P_Tag[236]='<p class="b1">&nbsp;*</p>*';
P_Tag[237]='<p class="c3">&nbsp;*</p>*';
P_Tag[238]='<p class="b1">&nbsp;*</p>*';
P_Tag[239]='<p class="c3">&nbsp;*</p>*';
P_Tag[240]='<p class="b1">&nbsp;*</p>*';
P_Tag[241]='<p class="c3">&nbsp;*</p>*';
P_Tag[242]='<p class="b1">&nbsp;*</p>*';
P_Tag[243]='<p class="c3">&nbsp;*</p>*';
P_Tag[244]='<p class="b1">&nbsp;*</p>*';
P_Tag[245]='<p class="c3">&nbsp;*</p>*';
P_Tag[246]='<p class="b1">&nbsp;*</p>*';
P_Tag[247]='<p class="c3">&nbsp;*</p>*';
P_Tag[248]='<p class="c3">&nbsp;*</p>*';
P_Tag[249]='<p class="b1">&nbsp;*<span class="font10" id="M1207_21">[Pg.21]</span></p>*';
P_Tag[250]='<p class="c3">&nbsp;*</p>*';
P_Tag[251]='<p class="b1">&nbsp;*</p>*';
P_Tag[252]='<p class="c3">&nbsp;*</p>*';
P_Tag[253]='<p class="b1">&nbsp;*</p>*';
P_Tag[254]='<p class="c3">&nbsp;*</p>*';
P_Tag[255]='<p class="b1">&nbsp;*</p>*';
P_Tag[256]='<p class="c3">&nbsp;*</p>*';
P_Tag[257]='<p class="b1">&nbsp;*</p>*';
P_Tag[258]='<p class="c3">&nbsp;*</p>*';
P_Tag[259]='<p class="b1">&nbsp;*</p>*';
P_Tag[260]='<p class="c3">&nbsp;*</p>*';
P_Tag[261]='<p class="b1">&nbsp;*</p>*';
P_Tag[262]='<p class="c3">&nbsp;*</p>*';
P_Tag[263]='<p class="b1">&nbsp;*</p>*';
P_Tag[264]='<p class="c3">&nbsp;*</p>*';
P_Tag[265]='<p class="b1">&nbsp;*</p>*';
P_Tag[266]='<p class="c3">&nbsp;*</p>*';
P_Tag[267]='<p class="b1">&nbsp;*<span class="font10" id="M1207_22">[Pg.22]</span></p>*';
P_Tag[268]='<p class="c3">&nbsp;*</p>*';
P_Tag[269]='<p class="c3">&nbsp;*</p>*';
P_Tag[270]='<p class="b1">&nbsp;*</p>*';
P_Tag[271]='<p class="c3">&nbsp;*</p>*';
P_Tag[272]='<p class="b1">&nbsp;*</p>*';
P_Tag[273]='<p class="c3">&nbsp;*</p>*';
P_Tag[274]='<p class="b1">&nbsp;*</p>*';
P_Tag[275]='<p class="c3">&nbsp;*</p>*';
P_Tag[276]='<p class="b1">&nbsp;*</p>*';
P_Tag[277]='<p class="c3">&nbsp;*</p>*';
P_Tag[278]='<p class="b1">&nbsp;*</p>*';
P_Tag[279]='<p class="c3">&nbsp;*</p>*';
P_Tag[280]='<p class="b1">&nbsp;*</p>*';
P_Tag[281]='<p class="c3">&nbsp;*</p>*';
P_Tag[282]='<p class="b1">&nbsp;*</p>*';
P_Tag[283]='<p class="c3">&nbsp;*</p>*';
P_Tag[284]='<p class="b1">&nbsp;*<span class="font10" id="M1207_23">[Pg.23]</span></p>*';
P_Tag[285]='<p class="c3">&nbsp;*</p>*';
P_Tag[286]='<p class="b1">&nbsp;*</p>*';
P_Tag[287]='<p class="c3">&nbsp;*</p>*';
P_Tag[288]='<p class="b1">&nbsp;*</p>*';
P_Tag[289]='<p class="c3">&nbsp;*</p>*';
P_Tag[290]='<p class="c3">&nbsp;*</p>*';
P_Tag[291]='<p class="b1">&nbsp;*<span class="font10" id="M1207_24">[Pg.24]</span></p>*';
P_Tag[292]='<p class="c3">&nbsp;*</p>*';
P_Tag[293]='<p class="b1">&nbsp;*</p>*';
P_Tag[294]='<p class="c3">&nbsp;*</p>*';
P_Tag[295]='<p class="b1">&nbsp;*</p>*';
P_Tag[296]='<p class="c3">&nbsp;*</p>*';
P_Tag[297]='<p class="b1">&nbsp;*</p>*';
P_Tag[298]='<p class="c3">&nbsp;*</p>*';
P_Tag[299]='<p class="b1">&nbsp;*</p>*';
P_Tag[300]='<p class="c3">&nbsp;*</p>*';
P_Tag[301]='<p class="b1">&nbsp;*</p>*';
P_Tag[302]='<p class="c3">&nbsp;*</p>*';
P_Tag[303]='<p class="b1">&nbsp;*<span class="font10" id="M1207_25">[Pg.25]</span></p>*';
P_Tag[304]='<p class="c3">&nbsp;*</p>*';
P_Tag[305]='<p class="b1">&nbsp;*</p>*';
P_Tag[306]='<p class="c3">&nbsp;*</p>*';
P_Tag[307]='<p class="b1">&nbsp;*</p>*';
P_Tag[308]='<p class="c3">&nbsp;*</p>*';
P_Tag[309]='<p class="b1">&nbsp;*</p>*';
P_Tag[310]='<p class="c3">&nbsp;*</p>*';
P_Tag[311]='<p class="b1">&nbsp;*</p>*';
P_Tag[312]='<p class="c3">&nbsp;*</p>*';
P_Tag[313]='<p class="b1">&nbsp;*</p>*';
P_Tag[314]='<p class="c3">&nbsp;*</p>*';
P_Tag[315]='<p class="c3">&nbsp;*</p>*';
P_Tag[316]='<p class="b1">&nbsp;*</p>*';
P_Tag[317]='<p class="c3">&nbsp;*</p>*';
P_Tag[318]='<p class="b1">&nbsp;*<span class="font10" id="M1207_26">[Pg.26]</span></p>*';
P_Tag[319]='<p class="c3">&nbsp;*</p>*';
P_Tag[320]='<p class="b1">&nbsp;*</p>*';
P_Tag[321]='<p class="c3">&nbsp;*</p>*';
P_Tag[322]='<p class="b1">&nbsp;*</p>*';
P_Tag[323]='<p class="c3">&nbsp;*</p>*';
P_Tag[324]='<p class="b1">&nbsp;*</p>*';
P_Tag[325]='<p class="c3">&nbsp;*</p>*';
P_Tag[326]='<p class="b1">&nbsp;*</p>*';
P_Tag[327]='<p class="c3">&nbsp;*</p>*';
P_Tag[328]='<p class="b1">&nbsp;*</p>*';
P_Tag[329]='<p class="c3">&nbsp;*</p>*';
P_Tag[330]='<p class="b1">&nbsp;*</p>*';
P_Tag[331]='<p class="c3">&nbsp;*</p>*';
P_Tag[332]='<p class="b1">&nbsp;*<span class="font10" id="M1207_27">[Pg.27]</span></p>*';
P_Tag[333]='<p class="c3">&nbsp;*</p>*';
P_Tag[334]='<p class="b1">&nbsp;*</p>*';
P_Tag[335]='<p class="c3">&nbsp;*</p>*';
P_Tag[336]='<p class="b1">&nbsp;*</p>*';
P_Tag[337]='<p class="c3">&nbsp;*</p>*';
P_Tag[338]='<p class="sc">&nbsp;*</p>*';
P_Tag[339]='<p class="c3">&nbsp;*</p>*';
P_Tag[340]='<p class="c3">&nbsp;*</p>*';
P_Tag[341]='<p class="c3">&nbsp;*</p>*';
P_Tag[342]='<p class="b1">&nbsp;*</p>*';
P_Tag[343]='<p class="c3">&nbsp;*</p>*';
P_Tag[344]='<p class="b1">&nbsp;*<span class="font10" id="M1207_28">[Pg.28]</span></p>*';
P_Tag[345]='<p class="c3">&nbsp;*</p>*';
P_Tag[346]='<p class="b1">&nbsp;*</p>*';
P_Tag[347]='<p class="c3">&nbsp;*</p>*';
P_Tag[348]='<p class="b1">&nbsp;*</p>*';
P_Tag[349]='<p class="b1">&nbsp;*</p>*';
P_Tag[350]='<p class="c3">&nbsp;*</p>*';
P_Tag[351]='<p class="sc">&nbsp;*</p>*';
P_Tag[352]='<p class="b1">&nbsp;*</p>*';
P_Tag[353]='<p class="c3">&nbsp;*</p>*';
P_Tag[354]='<p class="b1">&nbsp;*</p>*';
P_Tag[355]='<p class="b1">&nbsp;*</p>*';
P_Tag[356]='<p class="c3">&nbsp;*</p>*';
P_Tag[357]='<p class="b1">&nbsp;*<span class="font10" id="M1207_29">[Pg.29]</span></p>*';
P_Tag[358]='<p class="b1">&nbsp;*</p>*';
P_Tag[359]='<p class="c3">&nbsp;*</p>*';
P_Tag[360]='<p class="b1">&nbsp;*</p>*';
P_Tag[361]='<p class="b1">&nbsp;*</p>*';
P_Tag[362]='<p class="c3">&nbsp;*</p>*';
P_Tag[363]='<p class="b1">&nbsp;*</p>*';
P_Tag[364]='<p class="b1">&nbsp;*</p>*';
P_Tag[365]='<p class="c3">&nbsp;*</p>*';
P_Tag[366]='<p class="b1">&nbsp;*</p>*';
P_Tag[367]='<p class="b1">&nbsp;*</p>*';
P_Tag[368]='<p class="c3">&nbsp;*</p>*';
P_Tag[369]='<p class="c3">&nbsp;*</p>*';
P_Tag[370]='<p class="b1">&nbsp;*</p>*';
P_Tag[371]='<p class="b1">&nbsp;*</p>*';
P_Tag[372]='<p class="b1">&nbsp;*</p>*';
P_Tag[373]='<p class="b1">&nbsp;*</p>*';
P_Tag[374]='<p class="b1">&nbsp;*</p>*';
P_Tag[375]='<p class="c3">&nbsp;*</p>*';
P_Tag[376]='<p class="b1">&nbsp;*</p>*';
P_Tag[377]='<p class="b1">&nbsp;*</p>*';
P_Tag[378]='<p class="c3">&nbsp;*</p>*';
P_Tag[379]='<p class="b1">&nbsp;*</p>*';
P_Tag[380]='<p class="b1">&nbsp;*</p>*';
P_Tag[381]='<p class="c3">&nbsp;*</p>*';
P_Tag[382]='<p class="b1">&nbsp;*<span class="font10" id="M1207_30">[Pg.30]</span></p>*';
P_Tag[383]='<p class="b1">&nbsp;*</p>*';
P_Tag[384]='<p class="c3">&nbsp;*</p>*';
P_Tag[385]='<p class="c3">&nbsp;*</p>*';
P_Tag[386]='<p class="b1">&nbsp;*</p>*';
P_Tag[387]='<p class="b1">&nbsp;*</p>*';
P_Tag[388]='<p class="c3">&nbsp;*</p>*';
P_Tag[389]='<p class="b1">&nbsp;*</p>*';
P_Tag[390]='<p class="b1">&nbsp;*</p>*';
P_Tag[391]='<p class="c3">&nbsp;*</p>*';
P_Tag[392]='<p class="b1">&nbsp;*</p>*';
P_Tag[393]='<p class="c3">&nbsp;*</p>*';
P_Tag[394]='<p class="b1">&nbsp;*</p>*';
P_Tag[395]='<p class="c3">&nbsp;*</p>*';
P_Tag[396]='<p class="b1">&nbsp;*</p>*';
P_Tag[397]='<p class="c3">&nbsp;*</p>*';
P_Tag[398]='<p class="b1">&nbsp;*</p>*';
P_Tag[399]='<p class="c3">&nbsp;*</p>*';
P_Tag[400]='<p class="b1">&nbsp;*</p>*';
P_Tag[401]='<p class="c3">&nbsp;*</p>*';
P_Tag[402]='<p class="b1">&nbsp;*</p>*';
P_Tag[403]='<p class="c3">&nbsp;*</p>*';
P_Tag[404]='<p class="c3">&nbsp;*</p>*';
P_Tag[405]='<p class="b1">&nbsp;*<span class="font10" id="M1207_31">[Pg.31]</span></p>*';
P_Tag[406]='<p class="c3">&nbsp;*</p>*';
P_Tag[407]='<p class="b1">&nbsp;*</p>*';
P_Tag[408]='<p class="c3">&nbsp;*</p>*';
P_Tag[409]='<p class="b1">&nbsp;*</p>*';
P_Tag[410]='<p class="c3">&nbsp;*</p>*';
P_Tag[411]='<p class="b1">&nbsp;*</p>*';
P_Tag[412]='<p class="c3">&nbsp;*</p>*';
P_Tag[413]='<p class="b1">&nbsp;*</p>*';
P_Tag[414]='<p class="c3">&nbsp;*</p>*';
P_Tag[415]='<p class="b1">&nbsp;*</p>*';
P_Tag[416]='<p class="c3">&nbsp;*</p>*';
P_Tag[417]='<p class="b1">&nbsp;*</p>*';
P_Tag[418]='<p class="c3">&nbsp;*</p>*';
P_Tag[419]='<p class="b1">&nbsp;*</p>*';
P_Tag[420]='<p class="c3">&nbsp;*</p>*';
P_Tag[421]='<p class="b1">&nbsp;*</p>*';
P_Tag[422]='<p class="c3">&nbsp;*</p>*';
P_Tag[423]='<p class="b1">&nbsp;*</p>*';
P_Tag[424]='<p class="c3">&nbsp;*</p>*';
P_Tag[425]='<p class="c3">&nbsp;*</p>*';
P_Tag[426]='<p class="b1">&nbsp;*<span class="font10" id="M1207_32">[Pg.32]</span></p>*';
P_Tag[427]='<p class="c3">&nbsp;*</p>*';
P_Tag[428]='<p class="b1">&nbsp;*</p>*';
P_Tag[429]='<p class="c3">&nbsp;*</p>*';
P_Tag[430]='<p class="b1">&nbsp;*</p>*';
P_Tag[431]='<p class="c3">&nbsp;*</p>*';
P_Tag[432]='<p class="b1">&nbsp;*</p>*';
P_Tag[433]='<p class="c3">&nbsp;*</p>*';
P_Tag[434]='<p class="b1">&nbsp;*</p>*';
P_Tag[435]='<p class="c3">&nbsp;*</p>*';
P_Tag[436]='<p class="b1">&nbsp;*</p>*';
P_Tag[437]='<p class="c3">&nbsp;*</p>*';
P_Tag[438]='<p class="b1">&nbsp;*</p>*';
P_Tag[439]='<p class="c3">&nbsp;*</p>*';
P_Tag[440]='<p class="b1">&nbsp;*</p>*';
P_Tag[441]='<p class="c3">&nbsp;*</p>*';
P_Tag[442]='<p class="b1">&nbsp;*</p>*';
P_Tag[443]='<p class="c3">&nbsp;*</p>*';
P_Tag[444]='<p class="b1">&nbsp;*</p>*';
P_Tag[445]='<p class="c3">&nbsp;*</p>*';
P_Tag[446]='<p class="c3">&nbsp;*</p>*';
P_Tag[447]='<p class="b1">&nbsp;*</p>*';
P_Tag[448]='<p class="c3">&nbsp;*</p>*';
P_Tag[449]='<p class="b1">&nbsp;*</p>*';
P_Tag[450]='<p class="c3">&nbsp;*</p>*';
P_Tag[451]='<p class="b1">&nbsp;*<span class="font10" id="M1207_33">[Pg.33]</span></p>*';
P_Tag[452]='<p class="c3">&nbsp;*</p>*';
P_Tag[453]='<p class="b1">&nbsp;*</p>*';
P_Tag[454]='<p class="c3">&nbsp;*</p>*';
P_Tag[455]='<p class="b1">&nbsp;*</p>*';
P_Tag[456]='<p class="c3">&nbsp;*</p>*';
P_Tag[457]='<p class="b1">&nbsp;*</p>*';
P_Tag[458]='<p class="c3">&nbsp;*</p>*';
P_Tag[459]='<p class="b1">&nbsp;*</p>*';
P_Tag[460]='<p class="c3">&nbsp;*</p>*';
P_Tag[461]='<p class="b1">&nbsp;*</p>*';
P_Tag[462]='<p class="c3">&nbsp;*</p>*';
P_Tag[463]='<p class="b1">&nbsp;*</p>*';
P_Tag[464]='<p class="c3">&nbsp;*</p>*';
P_Tag[465]='<p class="b1">&nbsp;*</p>*';
P_Tag[466]='<p class="c3">&nbsp;*</p>*';
P_Tag[467]='<p class="c3">&nbsp;*</p>*';
P_Tag[468]='<p class="b1">&nbsp;*<span class="font10" id="M1207_34">[Pg.34]</span></p>*';
P_Tag[469]='<p class="c3">&nbsp;*</p>*';
P_Tag[470]='<p class="b1">&nbsp;*</p>*';
P_Tag[471]='<p class="c3">&nbsp;*</p>*';
P_Tag[472]='<p class="b1">&nbsp;*</p>*';
P_Tag[473]='<p class="c3">&nbsp;*</p>*';
P_Tag[474]='<p class="b1">&nbsp;*</p>*';
P_Tag[475]='<p class="c3">&nbsp;*</p>*';
P_Tag[476]='<p class="b1">&nbsp;*</p>*';
P_Tag[477]='<p class="c3">&nbsp;*</p>*';
P_Tag[478]='<p class="b1">&nbsp;*</p>*';
P_Tag[479]='<p class="c3">&nbsp;*</p>*';
P_Tag[480]='<p class="b1">&nbsp;*</p>*';
P_Tag[481]='<p class="c3">&nbsp;*</p>*';
P_Tag[482]='<p class="b1">&nbsp;*</p>*';
P_Tag[483]='<p class="c3">&nbsp;*</p>*';
P_Tag[484]='<p class="b1">&nbsp;*</p>*';
P_Tag[485]='<p class="c3">&nbsp;*</p>*';
P_Tag[486]='<p class="b1">&nbsp;*</p>*';
P_Tag[487]='<p class="c3">&nbsp;*</p>*';
P_Tag[488]='<p class="b1">&nbsp;*<span class="font10" id="M1207_35">[Pg.35]</span></p>*';
P_Tag[489]='<p class="c3">&nbsp;*</p>*';
P_Tag[490]='<p class="b1">&nbsp;*</p>*';
P_Tag[491]='<p class="c3">&nbsp;*</p>*';
P_Tag[492]='<p class="b1">&nbsp;*</p>*';
P_Tag[493]='<p class="c3">&nbsp;*</p>*';
P_Tag[494]='<p class="b1">&nbsp;*</p>*';
P_Tag[495]='<p class="c3">&nbsp;*</p>*';
P_Tag[496]='<p class="b1">&nbsp;*</p>*';
P_Tag[497]='<p class="c3">&nbsp;*</p>*';
P_Tag[498]='<p class="b1">&nbsp;*</p>*';
P_Tag[499]='<p class="c3">&nbsp;*</p>*';
P_Tag[500]='<p class="sc">&nbsp;*</p>*';
P_Tag[501]='<p class="c3">&nbsp;*</p>*';
P_Tag[502]='<p class="c3">&nbsp;*</p>*';
P_Tag[503]='<p class="b1">&nbsp;*</p>*';
P_Tag[504]='<p class="b1">&nbsp;*</p>*';
P_Tag[505]='<p class="b1">&nbsp;*</p>*';
P_Tag[506]='<p class="b1">&nbsp;*<span class="font10" id="M1207_36">[Pg.36]</span></p>*';
P_Tag[507]='<p class="b1">&nbsp;*</p>*';
P_Tag[508]='<p class="b1">&nbsp;*</p>*';
P_Tag[509]='<p class="b1">&nbsp;*</p>*';
P_Tag[510]='<p class="b1">&nbsp;*</p>*';
P_Tag[511]='<p class="c3">&nbsp;*</p>*';
P_Tag[512]='<p class="b1">&nbsp;*</p>*';
P_Tag[513]='<p class="b1">&nbsp;*</p>*';
P_Tag[514]='<p class="b1">&nbsp;*</p>*';
P_Tag[515]='<p class="b1">&nbsp;*</p>*';
P_Tag[516]='<p class="b1">&nbsp;*</p>*';
P_Tag[517]='<p class="b1">&nbsp;*</p>*';
P_Tag[518]='<p class="b1">&nbsp;*</p>*';
P_Tag[519]='<p class="b1">&nbsp;*</p>*';
P_Tag[520]='<p class="b1">&nbsp;*</p>*';
P_Tag[521]='<p class="c3">&nbsp;*</p>*';
P_Tag[522]='<p class="c3">&nbsp;*</p>*';
P_Tag[523]='<p class="c3">&nbsp;*</p>*';
P_Tag[524]='<p class="c4">&nbsp;*</p>*';
P_Tag[525]='<p class="c3">&nbsp;*</p>*';
P_Tag[526]='<p class="g5">&nbsp;*<span class="font10" id="M1207_37">[Pg.37]</span></p>*';
P_Tag[527]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[528]='<p class="c3">&nbsp;*</p>*';
P_Tag[529]='<p class="g5">&nbsp;*</p>*';
P_Tag[530]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[531]='<p class="c3">&nbsp;*</p>*';
P_Tag[532]='<p class="g5">&nbsp;*</p>*';
P_Tag[533]='<p class="g5">&nbsp;*</p>*';
P_Tag[534]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[535]='<p class="b1">&nbsp;*</p>*';
P_Tag[536]='<p class="sc">&nbsp;*</p>*';
P_Tag[537]='<p class="b1">&nbsp;*</p>*';
P_Tag[538]='<p class="b1">&nbsp;*<span class="font10" id="M1207_38">[Pg.38]</span></p>*';
P_Tag[539]='<p class="b1">&nbsp;*</p>*';
P_Tag[540]='<p class="c3">&nbsp;*</p>*';
P_Tag[541]='<p class="sc">&nbsp;*</p>*';
P_Tag[542]='<p class="c3">&nbsp;*</p>*';
P_Tag[543]='<p class="c3">&nbsp;*</p>*';
P_Tag[544]='<p class="b1">&nbsp;*</p>*';
P_Tag[545]='<p class="c3">&nbsp;*</p>*';
P_Tag[546]='<p class="b1">&nbsp;*</p>*';
P_Tag[547]='<p class="c3">&nbsp;*</p>*';
P_Tag[548]='<p class="b1">&nbsp;*</p>*';
P_Tag[549]='<p class="c3">&nbsp;*</p>*';
P_Tag[550]='<p class="b1">&nbsp;*<span class="font10" id="M1207_39">[Pg.39]</span></p>*';
P_Tag[551]='<p class="c3">&nbsp;*</p>*';
P_Tag[552]='<p class="b1">&nbsp;*</p>*';
P_Tag[553]='<p class="c3">&nbsp;*</p>*';
P_Tag[554]='<p class="b1">&nbsp;*</p>*';
P_Tag[555]='<p class="c3">&nbsp;*</p>*';
P_Tag[556]='<p class="b1">&nbsp;*</p>*';
P_Tag[557]='<p class="c3">&nbsp;*</p>*';
P_Tag[558]='<p class="b1">&nbsp;*<span class="font10" id="M1207_40">[Pg.40]</span></p>*';
P_Tag[559]='<p class="b1">&nbsp;*</p>*';
P_Tag[560]='<p class="c3">&nbsp;*</p>*';
P_Tag[561]='<p class="sc">&nbsp;*</p>*';
P_Tag[562]='<p class="c3">&nbsp;*</p>*';
P_Tag[563]='<p class="c3">&nbsp;*</p>*';
P_Tag[564]='<p class="c3">&nbsp;*</p>*';
P_Tag[565]='<p class="b1">&nbsp;*</p>*';
P_Tag[566]='<p class="c3">&nbsp;*</p>*';
P_Tag[567]='<p class="b1">&nbsp;*</p>*';
P_Tag[568]='<p class="c3">&nbsp;*</p>*';
P_Tag[569]='<p class="b1">&nbsp;*<span class="font10" id="M1207_41">[Pg.41]</span></p>*';
P_Tag[570]='<p class="c3">&nbsp;*</p>*';
P_Tag[571]='<p class="b1">&nbsp;*</p>*';
P_Tag[572]='<p class="c3">&nbsp;*</p>*';
P_Tag[573]='<p class="b1">&nbsp;*</p>*';
P_Tag[574]='<p class="c3">&nbsp;*</p>*';
P_Tag[575]='<p class="b1">&nbsp;*</p>*';
P_Tag[576]='<p class="c3">&nbsp;*</p>*';
P_Tag[577]='<p class="b1">&nbsp;*</p>*';
P_Tag[578]='<p class="c3">&nbsp;*</p>*';
P_Tag[579]='<p class="b1">&nbsp;*<span class="font10" id="M1207_42">[Pg.42]</span></p>*';
P_Tag[580]='<p class="c3">&nbsp;*</p>*';
P_Tag[581]='<p class="b1">&nbsp;*</p>*';
P_Tag[582]='<p class="c3">&nbsp;*</p>*';
P_Tag[583]='<p class="b1">&nbsp;*</p>*';
P_Tag[584]='<p class="c3">&nbsp;*</p>*';
P_Tag[585]='<p class="b1">&nbsp;*<span class="font10" id="M1207_43">[Pg.43]</span></p>*';
P_Tag[586]='<p class="c3">&nbsp;*</p>*';
P_Tag[587]='<p class="b1">&nbsp;*</p>*';
P_Tag[588]='<p class="c3">&nbsp;*</p>*';
P_Tag[589]='<p class="b1">&nbsp;*<span class="font10" id="M1207_44">[Pg.44]</span></p>*';
P_Tag[590]='<p class="c3">&nbsp;*</p>*';
P_Tag[591]='<p class="b1">&nbsp;*</p>*';
P_Tag[592]='<p class="c3">&nbsp;*</p>*';
P_Tag[593]='<p class="b1">&nbsp;*<span class="font10" id="M1207_45">[Pg.45]</span></p>*';
P_Tag[594]='<p class="c3">&nbsp;*</p>*';
P_Tag[595]='<p class="b1">&nbsp;*</p>*';
P_Tag[596]='<p class="c3">&nbsp;*</p>*';
P_Tag[597]='<p class="b1">&nbsp;*<span class="font10" id="M1207_46">[Pg.46]</span></p>*';
P_Tag[598]='<p class="c3">&nbsp;*</p>*';
P_Tag[599]='<p class="b1">&nbsp;*</p>*';
P_Tag[600]='<p class="c3">&nbsp;*</p>*';
P_Tag[601]='<p class="sc">&nbsp;*</p>*';
P_Tag[602]='<p class="c3">&nbsp;*</p>*';
P_Tag[603]='<p class="c3">&nbsp;*</p>*';
P_Tag[604]='<p class="c3">&nbsp;*</p>*';
P_Tag[605]='<p class="b1">&nbsp;*</p>*';
P_Tag[606]='<p class="c3">&nbsp;*</p>*';
P_Tag[607]='<p class="b1">&nbsp;*</p>*';
P_Tag[608]='<p class="c3">&nbsp;*</p>*';
P_Tag[609]='<p class="b1">&nbsp;*<span class="font10" id="M1207_47">[Pg.47]</span></p>*';
P_Tag[610]='<p class="c3">&nbsp;*</p>*';
P_Tag[611]='<p class="b1">&nbsp;*</p>*';
P_Tag[612]='<p class="c3">&nbsp;*</p>*';
P_Tag[613]='<p class="b1">&nbsp;*</p>*';
P_Tag[614]='<p class="c3">&nbsp;*</p>*';
P_Tag[615]='<p class="b1">&nbsp;*</p>*';
P_Tag[616]='<p class="c3">&nbsp;*</p>*';
P_Tag[617]='<p class="b1">&nbsp;*</p>*';
P_Tag[618]='<p class="c3">&nbsp;*</p>*';
P_Tag[619]='<p class="b1">&nbsp;*</p>*';
P_Tag[620]='<p class="c3">&nbsp;*</p>*';
P_Tag[621]='<p class="b1">&nbsp;*</p>*';
P_Tag[622]='<p class="c3">&nbsp;*</p>*';
P_Tag[623]='<p class="b1">&nbsp;*</p>*';
P_Tag[624]='<p class="c3">&nbsp;*</p>*';
P_Tag[625]='<p class="c3">&nbsp;*</p>*';
P_Tag[626]='<p class="b1">&nbsp;*<span class="font10" id="M1207_48">[Pg.48]</span></p>*';
P_Tag[627]='<p class="c3">&nbsp;*</p>*';
P_Tag[628]='<p class="b1">&nbsp;*</p>*';
P_Tag[629]='<p class="c3">&nbsp;*</p>*';
P_Tag[630]='<p class="b1">&nbsp;*</p>*';
P_Tag[631]='<p class="c3">&nbsp;*</p>*';
P_Tag[632]='<p class="b1">&nbsp;*</p>*';
P_Tag[633]='<p class="c3">&nbsp;*</p>*';
P_Tag[634]='<p class="b1">&nbsp;*</p>*';
P_Tag[635]='<p class="c3">&nbsp;*</p>*';
P_Tag[636]='<p class="b1">&nbsp;*</p>*';
P_Tag[637]='<p class="c3">&nbsp;*</p>*';
P_Tag[638]='<p class="b1">&nbsp;*</p>*';
P_Tag[639]='<p class="c3">&nbsp;*</p>*';
P_Tag[640]='<p class="b1">&nbsp;*<span class="font10" id="M1207_49">[Pg.49]</span></p>*';
P_Tag[641]='<p class="c3">&nbsp;*</p>*';
P_Tag[642]='<p class="b1">&nbsp;*</p>*';
P_Tag[643]='<p class="c3">&nbsp;*</p>*';
P_Tag[644]='<p class="b1">&nbsp;*<span class="font10" id="M1207_50">[Pg.50]</span></p>*';
P_Tag[645]='<p class="c3">&nbsp;*</p>*';
P_Tag[646]='<p class="c3">&nbsp;*</p>*';
P_Tag[647]='<p class="b1">&nbsp;*</p>*';
P_Tag[648]='<p class="c3">&nbsp;*</p>*';
P_Tag[649]='<p class="b1">&nbsp;*</p>*';
P_Tag[650]='<p class="c3">&nbsp;*</p>*';
P_Tag[651]='<p class="b1">&nbsp;*</p>*';
P_Tag[652]='<p class="c3">&nbsp;*</p>*';
P_Tag[653]='<p class="b1">&nbsp;*</p>*';
P_Tag[654]='<p class="c3">&nbsp;*</p>*';
P_Tag[655]='<p class="b1">&nbsp;*<span class="font10" id="M1207_51">[Pg.51]</span></p>*';
P_Tag[656]='<p class="c3">&nbsp;*</p>*';
P_Tag[657]='<p class="b1">&nbsp;*</p>*';
P_Tag[658]='<p class="c3">&nbsp;*</p>*';
P_Tag[659]='<p class="b1">&nbsp;*</p>*';
P_Tag[660]='<p class="c3">&nbsp;*</p>*';
P_Tag[661]='<p class="b1">&nbsp;*</p>*';
P_Tag[662]='<p class="c3">&nbsp;*</p>*';
P_Tag[663]='<p class="b1">&nbsp;*</p>*';
P_Tag[664]='<p class="c3">&nbsp;*</p>*';
P_Tag[665]='<p class="b1">&nbsp;*</p>*';
P_Tag[666]='<p class="c3">&nbsp;*</p>*';
P_Tag[667]='<p class="b1">&nbsp;*<span class="font10" id="M1207_52">[Pg.52]</span></p>*';
P_Tag[668]='<p class="c3">&nbsp;*</p>*';
P_Tag[669]='<p class="sc">&nbsp;*</p>*';
P_Tag[670]='<p class="c3">&nbsp;*</p>*';
P_Tag[671]='<p class="c3">&nbsp;*</p>*';
P_Tag[672]='<p class="c3">&nbsp;*</p>*';
P_Tag[673]='<p class="b1">&nbsp;*</p>*';
P_Tag[674]='<p class="c3">&nbsp;*</p>*';
P_Tag[675]='<p class="b1">&nbsp;*</p>*';
P_Tag[676]='<p class="c3">&nbsp;*</p>*';
P_Tag[677]='<p class="b1">&nbsp;*</p>*';
P_Tag[678]='<p class="c3">&nbsp;*</p>*';
P_Tag[679]='<p class="b1">&nbsp;*</p>*';
P_Tag[680]='<p class="c3">&nbsp;*</p>*';
P_Tag[681]='<p class="b1">&nbsp;*</p>*';
P_Tag[682]='<p class="c3">&nbsp;*</p>*';
P_Tag[683]='<p class="b1">&nbsp;*</p>*';
P_Tag[684]='<p class="c3">&nbsp;*</p>*';
P_Tag[685]='<p class="b1">&nbsp;*</p>*';
P_Tag[686]='<p class="c3">&nbsp;*</p>*';
P_Tag[687]='<p class="b1">&nbsp;*<span class="font10" id="M1207_53">[Pg.53]</span></p>*';
P_Tag[688]='<p class="c3">&nbsp;*</p>*';
P_Tag[689]='<p class="b1">&nbsp;*</p>*';
P_Tag[690]='<p class="c3">&nbsp;*</p>*';
P_Tag[691]='<p class="b1">&nbsp;*</p>*';
P_Tag[692]='<p class="c3">&nbsp;*</p>*';
P_Tag[693]='<p class="c3">&nbsp;*</p>*';
P_Tag[694]='<p class="b1">&nbsp;*</p>*';
P_Tag[695]='<p class="c3">&nbsp;*</p>*';
P_Tag[696]='<p class="b1">&nbsp;*</p>*';
P_Tag[697]='<p class="c3">&nbsp;*</p>*';
P_Tag[698]='<p class="b1">&nbsp;*</p>*';
P_Tag[699]='<p class="c3">&nbsp;*</p>*';
P_Tag[700]='<p class="b1">&nbsp;*</p>*';
P_Tag[701]='<p class="c3">&nbsp;*</p>*';
P_Tag[702]='<p class="b1">&nbsp;*</p>*';
P_Tag[703]='<p class="c3">&nbsp;*</p>*';
P_Tag[704]='<p class="b1">&nbsp;*<span class="font10" id="M1207_54">[Pg.54]</span></p>*';
P_Tag[705]='<p class="c3">&nbsp;*</p>*';
P_Tag[706]='<p class="b1">&nbsp;*</p>*';
P_Tag[707]='<p class="c3">&nbsp;*</p>*';
P_Tag[708]='<p class="b1">&nbsp;*</p>*';
P_Tag[709]='<p class="c3">&nbsp;*</p>*';
P_Tag[710]='<p class="b1">&nbsp;*</p>*';
P_Tag[711]='<p class="c3">&nbsp;*</p>*';
P_Tag[712]='<p class="b1">&nbsp;*</p>*';
P_Tag[713]='<p class="c3">&nbsp;*</p>*';
P_Tag[714]='<p class="c3">&nbsp;*</p>*';
P_Tag[715]='<p class="b1">&nbsp;*</p>*';
P_Tag[716]='<p class="c3">&nbsp;*</p>*';
P_Tag[717]='<p class="b1">&nbsp;*</p>*';
P_Tag[718]='<p class="c3">&nbsp;*</p>*';
P_Tag[719]='<p class="b1">&nbsp;*</p>*';
P_Tag[720]='<p class="c3">&nbsp;*</p>*';
P_Tag[721]='<p class="b1">&nbsp;*<span class="font10" id="M1207_55">[Pg.55]</span></p>*';
P_Tag[722]='<p class="c3">&nbsp;*</p>*';
P_Tag[723]='<p class="b1">&nbsp;*</p>*';
P_Tag[724]='<p class="c3">&nbsp;*</p>*';
P_Tag[725]='<p class="b1">&nbsp;*</p>*';
P_Tag[726]='<p class="c3">&nbsp;*</p>*';
P_Tag[727]='<p class="b1">&nbsp;*</p>*';
P_Tag[728]='<p class="c3">&nbsp;*</p>*';
P_Tag[729]='<p class="b1">&nbsp;*</p>*';
P_Tag[730]='<p class="c3">&nbsp;*</p>*';
P_Tag[731]='<p class="b1">&nbsp;*</p>*';
P_Tag[732]='<p class="c3">&nbsp;*</p>*';
P_Tag[733]='<p class="b1">&nbsp;*</p>*';
P_Tag[734]='<p class="c3">&nbsp;*</p>*';
P_Tag[735]='<p class="c3">&nbsp;*</p>*';
P_Tag[736]='<p class="b1">&nbsp;*</p>*';
P_Tag[737]='<p class="c3">&nbsp;*</p>*';
P_Tag[738]='<p class="b1">&nbsp;*</p>*';
P_Tag[739]='<p class="c3">&nbsp;*</p>*';
P_Tag[740]='<p class="b1">&nbsp;*</p>*';
P_Tag[741]='<p class="c3">&nbsp;*</p>*';
P_Tag[742]='<p class="b1">&nbsp;*<span class="font10" id="M1207_56">[Pg.56]</span></p>*';
P_Tag[743]='<p class="c3">&nbsp;*</p>*';
P_Tag[744]='<p class="b1">&nbsp;*</p>*';
P_Tag[745]='<p class="c3">&nbsp;*</p>*';
P_Tag[746]='<p class="b1">&nbsp;*</p>*';
P_Tag[747]='<p class="c3">&nbsp;*</p>*';
P_Tag[748]='<p class="b1">&nbsp;*</p>*';
P_Tag[749]='<p class="c3">&nbsp;*</p>*';
P_Tag[750]='<p class="b1">&nbsp;*</p>*';
P_Tag[751]='<p class="c3">&nbsp;*</p>*';
P_Tag[752]='<p class="b1">&nbsp;*</p>*';
P_Tag[753]='<p class="c3">&nbsp;*</p>*';
P_Tag[754]='<p class="b1">&nbsp;*</p>*';
P_Tag[755]='<p class="c3">&nbsp;*</p>*';
P_Tag[756]='<p class="c3">&nbsp;*</p>*';
P_Tag[757]='<p class="b1">&nbsp;*<span class="font10" id="M1207_57">[Pg.57]</span></p>*';
P_Tag[758]='<p class="c3">&nbsp;*</p>*';
P_Tag[759]='<p class="b1">&nbsp;*</p>*';
P_Tag[760]='<p class="c3">&nbsp;*</p>*';
P_Tag[761]='<p class="b1">&nbsp;*</p>*';
P_Tag[762]='<p class="c3">&nbsp;*</p>*';
P_Tag[763]='<p class="b1">&nbsp;*</p>*';
P_Tag[764]='<p class="c3">&nbsp;*</p>*';
P_Tag[765]='<p class="b1">&nbsp;*</p>*';
P_Tag[766]='<p class="c3">&nbsp;*</p>*';
P_Tag[767]='<p class="b1">&nbsp;*</p>*';
P_Tag[768]='<p class="c3">&nbsp;*</p>*';
P_Tag[769]='<p class="b1">&nbsp;*</p>*';
P_Tag[770]='<p class="c3">&nbsp;*</p>*';
P_Tag[771]='<p class="b1">&nbsp;*</p>*';
P_Tag[772]='<p class="c3">&nbsp;*</p>*';
P_Tag[773]='<p class="b1">&nbsp;*</p>*';
P_Tag[774]='<p class="c3">&nbsp;*</p>*';
P_Tag[775]='<p class="b1">&nbsp;*</p>*';
P_Tag[776]='<p class="c3">&nbsp;*</p>*';
P_Tag[777]='<p class="c3">&nbsp;*</p>*';
P_Tag[778]='<p class="b1">&nbsp;*<span class="font10" id="M1207_58">[Pg.58]</span></p>*';
P_Tag[779]='<p class="c3">&nbsp;*</p>*';
P_Tag[780]='<p class="b1">&nbsp;*</p>*';
P_Tag[781]='<p class="c3">&nbsp;*</p>*';
P_Tag[782]='<p class="b1">&nbsp;*</p>*';
P_Tag[783]='<p class="c3">&nbsp;*</p>*';
P_Tag[784]='<p class="b1">&nbsp;*</p>*';
P_Tag[785]='<p class="c3">&nbsp;*</p>*';
P_Tag[786]='<p class="b1">&nbsp;*</p>*';
P_Tag[787]='<p class="c3">&nbsp;*</p>*';
P_Tag[788]='<p class="b1">&nbsp;*</p>*';
P_Tag[789]='<p class="c3">&nbsp;*</p>*';
P_Tag[790]='<p class="b1">&nbsp;*</p>*';
P_Tag[791]='<p class="c3">&nbsp;*</p>*';
P_Tag[792]='<p class="b1">&nbsp;*</p>*';
P_Tag[793]='<p class="c3">&nbsp;*</p>*';
P_Tag[794]='<p class="b1">&nbsp;*</p>*';
P_Tag[795]='<p class="c3">&nbsp;*</p>*';
P_Tag[796]='<p class="b1">&nbsp;*<span class="font10" id="M1207_59">[Pg.59]</span></p>*';
P_Tag[797]='<p class="c3">&nbsp;*</p>*';
P_Tag[798]='<p class="c3">&nbsp;*</p>*';
P_Tag[799]='<p class="b1">&nbsp;*</p>*';
P_Tag[800]='<p class="c3">&nbsp;*</p>*';
P_Tag[801]='<p class="b1">&nbsp;*</p>*';
P_Tag[802]='<p class="c3">&nbsp;*</p>*';
P_Tag[803]='<p class="b1">&nbsp;*</p>*';
P_Tag[804]='<p class="c3">&nbsp;*</p>*';
P_Tag[805]='<p class="b1">&nbsp;*</p>*';
P_Tag[806]='<p class="c3">&nbsp;*</p>*';
P_Tag[807]='<p class="b1">&nbsp;*</p>*';
P_Tag[808]='<p class="c3">&nbsp;*</p>*';
P_Tag[809]='<p class="b1">&nbsp;*</p>*';
P_Tag[810]='<p class="c3">&nbsp;*</p>*';
P_Tag[811]='<p class="b1">&nbsp;*</p>*';
P_Tag[812]='<p class="c3">&nbsp;*</p>*';
P_Tag[813]='<p class="b1">&nbsp;*</p>*';
P_Tag[814]='<p class="c3">&nbsp;*</p>*';
P_Tag[815]='<p class="b1">&nbsp;*</p>*';
P_Tag[816]='<p class="c3">&nbsp;*</p>*';
P_Tag[817]='<p class="b1">&nbsp;*<span class="font10" id="M1207_60">[Pg.60]</span></p>*';
P_Tag[818]='<p class="c3">&nbsp;*</p>*';
P_Tag[819]='<p class="c3">&nbsp;*</p>*';
P_Tag[820]='<p class="b1">&nbsp;*</p>*';
P_Tag[821]='<p class="c3">&nbsp;*</p>*';
P_Tag[822]='<p class="b1">&nbsp;*</p>*';
P_Tag[823]='<p class="c3">&nbsp;*</p>*';
P_Tag[824]='<p class="b1">&nbsp;*</p>*';
P_Tag[825]='<p class="c3">&nbsp;*</p>*';
P_Tag[826]='<p class="b1">&nbsp;*</p>*';
P_Tag[827]='<p class="c3">&nbsp;*</p>*';
P_Tag[828]='<p class="b1">&nbsp;*</p>*';
P_Tag[829]='<p class="c3">&nbsp;*</p>*';
P_Tag[830]='<p class="b1">&nbsp;*</p>*';
P_Tag[831]='<p class="c3">&nbsp;*</p>*';
P_Tag[832]='<p class="b1">&nbsp;*</p>*';
P_Tag[833]='<p class="c3">&nbsp;*</p>*';
P_Tag[834]='<p class="b1">&nbsp;*<span class="font10" id="M1207_61">[Pg.61]</span></p>*';
P_Tag[835]='<p class="c3">&nbsp;*</p>*';
P_Tag[836]='<p class="b1">&nbsp;*</p>*';
P_Tag[837]='<p class="c3">&nbsp;*</p>*';
P_Tag[838]='<p class="b1">&nbsp;*</p>*';
P_Tag[839]='<p class="c3">&nbsp;*</p>*';
P_Tag[840]='<p class="b1">&nbsp;*</p>*';
P_Tag[841]='<p class="c3">&nbsp;*</p>*';
P_Tag[842]='<p class="b1">&nbsp;*</p>*';
P_Tag[843]='<p class="c3">&nbsp;*</p>*';
P_Tag[844]='<p class="b1">&nbsp;*</p>*';
P_Tag[845]='<p class="c3">&nbsp;*</p>*';
P_Tag[846]='<p class="c3">&nbsp;*</p>*';
P_Tag[847]='<p class="b1">&nbsp;*</p>*';
P_Tag[848]='<p class="c3">&nbsp;*</p>*';
P_Tag[849]='<p class="b1">&nbsp;*</p>*';
P_Tag[850]='<p class="c3">&nbsp;*</p>*';
P_Tag[851]='<p class="b1">&nbsp;*</p>*';
P_Tag[852]='<p class="c3">&nbsp;*</p>*';
P_Tag[853]='<p class="b1">&nbsp;*</p>*';
P_Tag[854]='<p class="c3">&nbsp;*</p>*';
P_Tag[855]='<p class="b1">&nbsp;*<span class="font10" id="M1207_62">[Pg.62]</span></p>*';
P_Tag[856]='<p class="c3">&nbsp;*</p>*';
P_Tag[857]='<p class="b1">&nbsp;*</p>*';
P_Tag[858]='<p class="c3">&nbsp;*</p>*';
P_Tag[859]='<p class="b1">&nbsp;*</p>*';
P_Tag[860]='<p class="c3">&nbsp;*</p>*';
P_Tag[861]='<p class="b1">&nbsp;*</p>*';
P_Tag[862]='<p class="c3">&nbsp;*</p>*';
P_Tag[863]='<p class="b1">&nbsp;*</p>*';
P_Tag[864]='<p class="c3">&nbsp;*</p>*';
P_Tag[865]='<p class="b1">&nbsp;*</p>*';
P_Tag[866]='<p class="c3">&nbsp;*</p>*';
P_Tag[867]='<p class="b1">&nbsp;*</p>*';
P_Tag[868]='<p class="c3">&nbsp;*</p>*';
P_Tag[869]='<p class="b1">&nbsp;*</p>*';
P_Tag[870]='<p class="c3">&nbsp;*</p>*';
P_Tag[871]='<p class="b1">&nbsp;*</p>*';
P_Tag[872]='<p class="c3">&nbsp;*</p>*';
P_Tag[873]='<p class="c3">&nbsp;*</p>*';
P_Tag[874]='<p class="b1">&nbsp;*<span class="font10" id="M1207_63">[Pg.63]</span></p>*';
P_Tag[875]='<p class="c3">&nbsp;*</p>*';
P_Tag[876]='<p class="b1">&nbsp;*</p>*';
P_Tag[877]='<p class="c3">&nbsp;*</p>*';
P_Tag[878]='<p class="b1">&nbsp;*</p>*';
P_Tag[879]='<p class="c3">&nbsp;*</p>*';
P_Tag[880]='<p class="b1">&nbsp;*</p>*';
P_Tag[881]='<p class="c3">&nbsp;*</p>*';
P_Tag[882]='<p class="b1">&nbsp;*</p>*';
P_Tag[883]='<p class="c3">&nbsp;*</p>*';
P_Tag[884]='<p class="b1">&nbsp;*</p>*';
P_Tag[885]='<p class="c3">&nbsp;*</p>*';
P_Tag[886]='<p class="b1">&nbsp;*</p>*';
P_Tag[887]='<p class="c3">&nbsp;*</p>*';
P_Tag[888]='<p class="b1">&nbsp;*</p>*';
P_Tag[889]='<p class="c3">&nbsp;*</p>*';
P_Tag[890]='<p class="b1">&nbsp;*</p>*';
P_Tag[891]='<p class="c3">&nbsp;*</p>*';
P_Tag[892]='<p class="b1">&nbsp;*</p>*';
P_Tag[893]='<p class="c3">&nbsp;*</p>*';
P_Tag[894]='<p class="c3">&nbsp;*</p>*';
P_Tag[895]='<p class="b1">&nbsp;*<span class="font10" id="M1207_64">[Pg.64]</span></p>*';
P_Tag[896]='<p class="c3">&nbsp;*</p>*';
P_Tag[897]='<p class="b1">&nbsp;*</p>*';
P_Tag[898]='<p class="c3">&nbsp;*</p>*';
P_Tag[899]='<p class="b1">&nbsp;*</p>*';
P_Tag[900]='<p class="c3">&nbsp;*</p>*';
P_Tag[901]='<p class="b1">&nbsp;*</p>*';
P_Tag[902]='<p class="c3">&nbsp;*</p>*';
P_Tag[903]='<p class="b1">&nbsp;*</p>*';
P_Tag[904]='<p class="c3">&nbsp;*</p>*';
P_Tag[905]='<p class="b1">&nbsp;*</p>*';
P_Tag[906]='<p class="c3">&nbsp;*</p>*';
P_Tag[907]='<p class="b1">&nbsp;*</p>*';
P_Tag[908]='<p class="c3">&nbsp;*</p>*';
P_Tag[909]='<p class="b1">&nbsp;*</p>*';
P_Tag[910]='<p class="c3">&nbsp;*</p>*';
P_Tag[911]='<p class="b1">&nbsp;*</p>*';
P_Tag[912]='<p class="c3">&nbsp;*</p>*';
P_Tag[913]='<p class="b1">&nbsp;*<span class="font10" id="M1207_65">[Pg.65]</span></p>*';
P_Tag[914]='<p class="c3">&nbsp;*</p>*';
P_Tag[915]='<p class="c3">&nbsp;*</p>*';
P_Tag[916]='<p class="b1">&nbsp;*</p>*';
P_Tag[917]='<p class="c3">&nbsp;*</p>*';
P_Tag[918]='<p class="b1">&nbsp;*</p>*';
P_Tag[919]='<p class="c3">&nbsp;*</p>*';
P_Tag[920]='<p class="b1">&nbsp;*</p>*';
P_Tag[921]='<p class="c3">&nbsp;*</p>*';
P_Tag[922]='<p class="b1">&nbsp;*</p>*';
P_Tag[923]='<p class="c3">&nbsp;*</p>*';
P_Tag[924]='<p class="b1">&nbsp;*</p>*';
P_Tag[925]='<p class="c3">&nbsp;*</p>*';
P_Tag[926]='<p class="b1">&nbsp;*</p>*';
P_Tag[927]='<p class="c3">&nbsp;*</p>*';
P_Tag[928]='<p class="b1">&nbsp;*<span class="font10" id="M1207_66">[Pg.66]</span></p>*';
P_Tag[929]='<p class="c3">&nbsp;*</p>*';
P_Tag[930]='<p class="b1">&nbsp;*</p>*';
P_Tag[931]='<p class="c3">&nbsp;*</p>*';
P_Tag[932]='<p class="b1">&nbsp;*</p>*';
P_Tag[933]='<p class="c3">&nbsp;*</p>*';
P_Tag[934]='<p class="b1">&nbsp;*</p>*';
P_Tag[935]='<p class="c3">&nbsp;*</p>*';
P_Tag[936]='<p class="c3">&nbsp;*</p>*';
P_Tag[937]='<p class="b1">&nbsp;*</p>*';
P_Tag[938]='<p class="c3">&nbsp;*</p>*';
P_Tag[939]='<p class="b1">&nbsp;*</p>*';
P_Tag[940]='<p class="c3">&nbsp;*</p>*';
P_Tag[941]='<p class="b1">&nbsp;*</p>*';
P_Tag[942]='<p class="c3">&nbsp;*</p>*';
P_Tag[943]='<p class="b1">&nbsp;*<span class="font10" id="M1207_67">[Pg.67]</span></p>*';
P_Tag[944]='<p class="c3">&nbsp;*</p>*';
P_Tag[945]='<p class="b1">&nbsp;*</p>*';
P_Tag[946]='<p class="c3">&nbsp;*</p>*';
P_Tag[947]='<p class="b1">&nbsp;*</p>*';
P_Tag[948]='<p class="c3">&nbsp;*</p>*';
P_Tag[949]='<p class="b1">&nbsp;*</p>*';
P_Tag[950]='<p class="c3">&nbsp;*</p>*';
P_Tag[951]='<p class="b1">&nbsp;*</p>*';
P_Tag[952]='<p class="c3">&nbsp;*</p>*';
P_Tag[953]='<p class="b1">&nbsp;*</p>*';
P_Tag[954]='<p class="c3">&nbsp;*</p>*';
P_Tag[955]='<p class="b1">&nbsp;*</p>*';
P_Tag[956]='<p class="c3">&nbsp;*</p>*';
P_Tag[957]='<p class="c3">&nbsp;*</p>*';
P_Tag[958]='<p class="b1">&nbsp;*</p>*';
P_Tag[959]='<p class="c3">&nbsp;*</p>*';
P_Tag[960]='<p class="b1">&nbsp;*</p>*';
P_Tag[961]='<p class="c3">&nbsp;*</p>*';
P_Tag[962]='<p class="b1">&nbsp;*<span class="font10" id="M1207_68">[Pg.68]</span></p>*';
P_Tag[963]='<p class="c3">&nbsp;*</p>*';
P_Tag[964]='<p class="b1">&nbsp;*</p>*';
P_Tag[965]='<p class="c3">&nbsp;*</p>*';
P_Tag[966]='<p class="b1">&nbsp;*</p>*';
P_Tag[967]='<p class="c3">&nbsp;*</p>*';
P_Tag[968]='<p class="b1">&nbsp;*</p>*';
P_Tag[969]='<p class="c3">&nbsp;*</p>*';
P_Tag[970]='<p class="b1">&nbsp;*</p>*';
P_Tag[971]='<p class="c3">&nbsp;*</p>*';
P_Tag[972]='<p class="b1">&nbsp;*</p>*';
P_Tag[973]='<p class="c3">&nbsp;*</p>*';
P_Tag[974]='<p class="b1">&nbsp;*</p>*';
P_Tag[975]='<p class="c3">&nbsp;*</p>*';
P_Tag[976]='<p class="b1">&nbsp;*<span class="font10" id="M1207_69">[Pg.69]</span></p>*';
P_Tag[977]='<p class="c3">&nbsp;*</p>*';
P_Tag[978]='<p class="c3">&nbsp;*</p>*';
P_Tag[979]='<p class="b1">&nbsp;*</p>*';
P_Tag[980]='<p class="c3">&nbsp;*</p>*';
P_Tag[981]='<p class="b1">&nbsp;*</p>*';
P_Tag[982]='<p class="c3">&nbsp;*</p>*';
P_Tag[983]='<p class="b1">&nbsp;*</p>*';
P_Tag[984]='<p class="c3">&nbsp;*</p>*';
P_Tag[985]='<p class="b1">&nbsp;*<span class="font10" id="M1207_70">[Pg.70]</span></p>*';
P_Tag[986]='<p class="c3">&nbsp;*</p>*';
P_Tag[987]='<p class="b1">&nbsp;*</p>*';
P_Tag[988]='<p class="c3">&nbsp;*</p>*';
P_Tag[989]='<p class="b1">&nbsp;*</p>*';
P_Tag[990]='<p class="c3">&nbsp;*</p>*';
P_Tag[991]='<p class="b1">&nbsp;*</p>*';
P_Tag[992]='<p class="c3">&nbsp;*</p>*';
P_Tag[993]='<p class="b1">&nbsp;*</p>*';
P_Tag[994]='<p class="c3">&nbsp;*</p>*';
P_Tag[995]='<p class="b1">&nbsp;*</p>*';
P_Tag[996]='<p class="c3">&nbsp;*</p>*';
P_Tag[997]='<p class="b1">&nbsp;*<span class="font10" id="M1207_71">[Pg.71]</span></p>*';
P_Tag[998]='<p class="c3">&nbsp;*</p>*';
P_Tag[999]='<p class="c3">&nbsp;*</p>*';
P_Tag[1000]='<p class="b1">&nbsp;*</p>*';
P_Tag[1001]='<p class="c3">&nbsp;*</p>*';
P_Tag[1002]='<p class="b1">&nbsp;*</p>*';
P_Tag[1003]='<p class="c3">&nbsp;*</p>*';
P_Tag[1004]='<p class="b1">&nbsp;*</p>*';
P_Tag[1005]='<p class="c3">&nbsp;*</p>*';
P_Tag[1006]='<p class="b1">&nbsp;*</p>*';
P_Tag[1007]='<p class="c3">&nbsp;*</p>*';
P_Tag[1008]='<p class="b1">&nbsp;*</p>*';
P_Tag[1009]='<p class="c3">&nbsp;*</p>*';
P_Tag[1010]='<p class="b1">&nbsp;*<span class="font10" id="M1207_72">[Pg.72]</span></p>*';
P_Tag[1011]='<p class="c3">&nbsp;*</p>*';
P_Tag[1012]='<p class="b1">&nbsp;*</p>*';
P_Tag[1013]='<p class="c3">&nbsp;*</p>*';
P_Tag[1014]='<p class="b1">&nbsp;*</p>*';
P_Tag[1015]='<p class="c3">&nbsp;*</p>*';
P_Tag[1016]='<p class="b1">&nbsp;*</p>*';
P_Tag[1017]='<p class="c3">&nbsp;*</p>*';
P_Tag[1018]='<p class="b1">&nbsp;*</p>*';
P_Tag[1019]='<p class="c3">&nbsp;*</p>*';
P_Tag[1020]='<p class="b1">&nbsp;*</p>*';
P_Tag[1021]='<p class="c3">&nbsp;*</p>*';
P_Tag[1022]='<p class="sc">&nbsp;*</p>*';
P_Tag[1023]='<p class="c3">&nbsp;*</p>*';
P_Tag[1024]='<p class="c3">&nbsp;*</p>*';
P_Tag[1025]='<p class="c3">&nbsp;*</p>*';
P_Tag[1026]='<p class="b1">&nbsp;*<span class="font10" id="M1207_73">[Pg.73]</span></p>*';
P_Tag[1027]='<p class="c3">&nbsp;*</p>*';
P_Tag[1028]='<p class="b1">&nbsp;*</p>*';
P_Tag[1029]='<p class="c3">&nbsp;*</p>*';
P_Tag[1030]='<p class="b1">&nbsp;*</p>*';
P_Tag[1031]='<p class="c3">&nbsp;*</p>*';
P_Tag[1032]='<p class="b1">&nbsp;*</p>*';
P_Tag[1033]='<p class="b1">&nbsp;*</p>*';
P_Tag[1034]='<p class="b1">&nbsp;*</p>*';
P_Tag[1035]='<p class="c3">&nbsp;*</p>*';
P_Tag[1036]='<p class="b1">&nbsp;*</p>*';
P_Tag[1037]='<p class="c3">&nbsp;*</p>*';
P_Tag[1038]='<p class="b1">&nbsp;*</p>*';
P_Tag[1039]='<p class="c3">&nbsp;*</p>*';
P_Tag[1040]='<p class="b1">&nbsp;*</p>*';
P_Tag[1041]='<p class="b1">&nbsp;*<span class="font10" id="M1207_74">[Pg.74]</span></p>*';
P_Tag[1042]='<p class="c3">&nbsp;*</p>*';
P_Tag[1043]='<p class="sc">&nbsp;*</p>*';
P_Tag[1044]='<p class="c3">&nbsp;*</p>*';
P_Tag[1045]='<p class="c3">&nbsp;*</p>*';
P_Tag[1046]='<p class="b1">&nbsp;*</p>*';
P_Tag[1047]='<p class="b1">&nbsp;*</p>*';
P_Tag[1048]='<p class="c3">&nbsp;*</p>*';
P_Tag[1049]='<p class="b1">&nbsp;*</p>*';
P_Tag[1050]='<p class="b1">&nbsp;*</p>*';
P_Tag[1051]='<p class="c3">&nbsp;*</p>*';
P_Tag[1052]='<p class="b1">&nbsp;*</p>*';
P_Tag[1053]='<p class="b1">&nbsp;*</p>*';
P_Tag[1054]='<p class="c3">&nbsp;*</p>*';
P_Tag[1055]='<p class="b1">&nbsp;*</p>*';
P_Tag[1056]='<p class="b1">&nbsp;*</p>*';
P_Tag[1057]='<p class="c3">&nbsp;*</p>*';
P_Tag[1058]='<p class="b1">&nbsp;*</p>*';
P_Tag[1059]='<p class="b1">&nbsp;*</p>*';
P_Tag[1060]='<p class="c3">&nbsp;*</p>*';
P_Tag[1061]='<p class="c3">&nbsp;*</p>*';
P_Tag[1062]='<p class="b1">&nbsp;*<span class="font10" id="M1207_75">[Pg.75]</span></p>*';
P_Tag[1063]='<p class="b1">&nbsp;*</p>*';
P_Tag[1064]='<p class="b1">&nbsp;*</p>*';
P_Tag[1065]='<p class="b1">&nbsp;*</p>*';
P_Tag[1066]='<p class="b1">&nbsp;*</p>*';
P_Tag[1067]='<p class="c3">&nbsp;*</p>*';
P_Tag[1068]='<p class="b1">&nbsp;*</p>*';
P_Tag[1069]='<p class="b1">&nbsp;*</p>*';
P_Tag[1070]='<p class="c3">&nbsp;*</p>*';
P_Tag[1071]='<p class="b1">&nbsp;*</p>*';
P_Tag[1072]='<p class="b1">&nbsp;*</p>*';
P_Tag[1073]='<p class="c3">&nbsp;*</p>*';
P_Tag[1074]='<p class="b1">&nbsp;*</p>*';
P_Tag[1075]='<p class="b1">&nbsp;*</p>*';
P_Tag[1076]='<p class="c3">&nbsp;*</p>*';
P_Tag[1077]='<p class="c3">&nbsp;*</p>*';
P_Tag[1078]='<p class="b1">&nbsp;*</p>*';
P_Tag[1079]='<p class="b1">&nbsp;*</p>*';
P_Tag[1080]='<p class="c3">&nbsp;*</p>*';
P_Tag[1081]='<p class="b1">&nbsp;*</p>*';
P_Tag[1082]='<p class="b1">&nbsp;*</p>*';
P_Tag[1083]='<p class="c3">&nbsp;*</p>*';
P_Tag[1084]='<p class="b1">&nbsp;*</p>*';
P_Tag[1085]='<p class="c3">&nbsp;*</p>*';
P_Tag[1086]='<p class="b1">&nbsp;*<span class="font10" id="M1207_76">[Pg.76]</span></p>*';
P_Tag[1087]='<p class="c3">&nbsp;*</p>*';
P_Tag[1088]='<p class="b1">&nbsp;*</p>*';
P_Tag[1089]='<p class="c3">&nbsp;*</p>*';
P_Tag[1090]='<p class="b1">&nbsp;*</p>*';
P_Tag[1091]='<p class="c3">&nbsp;*</p>*';
P_Tag[1092]='<p class="b1">&nbsp;*</p>*';
P_Tag[1093]='<p class="c3">&nbsp;*</p>*';
P_Tag[1094]='<p class="b1">&nbsp;*</p>*';
P_Tag[1095]='<p class="c3">&nbsp;*</p>*';
P_Tag[1096]='<p class="c3">&nbsp;*</p>*';
P_Tag[1097]='<p class="b1">&nbsp;*</p>*';
P_Tag[1098]='<p class="c3">&nbsp;*</p>*';
P_Tag[1099]='<p class="b1">&nbsp;*</p>*';
P_Tag[1100]='<p class="c3">&nbsp;*</p>*';
P_Tag[1101]='<p class="b1">&nbsp;*</p>*';
P_Tag[1102]='<p class="c3">&nbsp;*</p>*';
P_Tag[1103]='<p class="b1">&nbsp;*</p>*';
P_Tag[1104]='<p class="c3">&nbsp;*</p>*';
P_Tag[1105]='<p class="b1">&nbsp;*</p>*';
P_Tag[1106]='<p class="c3">&nbsp;*</p>*';
P_Tag[1107]='<p class="b1">&nbsp;*</p>*';
P_Tag[1108]='<p class="c3">&nbsp;*</p>*';
P_Tag[1109]='<p class="b1">&nbsp;*<span class="font10" id="M1207_77">[Pg.77]</span></p>*';
P_Tag[1110]='<p class="c3">&nbsp;*</p>*';
P_Tag[1111]='<p class="b1">&nbsp;*</p>*';
P_Tag[1112]='<p class="c3">&nbsp;*</p>*';
P_Tag[1113]='<p class="b1">&nbsp;*</p>*';
P_Tag[1114]='<p class="c3">&nbsp;*</p>*';
P_Tag[1115]='<p class="b1">&nbsp;*</p>*';
P_Tag[1116]='<p class="c3">&nbsp;*</p>*';
P_Tag[1117]='<p class="c3">&nbsp;*</p>*';
P_Tag[1118]='<p class="b1">&nbsp;*</p>*';
P_Tag[1119]='<p class="c3">&nbsp;*</p>*';
P_Tag[1120]='<p class="b1">&nbsp;*</p>*';
P_Tag[1121]='<p class="c3">&nbsp;*</p>*';
P_Tag[1122]='<p class="b1">&nbsp;*</p>*';
P_Tag[1123]='<p class="c3">&nbsp;*</p>*';
P_Tag[1124]='<p class="b1">&nbsp;*</p>*';
P_Tag[1125]='<p class="c3">&nbsp;*</p>*';
P_Tag[1126]='<p class="b1">&nbsp;*</p>*';
P_Tag[1127]='<p class="c3">&nbsp;*</p>*';
P_Tag[1128]='<p class="b1">&nbsp;*</p>*';
P_Tag[1129]='<p class="c3">&nbsp;*</p>*';
P_Tag[1130]='<p class="b1">&nbsp;*</p>*';
P_Tag[1131]='<p class="c3">&nbsp;*</p>*';
P_Tag[1132]='<p class="b1">&nbsp;*</p>*';
P_Tag[1133]='<p class="c3">&nbsp;*</p>*';
P_Tag[1134]='<p class="b1">&nbsp;*<span class="font10" id="M1207_78">[Pg.78]</span></p>*';
P_Tag[1135]='<p class="c3">&nbsp;*</p>*';
P_Tag[1136]='<p class="b1">&nbsp;*</p>*';
P_Tag[1137]='<p class="c3">&nbsp;*</p>*';
P_Tag[1138]='<p class="c3">&nbsp;*</p>*';
P_Tag[1139]='<p class="b1">&nbsp;*</p>*';
P_Tag[1140]='<p class="c3">&nbsp;*</p>*';
P_Tag[1141]='<p class="b1">&nbsp;*</p>*';
P_Tag[1142]='<p class="c3">&nbsp;*</p>*';
P_Tag[1143]='<p class="b1">&nbsp;*</p>*';
P_Tag[1144]='<p class="c3">&nbsp;*</p>*';
P_Tag[1145]='<p class="b1">&nbsp;*</p>*';
P_Tag[1146]='<p class="c3">&nbsp;*</p>*';
P_Tag[1147]='<p class="b1">&nbsp;*</p>*';
P_Tag[1148]='<p class="c3">&nbsp;*</p>*';
P_Tag[1149]='<p class="b1">&nbsp;*</p>*';
P_Tag[1150]='<p class="c3">&nbsp;*</p>*';
P_Tag[1151]='<p class="b1">&nbsp;*</p>*';
P_Tag[1152]='<p class="c3">&nbsp;*</p>*';
P_Tag[1153]='<p class="b1">&nbsp;*</p>*';
P_Tag[1154]='<p class="c3">&nbsp;*</p>*';
P_Tag[1155]='<p class="b1">&nbsp;*<span class="font10" id="M1207_79">[Pg.79]</span></p>*';
P_Tag[1156]='<p class="c3">&nbsp;*</p>*';
P_Tag[1157]='<p class="b1">&nbsp;*</p>*';
P_Tag[1158]='<p class="c3">&nbsp;*</p>*';
P_Tag[1159]='<p class="c3">&nbsp;*</p>*';
P_Tag[1160]='<p class="b1">&nbsp;*</p>*';
P_Tag[1161]='<p class="c3">&nbsp;*</p>*';
P_Tag[1162]='<p class="b1">&nbsp;*</p>*';
P_Tag[1163]='<p class="c3">&nbsp;*</p>*';
P_Tag[1164]='<p class="b1">&nbsp;*</p>*';
P_Tag[1165]='<p class="c3">&nbsp;*</p>*';
P_Tag[1166]='<p class="b1">&nbsp;*</p>*';
P_Tag[1167]='<p class="c3">&nbsp;*</p>*';
P_Tag[1168]='<p class="b1">&nbsp;*</p>*';
P_Tag[1169]='<p class="c3">&nbsp;*</p>*';
P_Tag[1170]='<p class="b1">&nbsp;*</p>*';
P_Tag[1171]='<p class="c3">&nbsp;*</p>*';
P_Tag[1172]='<p class="b1">&nbsp;*</p>*';
P_Tag[1173]='<p class="c3">&nbsp;*</p>*';
P_Tag[1174]='<p class="b1">&nbsp;*<span class="font10" id="M1207_80">[Pg.80]</span></p>*';
P_Tag[1175]='<p class="c3">&nbsp;*</p>*';
P_Tag[1176]='<p class="b1">&nbsp;*</p>*';
P_Tag[1177]='<p class="c3">&nbsp;*</p>*';
P_Tag[1178]='<p class="b1">&nbsp;*</p>*';
P_Tag[1179]='<p class="b1">&nbsp;*</p>*';
P_Tag[1180]='<p class="b1">&nbsp;*</p>*';
P_Tag[1181]='<p class="c3">&nbsp;*</p>*';
P_Tag[1182]='<p class="b1">&nbsp;*</p>*';
P_Tag[1183]='<p class="c3">&nbsp;*</p>*';
P_Tag[1184]='<p class="b1">&nbsp;*</p>*';
P_Tag[1185]='<p class="c3">&nbsp;*</p>*';
P_Tag[1186]='<p class="b1">&nbsp;*</p>*';
P_Tag[1187]='<p class="c3">&nbsp;*</p>*';
P_Tag[1188]='<p class="b1">&nbsp;*</p>*';
P_Tag[1189]='<p class="c3">&nbsp;*</p>*';
P_Tag[1190]='<p class="b1">&nbsp;*</p>*';
P_Tag[1191]='<p class="c3">&nbsp;*</p>*';
P_Tag[1192]='<p class="sc">&nbsp;*</p>*';
P_Tag[1193]='<p class="c3">&nbsp;*<span class="font10" id="M1207_81">[Pg.81]</span></p>*';
P_Tag[1194]='<p class="c3">&nbsp;*</p>*';
P_Tag[1195]='<p class="b1">&nbsp;*</p>*';
P_Tag[1196]='<p class="b1">&nbsp;*</p>*';
P_Tag[1197]='<p class="b1">&nbsp;*</p>*';
P_Tag[1198]='<p class="b1">&nbsp;*</p>*';
P_Tag[1199]='<p class="b1">&nbsp;*</p>*';
P_Tag[1200]='<p class="b1">&nbsp;*</p>*';
P_Tag[1201]='<p class="b1">&nbsp;*</p>*';
P_Tag[1202]='<p class="b1">&nbsp;*</p>*';
P_Tag[1203]='<p class="c3">&nbsp;*</p>*';
P_Tag[1204]='<p class="b1">&nbsp;*</p>*';
P_Tag[1205]='<p class="b1">&nbsp;*</p>*';
P_Tag[1206]='<p class="b1">&nbsp;*</p>*';
P_Tag[1207]='<p class="b1">&nbsp;*</p>*';
P_Tag[1208]='<p class="b1">&nbsp;*</p>*';
P_Tag[1209]='<p class="b1">&nbsp;*</p>*';
P_Tag[1210]='<p class="b1">&nbsp;*</p>*';
P_Tag[1211]='<p class="b1">&nbsp;*</p>*';
P_Tag[1212]='<p class="c3">&nbsp;*</p>*';
P_Tag[1213]='<p class="c3">&nbsp;*</p>*';
P_Tag[1214]='<p class="c3">&nbsp;*</p>*';
P_Tag[1215]='<p class="c4">&nbsp;*</p>*';
P_Tag[1216]='<p class="sd">&nbsp;*</p>*';
P_Tag[1217]='<p class="g5">&nbsp;*<span class="font10" id="P1207_1">[PTS.1]</span><span class="font10" id="M1207_83">[Pg.83]</span></p>*';
P_Tag[1218]='<p class="g8">&nbsp;*</p>*';
P_Tag[1219]='<p class="g5">&nbsp;*</p>*';
P_Tag[1220]='<p class="g8">&nbsp;*</p>*';
P_Tag[1221]='<p class="g5">&nbsp;*</p>*';
P_Tag[1222]='<p class="g8">&nbsp;*</p>*';
P_Tag[1223]='<p class="g5">&nbsp;*</p>*';
P_Tag[1224]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1225]='<p class="g5">&nbsp;*</p>*';
P_Tag[1226]='<p class="g8">&nbsp;*</p>*';
P_Tag[1227]='<p class="g5">&nbsp;*</p>*';
P_Tag[1228]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1229]='<p class="c4">&nbsp;*</p>*';
P_Tag[1230]='<p class="b1">&nbsp;*<span class="font10" id="M1207_84">[Pg.84]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1231]='<p class="b1">&nbsp;*<span class="font10" id="P1207_2">[PTS.2]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_85">[Pg.85]</span></p>*';
P_Tag[1232]='<p class="g5">&nbsp;*</p>*';
P_Tag[1233]='<p class="g8">&nbsp;*</p>*';
P_Tag[1234]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1235]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_3">[PTS.3]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_86">[Pg.86]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1236]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_4">[PTS.4]</span><span class="font10" id="M1207_87">[Pg.87]</span></p>*';
P_Tag[1237]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1238]='<p class="g5">&nbsp;*</p>*';
P_Tag[1239]='<p class="g6">&nbsp;*</p>*';
P_Tag[1240]='<p class="g7">&nbsp;*</p>*';
P_Tag[1241]='<p class="g8">&nbsp;*</p>*';
P_Tag[1242]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1243]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1244]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_88">[Pg.88]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_5">[PTS.5]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1245]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_89">[Pg.89]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_6">[PTS.6]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1246]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1247]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_90">[Pg.90]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1248]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_7">[PTS.7]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_91">[Pg.91]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1249]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1250]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_8">[PTS.8]</span><span class="bld">*</span>*<span class="font10" id="M1207_92">[Pg.92]</span></p>*';
P_Tag[1251]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_9">[PTS.9]</span><span class="font10" id="M1207_93">[Pg.93]</span></p>*';
P_Tag[1252]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1253]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1254]='<p class="b1">&nbsp;*<span class="font10" id="M1207_94">[Pg.94]</span></p>*';
P_Tag[1255]='<p class="b1">&nbsp;*</p>*';
P_Tag[1256]='<p class="b1">&nbsp;*</p>*';
P_Tag[1257]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_10">[PTS.10]</span><span class="bld">*</span>*</p>*';
P_Tag[1258]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_95">[Pg.95]</span><span class="bld">*</span>*</p>*';
P_Tag[1259]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1260]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_11">[PTS.11]</span></p>*';
P_Tag[1261]='<p class="g5">&nbsp;*</p>*';
P_Tag[1262]='<p class="g8">&nbsp;*</p>*';
P_Tag[1263]='<p class="g5">&nbsp;*</p>*';
P_Tag[1264]='<p class="g8">&nbsp;*</p>*';
P_Tag[1265]='<p class="b1">&nbsp;*</p>*';
P_Tag[1266]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_96">[Pg.96]</span><span class="bld">*</span>*</p>*';
P_Tag[1267]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_12">[PTS.12]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_97">[Pg.97]</span></p>*';
P_Tag[1268]='<p class="b1">&nbsp;*<span class="font10" id="P1207_13">[PTS.13]</span></p>*';
P_Tag[1269]='<p class="b1">&nbsp;*<span class="font10" id="M1207_98">[Pg.98]</span></p>*';
P_Tag[1270]='<p class="g5">&nbsp;*<span class="font10" id="P1207_14">[PTS.14]</span><span class="font10" id="M1207_99">[Pg.99]</span></p>*';
P_Tag[1271]='<p class="g8">&nbsp;*</p>*';
P_Tag[1272]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1273]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1274]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_100">[Pg.100]</span></p>*';
P_Tag[1275]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1276]='<p class="c3">&nbsp;*</p>*';
P_Tag[1277]='<p class="g5">&nbsp;*</p>*';
P_Tag[1278]='<p class="g8">&nbsp;*</p>*';
P_Tag[1279]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1280]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_15">[PTS.15]</span></p>*';
P_Tag[1281]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1282]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1283]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1284]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_101">[Pg.101]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1285]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1286]='<p class="b1">&nbsp;*<span class="font10" id="P1207_16">[PTS.16]</span><span class="font10" id="M1207_102">[Pg.102]</span></p>*';
P_Tag[1287]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1288]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1289]='<p class="c3">&nbsp;*</p>*';
P_Tag[1290]='<p class="g5">&nbsp;*</p>*';
P_Tag[1291]='<p class="g6">&nbsp;*</p>*';
P_Tag[1292]='<p class="g7">&nbsp;*</p>*';
P_Tag[1293]='<p class="g8">&nbsp;*</p>*';
P_Tag[1294]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_103">[Pg.103]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_17">[PTS.17]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1295]='<p class="c3">&nbsp;*</p>*';
P_Tag[1296]='<p class="c3">&nbsp;*</p>*';
P_Tag[1297]='<p class="c4">&nbsp;*</p>*';
P_Tag[1298]='<p class="b1">&nbsp;*<span class="font10" id="M1207_104">[Pg.104]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1299]='<p class="sc">&nbsp;*</p>*';
P_Tag[1300]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1301]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1302]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_18">[PTS.18]</span><span class="bld">*</span>*<span class="font10" id="M1207_105">[Pg.105]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1303]='<p class="g5">&nbsp;*</p>*';
P_Tag[1304]='<p class="g8">&nbsp;*</p>*';
P_Tag[1305]='<p class="g5">&nbsp;*</p>*';
P_Tag[1306]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1307]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_106">[Pg.106]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_19">[PTS.19]</span><span class="bld">*</span>*</p>*';
P_Tag[1308]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1309]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1310]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_107">[Pg.107]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1311]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_20">[PTS.20]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1312]='<p class="b1">&nbsp;*<span class="font10" id="M1207_108">[Pg.108]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1313]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1314]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_21">[PTS.21]</span></p>*';
P_Tag[1315]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_109">[Pg.109]</span></p>*';
P_Tag[1316]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1317]='<p class="b1">&nbsp;*</p>*';
P_Tag[1318]='<p class="g5">&nbsp;*<span class="font10" id="P1207_22">[PTS.22]</span></p>*';
P_Tag[1319]='<p class="g8">&nbsp;*</p>*';
P_Tag[1320]='<p class="g5">&nbsp;*</p>*';
P_Tag[1321]='<p class="g8">&nbsp;*</p>*';
P_Tag[1322]='<p class="g5">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1323]='<p class="g8">&nbsp;*</p>*';
P_Tag[1324]='<p class="b1">&nbsp;*<span class="font10" id="M1207_110">[Pg.110]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1325]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_23">[PTS.23]</span><span class="bld">*</span>*<span class="font10" id="M1207_111">[Pg.111]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1326]='<p class="b1">&nbsp;*</p>*';
P_Tag[1327]='<p class="g5">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1328]='<p class="g8">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1329]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1330]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_112">[Pg.112]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_24">[PTS.24]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1331]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1332]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1333]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_113">[Pg.113]</span></p>*';
P_Tag[1334]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1335]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_25">[PTS.25]</span><span class="font10" id="M1207_114">[Pg.114]</span></p>*';
P_Tag[1336]='<p class="b1">&nbsp;*<span class="font10" id="P1207_26">[PTS.26]</span></p>*';
P_Tag[1337]='<p class="g5">&nbsp;*</p>*';
P_Tag[1338]='<p class="g8">&nbsp;*</p>*';
P_Tag[1339]='<p class="g5">&nbsp;*</p>*';
P_Tag[1340]='<p class="g8">&nbsp;*</p>*';
P_Tag[1341]='<p class="c3">&nbsp;*</p>*';
P_Tag[1342]='<p class="sc">&nbsp;*</p>*';
P_Tag[1343]='<p class="b1">&nbsp;*<span class="font10" id="M1207_115">[Pg.115]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1344]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_27">[PTS.27]</span><span class="font10" id="M1207_116">[Pg.116]</span></p>*';
P_Tag[1345]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1346]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_117">[Pg.117]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_28">[PTS.28]</span><span class="bld">*</span>*</p>*';
P_Tag[1347]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1348]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_118">[Pg.118]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1349]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_29">[PTS.29]</span></p>*';
P_Tag[1350]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_119">[Pg.119]</span></p>*';
P_Tag[1351]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1352]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_30">[PTS.30]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_120">[Pg.120]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1353]='<p class="b1">&nbsp;*</p>*';
P_Tag[1354]='<p class="c3">&nbsp;*</p>*';
P_Tag[1355]='<p class="sc">&nbsp;*</p>*';
P_Tag[1356]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_121">[Pg.121]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_31">[PTS.31]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1357]='<p class="c3">&nbsp;*</p>*';
P_Tag[1358]='<p class="g5">&nbsp;*</p>*';
P_Tag[1359]='<p class="g8">&nbsp;*</p>*';
P_Tag[1360]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_122">[Pg.122]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1361]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_32">[PTS.32]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_123">[Pg.123]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1362]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1363]='<p class="c3">&nbsp;*</p>*';
P_Tag[1364]='<p class="sc">&nbsp;*</p>*';
P_Tag[1365]='<p class="b1">&nbsp;*<span class="font10" id="P1207_33">[PTS.33]</span><span class="font10" id="M1207_124">[Pg.124]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_125">[Pg.125]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_34">[PTS.34]</span><span class="bld">*</span>*</p>*';
P_Tag[1366]='<p class="b1">&nbsp;*</p>*';
P_Tag[1367]='<p class="c3">&nbsp;*</p>*';
P_Tag[1368]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_126">[Pg.126]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_35">[PTS.35]</span><span class="bld">*</span>*</p>*';
P_Tag[1369]='<p class="c3">&nbsp;*</p>*';
P_Tag[1370]='<p class="c3">&nbsp;*</p>*';
P_Tag[1371]='<p class="c4">&nbsp;*</p>*';
P_Tag[1372]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_127">[Pg.127]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1373]='<p class="sc">&nbsp;*</p>*';
P_Tag[1374]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1375]='<p class="b1">&nbsp;*<span class="font10" id="M1207_128">[Pg.128]</span><span class="font10" id="P1207_36">[PTS.36]</span></p>*';
P_Tag[1376]='<p class="c3">&nbsp;*</p>*';
P_Tag[1377]='<p class="sc">&nbsp;*</p>*';
P_Tag[1378]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1379]='<p class="b1">&nbsp;*<span class="font10" id="M1207_129">[Pg.129]</span><span class="font10" id="P1207_37">[PTS.37]</span></p>*';
P_Tag[1380]='<p class="c3">&nbsp;*</p>*';
P_Tag[1381]='<p class="sc">&nbsp;*</p>*';
P_Tag[1382]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_130">[Pg.130]</span><span class="bld">*</span>*</p>*';
P_Tag[1383]='<p class="b1">&nbsp;*</p>*';
P_Tag[1384]='<p class="c3">&nbsp;*</p>*';
P_Tag[1385]='<p class="sc">&nbsp;*</p>*';
P_Tag[1386]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_38">[PTS.38]</span><span class="font10" id="M1207_131">[Pg.131]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1387]='<p class="b1">&nbsp;*</p>*';
P_Tag[1388]='<p class="c3">&nbsp;*</p>*';
P_Tag[1389]='<p class="sc">&nbsp;*</p>*';
P_Tag[1390]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_132">[Pg.132]</span><span class="bld">*</span>*<span class="font10" id="P1207_39">[PTS.39]</span><span class="bld">*</span>*</p>*';
P_Tag[1391]='<p class="b1">&nbsp;*<span class="font10" id="M1207_133">[Pg.133]</span></p>*';
P_Tag[1392]='<p class="c3">&nbsp;*</p>*';
P_Tag[1393]='<p class="b1">&nbsp;*<span class="font10" id="P1207_40">[PTS.40]</span></p>*';
P_Tag[1394]='<p class="c3">&nbsp;*</p>*';
P_Tag[1395]='<p class="sc">&nbsp;*</p>*';
P_Tag[1396]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_134">[Pg.134]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_41">[PTS.41]</span><span class="bld">*</span>*<span class="font10" id="M1207_135">[Pg.135]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1397]='<p class="b1">&nbsp;*<span class="font10" id="M1207_136">[Pg.136]</span></p>*';
P_Tag[1398]='<p class="c3">&nbsp;*</p>*';
P_Tag[1399]='<p class="sc">&nbsp;*</p>*';
P_Tag[1400]='<p class="b1">&nbsp;*<span class="font10" id="P1207_42">[PTS.42]</span><span class="bld">*</span>*</p>*';
P_Tag[1401]='<p class="b1">&nbsp;*</p>*';
P_Tag[1402]='<p class="c3">&nbsp;*</p>*';
P_Tag[1403]='<p class="sc">&nbsp;*</p>*';
P_Tag[1404]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_137">[Pg.137]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_43">[PTS.43]</span><span class="bld">*</span>*<span class="font10" id="M1207_138">[Pg.138]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1405]='<p class="b1">&nbsp;*<span class="font10" id="P1207_44">[PTS.44]</span><span class="font10" id="M1207_139">[Pg.139]</span></p>*';
P_Tag[1406]='<p class="c3">&nbsp;*</p>*';
P_Tag[1407]='<p class="sc">&nbsp;*</p>*';
P_Tag[1408]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_140">[Pg.140]</span><span class="font10" id="P1207_45">[PTS.45]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1409]='<p class="c3">&nbsp;*</p>*';
P_Tag[1410]='<p class="sc">&nbsp;*</p>*';
P_Tag[1411]='<p class="b1">&nbsp;*<span class="font10" id="M1207_141">[Pg.141]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_46">[PTS.46]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_142">[Pg.142]</span><span class="bld">*</span>*</p>*';
P_Tag[1412]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1413]='<p class="c3">&nbsp;*</p>*';
P_Tag[1414]='<p class="sc">&nbsp;*</p>*';
P_Tag[1415]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1416]='<p class="b1">&nbsp;*<span class="font10" id="P1207_47">[PTS.47]</span></p>*';
P_Tag[1417]='<p class="c3">&nbsp;*</p>*';
P_Tag[1418]='<p class="sc">&nbsp;*</p>*';
P_Tag[1419]='<p class="b1">&nbsp;*<span class="font10" id="M1207_143">[Pg.143]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1420]='<p class="b1">&nbsp;*</p>*';
P_Tag[1421]='<p class="c3">&nbsp;*</p>*';
P_Tag[1422]='<p class="sc">&nbsp;*</p>*';
P_Tag[1423]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_144">[Pg.144]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_48">[PTS.48]</span><span class="bld">*</span>*</p>*';
P_Tag[1424]='<p class="b1">&nbsp;*</p>*';
P_Tag[1425]='<p class="c3">&nbsp;*</p>*';
P_Tag[1426]='<p class="sc">&nbsp;*</p>*';
P_Tag[1427]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_145">[Pg.145]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1428]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_49">[PTS.49]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_146">[Pg.146]</span></p>*';
P_Tag[1429]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_50">[PTS.50]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1430]='<p class="b1">&nbsp;*<span class="font10" id="M1207_147">[Pg.147]</span></p>*';
P_Tag[1431]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_148">[Pg.148]</span><span class="bld">*</span>*<span class="font10" id="P1207_51">[PTS.51]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1432]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_149">[Pg.149]</span><span class="bld">*</span>*</p>*';
P_Tag[1433]='<p class="c3">&nbsp;*</p>*';
P_Tag[1434]='<p class="c3">&nbsp;*</p>*';
P_Tag[1435]='<p class="c4">&nbsp;*</p>*';
P_Tag[1436]='<p class="sc">&nbsp;*</p>*';
P_Tag[1437]='<p class="b1">&nbsp;*<span class="font10" id="P1207_52">[PTS.52]</span><span class="font10" id="M1207_150">[Pg.150]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1438]='<p class="b1">&nbsp;*<span class="font10" id="M1207_151">[Pg.151]</span><span class="font10" id="P1207_53">[PTS.53]</span></p>*';
P_Tag[1439]='<p class="c3">&nbsp;*</p>*';
P_Tag[1440]='<p class="sc">&nbsp;*</p>*';
P_Tag[1441]='<p class="b1">&nbsp;*</p>*';
P_Tag[1442]='<p class="c3">&nbsp;*</p>*';
P_Tag[1443]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1444]='<p class="c3">&nbsp;*</p>*';
P_Tag[1445]='<p class="c3">&nbsp;*</p>*';
P_Tag[1446]='<p class="c4">&nbsp;*</p>*';
P_Tag[1447]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1448]='<p class="te">&nbsp;*</p>*';
P_Tag[1449]='<p class="sc">&nbsp;*</p>*';
P_Tag[1450]='<p class="b1">&nbsp;*<span class="font10" id="M1207_152">[Pg.152]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_54">[PTS.54]</span><span class="font10" id="M1207_153">[Pg.153]</span></p>*';
P_Tag[1451]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_154">[Pg.154]</span><span class="font10" id="P1207_55">[PTS.55]</span></p>*';
P_Tag[1452]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_155">[Pg.155]</span><span class="font10" id="P1207_56">[PTS.56]</span></p>*';
P_Tag[1453]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_156">[Pg.156]</span><span class="font10" id="P1207_57">[PTS.57]</span></p>*';
P_Tag[1454]='<p class="b1">&nbsp;*<span class="font10" id="M1207_157">[Pg.157]</span></p>*';
P_Tag[1455]='<p class="b1">&nbsp;*<span class="font10" id="P1207_58">[PTS.58]</span></p>*';
P_Tag[1456]='<p class="c3">&nbsp;*</p>*';
P_Tag[1457]='<p class="sc">&nbsp;*</p>*';
P_Tag[1458]='<p class="b1">&nbsp;*<span class="font10" id="M1207_158">[Pg.158]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1459]='<p class="c3">&nbsp;*</p>*';
P_Tag[1460]='<p class="b1">&nbsp;*<span class="font10" id="P1207_59">[PTS.59]</span><span class="font10" id="M1207_159">[Pg.159]</span></p>*';
P_Tag[1461]='<p class="c3">&nbsp;*</p>*';
P_Tag[1462]='<p class="sc">&nbsp;*</p>*';
P_Tag[1463]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_160">[Pg.160]</span><span class="bld">*</span>*<span class="font10" id="P1207_60">[PTS.60]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1464]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_161">[Pg.161]</span></p>*';
P_Tag[1465]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_61">[PTS.61]</span></p>*';
P_Tag[1466]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1467]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_162">[Pg.162]</span></p>*';
P_Tag[1468]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1469]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_62">[PTS.62]</span></p>*';
P_Tag[1470]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1471]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_163">[Pg.163]</span><span class="bld">*</span>*</p>*';
P_Tag[1472]='<p class="c3">&nbsp;*</p>*';
P_Tag[1473]='<p class="b1">&nbsp;*</p>*';
P_Tag[1474]='<p class="c3">&nbsp;*</p>*';
P_Tag[1475]='<p class="sc">&nbsp;*</p>*';
P_Tag[1476]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_63">[PTS.63]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_164">[Pg.164]</span></p>*';
P_Tag[1477]='<p class="b1">&nbsp;*</p>*';
P_Tag[1478]='<p class="c3">&nbsp;*</p>*';
P_Tag[1479]='<p class="sc">&nbsp;*</p>*';
P_Tag[1480]='<p class="b1">&nbsp;*<span class="font10" id="M1207_165">[Pg.165]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_64">[PTS.64]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1481]='<p class="b1">&nbsp;*</p>*';
P_Tag[1482]='<p class="c3">&nbsp;*</p>*';
P_Tag[1483]='<p class="sc">&nbsp;*</p>*';
P_Tag[1484]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_166">[Pg.166]</span><span class="bld">*</span>*</p>*';
P_Tag[1485]='<p class="b1">&nbsp;*<span class="font10" id="P1207_65">[PTS.65]</span></p>*';
P_Tag[1486]='<p class="c3">&nbsp;*</p>*';
P_Tag[1487]='<p class="sc">&nbsp;*</p>*';
P_Tag[1488]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1489]='<p class="b1">&nbsp;*<span class="font10" id="M1207_167">[Pg.167]</span></p>*';
P_Tag[1490]='<p class="b1">&nbsp;*<span class="font10" id="P1207_66">[PTS.66]</span></p>*';
P_Tag[1491]='<p class="c3">&nbsp;*</p>*';
P_Tag[1492]='<p class="sc">&nbsp;*</p>*';
P_Tag[1493]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_168">[Pg.168]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1494]='<p class="b1">&nbsp;*</p>*';
P_Tag[1495]='<p class="c3">&nbsp;*</p>*';
P_Tag[1496]='<p class="sc">&nbsp;*</p>*';
P_Tag[1497]='<p class="b1">&nbsp;*<span class="font10" id="M1207_169">[Pg.169]</span><span class="font10" id="P1207_67">[PTS.67]</span></p>*';
P_Tag[1498]='<p class="c3">&nbsp;*</p>*';
P_Tag[1499]='<p class="sc">&nbsp;*</p>*';
P_Tag[1500]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1501]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_170">[Pg.170]</span><span class="bld">*</span>*<span class="font10" id="P1207_68">[PTS.68]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1502]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_171">[Pg.171]</span></p>*';
P_Tag[1503]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_69">[PTS.69]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1504]='<p class="b1">&nbsp;*</p>*';
P_Tag[1505]='<p class="c3">&nbsp;*</p>*';
P_Tag[1506]='<p class="c3">&nbsp;*</p>*';
P_Tag[1507]='<p class="te">&nbsp;*</p>*';
P_Tag[1508]='<p class="sc">&nbsp;*</p>*';
P_Tag[1509]='<p class="b1">&nbsp;*<span class="font10" id="M1207_172">[Pg.172]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1510]='<p class="b1">&nbsp;*</p>*';
P_Tag[1511]='<p class="c3">&nbsp;*</p>*';
P_Tag[1512]='<p class="sc">&nbsp;*</p>*';
P_Tag[1513]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1514]='<p class="c3">&nbsp;*</p>*';
P_Tag[1515]='<p class="sc">&nbsp;*</p>*';
P_Tag[1516]='<p class="b1">&nbsp;*<span class="font10" id="P1207_70">[PTS.70]</span><span class="font10" id="M1207_173">[Pg.173]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1517]='<p class="b1">&nbsp;*</p>*';
P_Tag[1518]='<p class="c3">&nbsp;*</p>*';
P_Tag[1519]='<p class="sc">&nbsp;*</p>*';
P_Tag[1520]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1521]='<p class="b1">&nbsp;*</p>*';
P_Tag[1522]='<p class="c3">&nbsp;*</p>*';
P_Tag[1523]='<p class="sc">&nbsp;*</p>*';
P_Tag[1524]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_174">[Pg.174]</span><span class="bld">*</span>*</p>*';
P_Tag[1525]='<p class="b1">&nbsp;*</p>*';
P_Tag[1526]='<p class="c3">&nbsp;*</p>*';
P_Tag[1527]='<p class="sc">&nbsp;*</p>*';
P_Tag[1528]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_71">[PTS.71]</span></p>*';
P_Tag[1529]='<p class="b1">&nbsp;*<span class="font10" id="M1207_175">[Pg.175]</span></p>*';
P_Tag[1530]='<p class="c3">&nbsp;*</p>*';
P_Tag[1531]='<p class="sc">&nbsp;*</p>*';
P_Tag[1532]='<p class="b1">&nbsp;*</p>*';
P_Tag[1533]='<p class="c3">&nbsp;*</p>*';
P_Tag[1534]='<p class="sc">&nbsp;*</p>*';
P_Tag[1535]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_72">[PTS.72]</span><span class="font10" id="M1207_176">[Pg.176]</span></p>*';
P_Tag[1536]='<p class="b1">&nbsp;*</p>*';
P_Tag[1537]='<p class="c3">&nbsp;*</p>*';
P_Tag[1538]='<p class="sc">&nbsp;*</p>*';
P_Tag[1539]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1540]='<p class="b1">&nbsp;*<span class="font10" id="M1207_177">[Pg.177]</span><span class="font10" id="P1207_73">[PTS.73]</span></p>*';
P_Tag[1541]='<p class="c3">&nbsp;*</p>*';
P_Tag[1542]='<p class="sc">&nbsp;*</p>*';
P_Tag[1543]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1544]='<p class="b1">&nbsp;*</p>*';
P_Tag[1545]='<p class="c3">&nbsp;*</p>*';
P_Tag[1546]='<p class="c3">&nbsp;*</p>*';
P_Tag[1547]='<p class="te">&nbsp;*</p>*';
P_Tag[1548]='<p class="sc">&nbsp;*</p>*';
P_Tag[1549]='<p class="b1">&nbsp;*<span class="font10" id="M1207_178">[Pg.178]</span><span class="bld">*</span>*<span class="font10" id="P1207_74">[PTS.74]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_179">[Pg.179]</span></p>*';
P_Tag[1550]='<p class="b1">&nbsp;*</p>*';
P_Tag[1551]='<p class="c3">&nbsp;*</p>*';
P_Tag[1552]='<p class="sc">&nbsp;*</p>*';
P_Tag[1553]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_75">[PTS.75]</span></p>*';
P_Tag[1554]='<p class="b1">&nbsp;*<span class="font10" id="M1207_180">[Pg.180]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1555]='<p class="b1">&nbsp;*<span class="font10" id="P1207_76">[PTS.76]</span></p>*';
P_Tag[1556]='<p class="c3">&nbsp;*</p>*';
P_Tag[1557]='<p class="sc">&nbsp;*</p>*';
P_Tag[1558]='<p class="b1">&nbsp;*<span class="font10" id="M1207_181">[Pg.181]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_182">[Pg.182]</span><span class="font10" id="P1207_77">[PTS.77]</span></p>*';
P_Tag[1559]='<p class="b1">&nbsp;*</p>*';
P_Tag[1560]='<p class="c3">&nbsp;*</p>*';
P_Tag[1561]='<p class="sc">&nbsp;*</p>*';
P_Tag[1562]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_183">[Pg.183]</span></p>*';
P_Tag[1563]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_78">[PTS.78]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1564]='<p class="b1">&nbsp;*<span class="font10" id="M1207_184">[Pg.184]</span></p>*';
P_Tag[1565]='<p class="c3">&nbsp;*</p>*';
P_Tag[1566]='<p class="sc">&nbsp;*</p>*';
P_Tag[1567]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1568]='<p class="b1">&nbsp;*</p>*';
P_Tag[1569]='<p class="c3">&nbsp;*</p>*';
P_Tag[1570]='<p class="sc">&nbsp;*</p>*';
P_Tag[1571]='<p class="b1">&nbsp;*<span class="font10" id="P1207_79">[PTS.79]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_185">[Pg.185]</span></p>*';
P_Tag[1572]='<p class="b1">&nbsp;*</p>*';
P_Tag[1573]='<p class="c3">&nbsp;*</p>*';
P_Tag[1574]='<p class="sc">&nbsp;*</p>*';
P_Tag[1575]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_186">[Pg.186]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_80">[PTS.80]</span><span class="bld">*</span>*</p>*';
P_Tag[1576]='<p class="b1">&nbsp;*</p>*';
P_Tag[1577]='<p class="c3">&nbsp;*</p>*';
P_Tag[1578]='<p class="sc">&nbsp;*</p>*';
P_Tag[1579]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_187">[Pg.187]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1580]='<p class="b1">&nbsp;*</p>*';
P_Tag[1581]='<p class="b1">&nbsp;*</p>*';
P_Tag[1582]='<p class="sc">&nbsp;*</p>*';
P_Tag[1583]='<p class="b1">&nbsp;*<span class="font10" id="P1207_81">[PTS.81]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_188">[Pg.188]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1584]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1585]='<p class="b1">&nbsp;*</p>*';
P_Tag[1586]='<p class="c3">&nbsp;*</p>*';
P_Tag[1587]='<p class="sc">&nbsp;*</p>*';
P_Tag[1588]='<p class="b1">&nbsp;*<span class="font10" id="P1207_82">[PTS.82]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_189">[Pg.189]</span><span class="bld">*</span>*</p>*';
P_Tag[1589]='<p class="b1">&nbsp;*</p>*';
P_Tag[1590]='<p class="c3">&nbsp;*</p>*';
P_Tag[1591]='<p class="c3">&nbsp;*</p>*';
P_Tag[1592]='<p class="c3">&nbsp;*</p>*';
P_Tag[1593]='<p class="c3">&nbsp;*</p>*';
P_Tag[1594]='<p class="c4">&nbsp;*</p>*';
P_Tag[1595]='<p class="te">&nbsp;*</p>*';
P_Tag[1596]='<p class="sc">&nbsp;*</p>*';
P_Tag[1597]='<p class="b1">&nbsp;*<span class="font10" id="M1207_190">[Pg.190]</span><span class="bld">*</span>*</p>*';
P_Tag[1598]='<p class="b1">&nbsp;*<span class="font10" id="P1207_83">[PTS.83]</span></p>*';
P_Tag[1599]='<p class="c3">&nbsp;*</p>*';
P_Tag[1600]='<p class="sc">&nbsp;*</p>*';
P_Tag[1601]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_191">[Pg.191]</span></p>*';
P_Tag[1602]='<p class="b1">&nbsp;*</p>*';
P_Tag[1603]='<p class="c3">&nbsp;*</p>*';
P_Tag[1604]='<p class="sc">&nbsp;*</p>*';
P_Tag[1605]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1606]='<p class="b1">&nbsp;*<span class="font10" id="M1207_192">[Pg.192]</span><span class="font10" id="P1207_84">[PTS.84]</span></p>*';
P_Tag[1607]='<p class="c3">&nbsp;*</p>*';
P_Tag[1608]='<p class="sc">&nbsp;*</p>*';
P_Tag[1609]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1610]='<p class="b1">&nbsp;*</p>*';
P_Tag[1611]='<p class="c3">&nbsp;*</p>*';
P_Tag[1612]='<p class="sc">&nbsp;*</p>*';
P_Tag[1613]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_193">[Pg.193]</span></p>*';
P_Tag[1614]='<p class="b1">&nbsp;*<span class="font10" id="P1207_85">[PTS.85]</span></p>*';
P_Tag[1615]='<p class="c3">&nbsp;*</p>*';
P_Tag[1616]='<p class="sc">&nbsp;*</p>*';
P_Tag[1617]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1618]='<p class="b1">&nbsp;*<span class="font10" id="M1207_194">[Pg.194]</span></p>*';
P_Tag[1619]='<p class="c3">&nbsp;*</p>*';
P_Tag[1620]='<p class="sc">&nbsp;*</p>*';
P_Tag[1621]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1622]='<p class="b1">&nbsp;*<span class="font10" id="P1207_86">[PTS.86]</span></p>*';
P_Tag[1623]='<p class="c3">&nbsp;*</p>*';
P_Tag[1624]='<p class="sc">&nbsp;*</p>*';
P_Tag[1625]='<p class="b1">&nbsp;*<span class="font10" id="M1207_195">[Pg.195]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1626]='<p class="b1">&nbsp;*</p>*';
P_Tag[1627]='<p class="c3">&nbsp;*</p>*';
P_Tag[1628]='<p class="sc">&nbsp;*</p>*';
P_Tag[1629]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1630]='<p class="b1">&nbsp;*<span class="font10" id="M1207_196">[Pg.196]</span><span class="font10" id="P1207_87">[PTS.87]</span></p>*';
P_Tag[1631]='<p class="c3">&nbsp;*</p>*';
P_Tag[1632]='<p class="sc">&nbsp;*</p>*';
P_Tag[1633]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_197">[Pg.197]</span></p>*';
P_Tag[1634]='<p class="b1">&nbsp;*<span class="font10" id="P1207_88">[PTS.88]</span></p>*';
P_Tag[1635]='<p class="c3">&nbsp;*</p>*';
P_Tag[1636]='<p class="c3">&nbsp;*</p>*';
P_Tag[1637]='<p class="te">&nbsp;*</p>*';
P_Tag[1638]='<p class="sc">&nbsp;*</p>*';
P_Tag[1639]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_198">[Pg.198]</span></p>*';
P_Tag[1640]='<p class="b1">&nbsp;*</p>*';
P_Tag[1641]='<p class="b1">&nbsp;*<span class="font10" id="P1207_89">[PTS.89]</span><span class="font10" id="M1207_199">[Pg.199]</span></p>*';
P_Tag[1642]='<p class="c3">&nbsp;*</p>*';
P_Tag[1643]='<p class="sc">&nbsp;*</p>*';
P_Tag[1644]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1645]='<p class="b1">&nbsp;*<span class="font10" id="P1207_90">[PTS.90]</span><span class="font10" id="M1207_200">[Pg.200]</span></p>*';
P_Tag[1646]='<p class="c3">&nbsp;*</p>*';
P_Tag[1647]='<p class="sc">&nbsp;*</p>*';
P_Tag[1648]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1649]='<p class="b1">&nbsp;*</p>*';
P_Tag[1650]='<p class="c3">&nbsp;*</p>*';
P_Tag[1651]='<p class="sc">&nbsp;*</p>*';
P_Tag[1652]='<p class="b1">&nbsp;*<span class="font10" id="M1207_201">[Pg.201]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_91">[PTS.91]</span></p>*';
P_Tag[1653]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_202">[Pg.202]</span></p>*';
P_Tag[1654]='<p class="b1">&nbsp;*<span class="font10" id="P1207_92">[PTS.92]</span></p>*';
P_Tag[1655]='<p class="c3">&nbsp;*</p>*';
P_Tag[1656]='<p class="sc">&nbsp;*</p>*';
P_Tag[1657]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_203">[Pg.203]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1658]='<p class="b1">&nbsp;*<span class="font10" id="P1207_93">[PTS.93]</span><span class="font10" id="M1207_204">[Pg.204]</span></p>*';
P_Tag[1659]='<p class="c3">&nbsp;*</p>*';
P_Tag[1660]='<p class="sc">&nbsp;*</p>*';
P_Tag[1661]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1662]='<p class="b1">&nbsp;*<span class="font10" id="M1207_205">[Pg.205]</span></p>*';
P_Tag[1663]='<p class="c3">&nbsp;*</p>*';
P_Tag[1664]='<p class="sc">&nbsp;*</p>*';
P_Tag[1665]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_94">[PTS.94]</span></p>*';
P_Tag[1666]='<p class="c3">&nbsp;*</p>*';
P_Tag[1667]='<p class="b1">&nbsp;*<span class="font10" id="M1207_206">[Pg.206]</span></p>*';
P_Tag[1668]='<p class="c3">&nbsp;*</p>*';
P_Tag[1669]='<p class="sc">&nbsp;*</p>*';
P_Tag[1670]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1671]='<p class="b1">&nbsp;*<span class="font10" id="P1207_95">[PTS.95]</span><span class="font10" id="M1207_207">[Pg.207]</span></p>*';
P_Tag[1672]='<p class="c3">&nbsp;*</p>*';
P_Tag[1673]='<p class="sc">&nbsp;*</p>*';
P_Tag[1674]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1675]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_96">[PTS.96]</span><span class="font10" id="M1207_208">[Pg.208]</span><span class="bld">*</span>*</p>*';
P_Tag[1676]='<p class="b1">&nbsp;*</p>*';
P_Tag[1677]='<p class="c3">&nbsp;*</p>*';
P_Tag[1678]='<p class="sc">&nbsp;*</p>*';
P_Tag[1679]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_209">[Pg.209]</span></p>*';
P_Tag[1680]='<p class="b1">&nbsp;*<span class="font10" id="P1207_97">[PTS.97]</span></p>*';
P_Tag[1681]='<p class="c3">&nbsp;*</p>*';
P_Tag[1682]='<p class="c3">&nbsp;*</p>*';
P_Tag[1683]='<p class="te">&nbsp;*</p>*';
P_Tag[1684]='<p class="sc">&nbsp;*</p>*';
P_Tag[1685]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1686]='<p class="b1">&nbsp;*<span class="font10" id="M1207_210">[Pg.210]</span></p>*';
P_Tag[1687]='<p class="c3">&nbsp;*</p>*';
P_Tag[1688]='<p class="sc">&nbsp;*</p>*';
P_Tag[1689]='<p class="b1">&nbsp;*<span class="font10" id="P1207_98">[PTS.98]</span><span class="bld">*</span>*</p>*';
P_Tag[1690]='<p class="b1">&nbsp;*</p>*';
P_Tag[1691]='<p class="c3">&nbsp;*</p>*';
P_Tag[1692]='<p class="sc">&nbsp;*</p>*';
P_Tag[1693]='<p class="b1">&nbsp;*<span class="font10" id="M1207_211">[Pg.211]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1694]='<p class="b1">&nbsp;*</p>*';
P_Tag[1695]='<p class="c3">&nbsp;*</p>*';
P_Tag[1696]='<p class="sc">&nbsp;*</p>*';
P_Tag[1697]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1698]='<p class="b1">&nbsp;*<span class="font10" id="P1207_99">[PTS.99]</span><span class="font10" id="M1207_212">[Pg.212]</span></p>*';
P_Tag[1699]='<p class="c3">&nbsp;*</p>*';
P_Tag[1700]='<p class="sc">&nbsp;*</p>*';
P_Tag[1701]='<p class="b1">&nbsp;*</p>*';
P_Tag[1702]='<p class="c3">&nbsp;*</p>*';
P_Tag[1703]='<p class="sc">&nbsp;*</p>*';
P_Tag[1704]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1705]='<p class="b1">&nbsp;*<span class="font10" id="M1207_213">[Pg.213]</span></p>*';
P_Tag[1706]='<p class="c3">&nbsp;*</p>*';
P_Tag[1707]='<p class="sc">&nbsp;*</p>*';
P_Tag[1708]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_100">[PTS.100]</span></p>*';
P_Tag[1709]='<p class="b1">&nbsp;*</p>*';
P_Tag[1710]='<p class="c3">&nbsp;*</p>*';
P_Tag[1711]='<p class="sc">&nbsp;*</p>*';
P_Tag[1712]='<p class="b1">&nbsp;*<span class="font10" id="M1207_214">[Pg.214]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1713]='<p class="b1">&nbsp;*</p>*';
P_Tag[1714]='<p class="c3">&nbsp;*</p>*';
P_Tag[1715]='<p class="sc">&nbsp;*</p>*';
P_Tag[1716]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_101">[PTS.101]</span></p>*';
P_Tag[1717]='<p class="b1">&nbsp;*<span class="font10" id="M1207_215">[Pg.215]</span></p>*';
P_Tag[1718]='<p class="c3">&nbsp;*</p>*';
P_Tag[1719]='<p class="sc">&nbsp;*</p>*';
P_Tag[1720]='<p class="b1">&nbsp;*</p>*';
P_Tag[1721]='<p class="c3">&nbsp;*</p>*';
P_Tag[1722]='<p class="c3">&nbsp;*</p>*';
P_Tag[1723]='<p class="te">&nbsp;*</p>*';
P_Tag[1724]='<p class="sc">&nbsp;*</p>*';
P_Tag[1725]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1726]='<p class="b1">&nbsp;*<span class="font10" id="M1207_216">[Pg.216]</span><span class="font10" id="P1207_102">[PTS.102]</span></p>*';
P_Tag[1727]='<p class="c3">&nbsp;*</p>*';
P_Tag[1728]='<p class="sc">&nbsp;*</p>*';
P_Tag[1729]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_217">[Pg.217]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1730]='<p class="b1">&nbsp;*<span class="font10" id="P1207_103">[PTS.103]</span></p>*';
P_Tag[1731]='<p class="c3">&nbsp;*</p>*';
P_Tag[1732]='<p class="sc">&nbsp;*</p>*';
P_Tag[1733]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1734]='<p class="b1">&nbsp;*<span class="font10" id="M1207_218">[Pg.218]</span></p>*';
P_Tag[1735]='<p class="c3">&nbsp;*</p>*';
P_Tag[1736]='<p class="sc">&nbsp;*</p>*';
P_Tag[1737]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_104">[PTS.104]</span><span class="bld">*</span>*<span class="font10" id="M1207_219">[Pg.219]</span></p>*';
P_Tag[1738]='<p class="b1">&nbsp;*</p>*';
P_Tag[1739]='<p class="c3">&nbsp;*</p>*';
P_Tag[1740]='<p class="sc">&nbsp;*</p>*';
P_Tag[1741]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1742]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_220">[Pg.220]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_105">[PTS.105]</span><span class="bld">*</span>*</p>*';
P_Tag[1743]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_221">[Pg.221]</span><span class="bld">*</span>*<span class="font10" id="P1207_106">[PTS.106]</span></p>*';
P_Tag[1744]='<p class="b1">&nbsp;*<span class="font10" id="M1207_222">[Pg.222]</span></p>*';
P_Tag[1745]='<p class="b1">&nbsp;*<span class="font10" id="P1207_107">[PTS.107]</span></p>*';
P_Tag[1746]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_223">[Pg.223]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1747]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_108">[PTS.108]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1748]='<p class="b1">&nbsp;*<span class="font10" id="M1207_224">[Pg.224]</span></p>*';
P_Tag[1749]='<p class="c3">&nbsp;*</p>*';
P_Tag[1750]='<p class="sc">&nbsp;*</p>*';
P_Tag[1751]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1752]='<p class="b1">&nbsp;*</p>*';
P_Tag[1753]='<p class="c3">&nbsp;*</p>*';
P_Tag[1754]='<p class="sc">&nbsp;*</p>*';
P_Tag[1755]='<p class="b1">&nbsp;*<span class="font10" id="P1207_109">[PTS.109]</span><span class="font10" id="M1207_225">[Pg.225]</span><span class="bld">*</span>*</p>*';
P_Tag[1756]='<p class="b1">&nbsp;*</p>*';
P_Tag[1757]='<p class="c3">&nbsp;*</p>*';
P_Tag[1758]='<p class="sc">&nbsp;*</p>*';
P_Tag[1759]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_226">[Pg.226]</span></p>*';
P_Tag[1760]='<p class="b1">&nbsp;*<span class="font10" id="P1207_110">[PTS.110]</span></p>*';
P_Tag[1761]='<p class="b1">&nbsp;*<span class="font10" id="M1207_227">[Pg.227]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_111">[PTS.111]</span></p>*';
P_Tag[1762]='<p class="c3">&nbsp;*</p>*';
P_Tag[1763]='<p class="sc">&nbsp;*</p>*';
P_Tag[1764]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_228">[Pg.228]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1765]='<p class="b1">&nbsp;*<span class="font10" id="P1207_112">[PTS.112]</span><span class="font10" id="M1207_229">[Pg.229]</span></p>*';
P_Tag[1766]='<p class="c3">&nbsp;*</p>*';
P_Tag[1767]='<p class="sc">&nbsp;*</p>*';
P_Tag[1768]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_230">[Pg.230]</span></p>*';
P_Tag[1769]='<p class="b1">&nbsp;*<span class="font10" id="P1207_113">[PTS.113]</span><span class="font10" id="M1207_231">[Pg.231]</span></p>*';
P_Tag[1770]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_114">[PTS.114]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1771]='<p class="b1">&nbsp;*<span class="font10" id="M1207_232">[Pg.232]</span></p>*';
P_Tag[1772]='<p class="c3">&nbsp;*</p>*';
P_Tag[1773]='<p class="c3">&nbsp;*</p>*';
P_Tag[1774]='<p class="te">&nbsp;*</p>*';
P_Tag[1775]='<p class="sc">&nbsp;*</p>*';
P_Tag[1776]='<p class="b1">&nbsp;*</p>*';
P_Tag[1777]='<p class="b1">&nbsp;*<span class="font10" id="P1207_115">[PTS.115]</span></p>*';
P_Tag[1778]='<p class="c3">&nbsp;*</p>*';
P_Tag[1779]='<p class="sc">&nbsp;*</p>*';
P_Tag[1780]='<p class="b1">&nbsp;*<span class="font10" id="M1207_233">[Pg.233]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1781]='<p class="b1">&nbsp;*</p>*';
P_Tag[1782]='<p class="c3">&nbsp;*</p>*';
P_Tag[1783]='<p class="sc">&nbsp;*</p>*';
P_Tag[1784]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1785]='<p class="b1">&nbsp;*<span class="font10" id="M1207_234">[Pg.234]</span><span class="font10" id="P1207_116">[PTS.116]</span></p>*';
P_Tag[1786]='<p class="c3">&nbsp;*</p>*';
P_Tag[1787]='<p class="sc">&nbsp;*</p>*';
P_Tag[1788]='<p class="b1">&nbsp;*</p>*';
P_Tag[1789]='<p class="c3">&nbsp;*</p>*';
P_Tag[1790]='<p class="sc">&nbsp;*</p>*';
P_Tag[1791]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_235">[Pg.235]</span></p>*';
P_Tag[1792]='<p class="b1">&nbsp;*</p>*';
P_Tag[1793]='<p class="c3">&nbsp;*</p>*';
P_Tag[1794]='<p class="sc">&nbsp;*</p>*';
P_Tag[1795]='<p class="b1">&nbsp;*<span class="font10" id="P1207_117">[PTS.117]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1796]='<p class="b1">&nbsp;*<span class="font10" id="M1207_236">[Pg.236]</span></p>*';
P_Tag[1797]='<p class="c3">&nbsp;*</p>*';
P_Tag[1798]='<p class="sc">&nbsp;*</p>*';
P_Tag[1799]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1800]='<p class="b1">&nbsp;*<span class="font10" id="P1207_118">[PTS.118]</span></p>*';
P_Tag[1801]='<p class="c3">&nbsp;*</p>*';
P_Tag[1802]='<p class="sc">&nbsp;*</p>*';
P_Tag[1803]='<p class="b1">&nbsp;*<span class="font10" id="M1207_237">[Pg.237]</span><span class="bld">*</span>*</p>*';
P_Tag[1804]='<p class="b1">&nbsp;*</p>*';
P_Tag[1805]='<p class="c3">&nbsp;*</p>*';
P_Tag[1806]='<p class="sc">&nbsp;*</p>*';
P_Tag[1807]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1808]='<p class="c3">&nbsp;*</p>*';
P_Tag[1809]='<p class="c3">&nbsp;*</p>*';
P_Tag[1810]='<p class="te">&nbsp;*</p>*';
P_Tag[1811]='<p class="sc">&nbsp;*</p>*';
P_Tag[1812]='<p class="b1">&nbsp;*<span class="font10" id="M1207_238">[Pg.238]</span><span class="bld">*</span>*</p>*';
P_Tag[1813]='<p class="b1">&nbsp;*<span class="font10" id="P1207_119">[PTS.119]</span></p>*';
P_Tag[1814]='<p class="c3">&nbsp;*</p>*';
P_Tag[1815]='<p class="sc">&nbsp;*</p>*';
P_Tag[1816]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1817]='<p class="b1">&nbsp;*</p>*';
P_Tag[1818]='<p class="c3">&nbsp;*</p>*';
P_Tag[1819]='<p class="sc">&nbsp;*</p>*';
P_Tag[1820]='<p class="b1">&nbsp;*<span class="font10" id="M1207_239">[Pg.239]</span><span class="bld">*</span>*</p>*';
P_Tag[1821]='<p class="b1">&nbsp;*</p>*';
P_Tag[1822]='<p class="c3">&nbsp;*</p>*';
P_Tag[1823]='<p class="sc">&nbsp;*</p>*';
P_Tag[1824]='<p class="b1">&nbsp;*<span class="font10" id="P1207_120">[PTS.120]</span><span class="bld">*</span>*</p>*';
P_Tag[1825]='<p class="b1">&nbsp;*<span class="font10" id="M1207_240">[Pg.240]</span></p>*';
P_Tag[1826]='<p class="c3">&nbsp;*</p>*';
P_Tag[1827]='<p class="sc">&nbsp;*</p>*';
P_Tag[1828]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1829]='<p class="b1">&nbsp;*</p>*';
P_Tag[1830]='<p class="c3">&nbsp;*</p>*';
P_Tag[1831]='<p class="sc">&nbsp;*</p>*';
P_Tag[1832]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1833]='<p class="b1">&nbsp;*<span class="font10" id="M1207_241">[Pg.241]</span><span class="font10" id="P1207_121">[PTS.121]</span></p>*';
P_Tag[1834]='<p class="c3">&nbsp;*</p>*';
P_Tag[1835]='<p class="sc">&nbsp;*</p>*';
P_Tag[1836]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1837]='<p class="b1">&nbsp;*<span class="font10" id="M1207_242">[Pg.242]</span></p>*';
P_Tag[1838]='<p class="c3">&nbsp;*</p>*';
P_Tag[1839]='<p class="sc">&nbsp;*</p>*';
P_Tag[1840]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1841]='<p class="b1">&nbsp;*<span class="font10" id="P1207_122">[PTS.122]</span></p>*';
P_Tag[1842]='<p class="c3">&nbsp;*</p>*';
P_Tag[1843]='<p class="sc">&nbsp;*</p>*';
P_Tag[1844]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_243">[Pg.243]</span></p>*';
P_Tag[1845]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_123">[PTS.123]</span><span class="font10" id="M1207_244">[Pg.244]</span></p>*';
P_Tag[1846]='<p class="b1">&nbsp;*</p>*';
P_Tag[1847]='<p class="c3">&nbsp;*</p>*';
P_Tag[1848]='<p class="sc">&nbsp;*</p>*';
P_Tag[1849]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1850]='<p class="b1">&nbsp;*</p>*';
P_Tag[1851]='<p class="c3">&nbsp;*</p>*';
P_Tag[1852]='<p class="c3">&nbsp;*</p>*';
P_Tag[1853]='<p class="te">&nbsp;*</p>*';
P_Tag[1854]='<p class="sc">&nbsp;*</p>*';
P_Tag[1855]='<p class="b1">&nbsp;*<span class="font10" id="M1207_245">[Pg.245]</span><span class="bld">*</span>*</p>*';
P_Tag[1856]='<p class="b1">&nbsp;*<span class="font10" id="P1207_124">[PTS.124]</span></p>*';
P_Tag[1857]='<p class="c3">&nbsp;*</p>*';
P_Tag[1858]='<p class="sc">&nbsp;*</p>*';
P_Tag[1859]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1860]='<p class="b1">&nbsp;*</p>*';
P_Tag[1861]='<p class="c3">&nbsp;*</p>*';
P_Tag[1862]='<p class="sc">&nbsp;*</p>*';
P_Tag[1863]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_246">[Pg.246]</span></p>*';
P_Tag[1864]='<p class="b1">&nbsp;*</p>*';
P_Tag[1865]='<p class="c3">&nbsp;*</p>*';
P_Tag[1866]='<p class="sc">&nbsp;*</p>*';
P_Tag[1867]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_125">[PTS.125]</span></p>*';
P_Tag[1868]='<p class="b1">&nbsp;*<span class="font10" id="M1207_247">[Pg.247]</span></p>*';
P_Tag[1869]='<p class="c3">&nbsp;*</p>*';
P_Tag[1870]='<p class="sc">&nbsp;*</p>*';
P_Tag[1871]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1872]='<p class="b1">&nbsp;*<span class="font10" id="P1207_126">[PTS.126]</span></p>*';
P_Tag[1873]='<p class="c3">&nbsp;*</p>*';
P_Tag[1874]='<p class="sc">&nbsp;*</p>*';
P_Tag[1875]='<p class="b1">&nbsp;*<span class="font10" id="M1207_248">[Pg.248]</span><span class="bld">*</span>*</p>*';
P_Tag[1876]='<p class="b1">&nbsp;*</p>*';
P_Tag[1877]='<p class="c3">&nbsp;*</p>*';
P_Tag[1878]='<p class="sc">&nbsp;*</p>*';
P_Tag[1879]='<p class="b1">&nbsp;*</p>*';
P_Tag[1880]='<p class="c3">&nbsp;*</p>*';
P_Tag[1881]='<p class="sc">&nbsp;*</p>*';
P_Tag[1882]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_249">[Pg.249]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_127">[PTS.127]</span></p>*';
P_Tag[1883]='<p class="b1">&nbsp;*</p>*';
P_Tag[1884]='<p class="c3">&nbsp;*</p>*';
P_Tag[1885]='<p class="sc">&nbsp;*</p>*';
P_Tag[1886]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_250">[Pg.250]</span><span class="bld">*</span>*</p>*';
P_Tag[1887]='<p class="b1">&nbsp;*</p>*';
P_Tag[1888]='<p class="c3">&nbsp;*</p>*';
P_Tag[1889]='<p class="sc">&nbsp;*</p>*';
P_Tag[1890]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_128">[PTS.128]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_251">[Pg.251]</span></p>*';
P_Tag[1891]='<p class="b1">&nbsp;*</p>*';
P_Tag[1892]='<p class="c3">&nbsp;*</p>*';
P_Tag[1893]='<p class="c3">&nbsp;*</p>*';
P_Tag[1894]='<p class="te">&nbsp;*</p>*';
P_Tag[1895]='<p class="sc">&nbsp;*</p>*';
P_Tag[1896]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1897]='<p class="b1">&nbsp;*</p>*';
P_Tag[1898]='<p class="c3">&nbsp;*</p>*';
P_Tag[1899]='<p class="sc">&nbsp;*</p>*';
P_Tag[1900]='<p class="b1">&nbsp;*<span class="font10" id="M1207_252">[Pg.252]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_129">[PTS.129]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1901]='<p class="b1">&nbsp;*</p>*';
P_Tag[1902]='<p class="c3">&nbsp;*</p>*';
P_Tag[1903]='<p class="sc">&nbsp;*</p>*';
P_Tag[1904]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_253">[Pg.253]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1905]='<p class="b1">&nbsp;*</p>*';
P_Tag[1906]='<p class="c3">&nbsp;*</p>*';
P_Tag[1907]='<p class="sc">&nbsp;*</p>*';
P_Tag[1908]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1909]='<p class="b1">&nbsp;*<span class="font10" id="P1207_130">[PTS.130]</span></p>*';
P_Tag[1910]='<p class="c3">&nbsp;*</p>*';
P_Tag[1911]='<p class="sc">&nbsp;*</p>*';
P_Tag[1912]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_254">[Pg.254]</span></p>*';
P_Tag[1913]='<p class="c3">&nbsp;*</p>*';
P_Tag[1914]='<p class="sc">&nbsp;*</p>*';
P_Tag[1915]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1916]='<p class="b1">&nbsp;*</p>*';
P_Tag[1917]='<p class="c3">&nbsp;*</p>*';
P_Tag[1918]='<p class="sc">&nbsp;*</p>*';
P_Tag[1919]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1920]='<p class="b1">&nbsp;*<span class="font10" id="P1207_131">[PTS.131]</span></p>*';
P_Tag[1921]='<p class="c3">&nbsp;*</p>*';
P_Tag[1922]='<p class="sc">&nbsp;*</p>*';
P_Tag[1923]='<p class="b1">&nbsp;*<span class="font10" id="M1207_255">[Pg.255]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1924]='<p class="b1">&nbsp;*</p>*';
P_Tag[1925]='<p class="c3">&nbsp;*</p>*';
P_Tag[1926]='<p class="sc">&nbsp;*</p>*';
P_Tag[1927]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_256">[Pg.256]</span><span class="bld">*</span>*</p>*';
P_Tag[1928]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_132">[PTS.132]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1929]='<p class="b1">&nbsp;*<span class="font10" id="M1207_257">[Pg.257]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_133">[PTS.133]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1930]='<p class="b1">&nbsp;*<span class="font10" id="M1207_258">[Pg.258]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1931]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_134">[PTS.134]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1932]='<p class="b1">&nbsp;*<span class="font10" id="M1207_259">[Pg.259]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1933]='<p class="b1">&nbsp;*</p>*';
P_Tag[1934]='<p class="c3">&nbsp;*</p>*';
P_Tag[1935]='<p class="sc">&nbsp;*</p>*';
P_Tag[1936]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1937]='<p class="b1">&nbsp;*<span class="font10" id="M1207_260">[Pg.260]</span><span class="font10" id="P1207_135">[PTS.135]</span></p>*';
P_Tag[1938]='<p class="c3">&nbsp;*</p>*';
P_Tag[1939]='<p class="sc">&nbsp;*</p>*';
P_Tag[1940]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1941]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_261">[Pg.261]</span><span class="bld">*</span>*<span class="font10" id="P1207_136">[PTS.136]</span></p>*';
P_Tag[1942]='<p class="b1">&nbsp;*</p>*';
P_Tag[1943]='<p class="b1">&nbsp;*<span class="font10" id="M1207_262">[Pg.262]</span></p>*';
P_Tag[1944]='<p class="b1">&nbsp;*</p>*';
P_Tag[1945]='<p class="b1">&nbsp;*<span class="font10" id="P1207_137">[PTS.137]</span></p>*';
P_Tag[1946]='<p class="b1">&nbsp;*<span class="font10" id="M1207_263">[Pg.263]</span></p>*';
P_Tag[1947]='<p class="b1">&nbsp;*</p>*';
P_Tag[1948]='<p class="b1">&nbsp;*</p>*';
P_Tag[1949]='<p class="b1">&nbsp;*</p>*';
P_Tag[1950]='<p class="b1">&nbsp;*</p>*';
P_Tag[1951]='<p class="b1">&nbsp;*<span class="font10" id="M1207_264">[Pg.264]</span><span class="font10" id="P1207_138">[PTS.138]</span></p>*';
P_Tag[1952]='<p class="b1">&nbsp;*</p>*';
P_Tag[1953]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1954]='<p class="b1">&nbsp;*</p>*';
P_Tag[1955]='<p class="b1">&nbsp;*</p>*';
P_Tag[1956]='<p class="b1">&nbsp;*<span class="font10" id="M1207_265">[Pg.265]</span><span class="font10" id="P1207_139">[PTS.139]</span></p>*';
P_Tag[1957]='<p class="c3">&nbsp;*</p>*';
P_Tag[1958]='<p class="sc">&nbsp;*</p>*';
P_Tag[1959]='<p class="b1">&nbsp;*</p>*';
P_Tag[1960]='<p class="c3">&nbsp;*</p>*';
P_Tag[1961]='<p class="c3">&nbsp;*</p>*';
P_Tag[1962]='<p class="te">&nbsp;*</p>*';
P_Tag[1963]='<p class="sc">&nbsp;*</p>*';
P_Tag[1964]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_266">[Pg.266]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1965]='<p class="b1">&nbsp;*</p>*';
P_Tag[1966]='<p class="c3">&nbsp;*</p>*';
P_Tag[1967]='<p class="sc">&nbsp;*</p>*';
P_Tag[1968]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_140">[PTS.140]</span><span class="font10" id="M1207_267">[Pg.267]</span></p>*';
P_Tag[1969]='<p class="b1">&nbsp;*</p>*';
P_Tag[1970]='<p class="b1">&nbsp;*</p>*';
P_Tag[1971]='<p class="c3">&nbsp;*</p>*';
P_Tag[1972]='<p class="sc">&nbsp;*</p>*';
P_Tag[1973]='<p class="b1">&nbsp;*<span class="font10" id="M1207_268">[Pg.268]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_141">[PTS.141]</span></p>*';
P_Tag[1974]='<p class="b1">&nbsp;*</p>*';
P_Tag[1975]='<p class="c3">&nbsp;*</p>*';
P_Tag[1976]='<p class="sc">&nbsp;*</p>*';
P_Tag[1977]='<p class="b1">&nbsp;*<span class="font10" id="M1207_269">[Pg.269]</span><span class="bld">*</span>*</p>*';
P_Tag[1978]='<p class="b1">&nbsp;*</p>*';
P_Tag[1979]='<p class="c3">&nbsp;*</p>*';
P_Tag[1980]='<p class="sc">&nbsp;*</p>*';
P_Tag[1981]='<p class="b1">&nbsp;*<span class="font10" id="P1207_142">[PTS.142]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1982]='<p class="b1">&nbsp;*</p>*';
P_Tag[1983]='<p class="c3">&nbsp;*</p>*';
P_Tag[1984]='<p class="sc">&nbsp;*</p>*';
P_Tag[1985]='<p class="b1">&nbsp;*<span class="font10" id="M1207_270">[Pg.270]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[1986]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1987]='<p class="c3">&nbsp;*</p>*';
P_Tag[1988]='<p class="sc">&nbsp;*</p>*';
P_Tag[1989]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[1990]='<p class="b1">&nbsp;*</p>*';
P_Tag[1991]='<p class="c3">&nbsp;*</p>*';
P_Tag[1992]='<p class="sc">&nbsp;*</p>*';
P_Tag[1993]='<p class="b1">&nbsp;*<span class="font10" id="P1207_143">[PTS.143]</span><span class="font10" id="M1207_271">[Pg.271]</span><span class="bld">*</span>*</p>*';
P_Tag[1994]='<p class="b1">&nbsp;*</p>*';
P_Tag[1995]='<p class="c3">&nbsp;*</p>*';
P_Tag[1996]='<p class="sc">&nbsp;*</p>*';
P_Tag[1997]='<p class="b1">&nbsp;*</p>*';
P_Tag[1998]='<p class="c3">&nbsp;*</p>*';
P_Tag[1999]='<p class="sc">&nbsp;*</p>*';
P_Tag[2000]='<p class="b1">&nbsp;*</p>*';
P_Tag[2001]='<p class="c3">&nbsp;*</p>*';
P_Tag[2002]='<p class="c3">&nbsp;*</p>*';
P_Tag[2003]='<p class="c3">&nbsp;*</p>*';
P_Tag[2004]='<p class="c3">&nbsp;*</p>*';
P_Tag[2005]='<p class="c4">&nbsp;*</p>*';
P_Tag[2006]='<p class="sc">&nbsp;*</p>*';
P_Tag[2007]='<p class="b1">&nbsp;*<span class="font10" id="M1207_272">[Pg.272]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2008]='<p class="b1">&nbsp;*<span class="font10" id="P1207_144">[PTS.144]</span></p>*';
P_Tag[2009]='<p class="c3">&nbsp;*</p>*';
P_Tag[2010]='<p class="sc">&nbsp;*</p>*';
P_Tag[2011]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_273">[Pg.273]</span></p>*';
P_Tag[2012]='<p class="b1">&nbsp;*</p>*';
P_Tag[2013]='<p class="c3">&nbsp;*</p>*';
P_Tag[2014]='<p class="sc">&nbsp;*</p>*';
P_Tag[2015]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2016]='<p class="b1">&nbsp;*<span class="font10" id="M1207_274">[Pg.274]</span><span class="font10" id="P1207_145">[PTS.145]</span></p>*';
P_Tag[2017]='<p class="c3">&nbsp;*</p>*';
P_Tag[2018]='<p class="sc">&nbsp;*</p>*';
P_Tag[2019]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2020]='<p class="b1">&nbsp;*<span class="font10" id="M1207_275">[Pg.275]</span></p>*';
P_Tag[2021]='<p class="c3">&nbsp;*</p>*';
P_Tag[2022]='<p class="c3">&nbsp;*</p>*';
P_Tag[2023]='<p class="c3">&nbsp;*</p>*';
P_Tag[2024]='<p class="c4">&nbsp;*</p>*';
P_Tag[2025]='<p class="sc">&nbsp;*</p>*';
P_Tag[2026]='<p class="b1">&nbsp;*<span class="font10" id="M1207_276">[Pg.276]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_146">[PTS.146]</span></p>*';
P_Tag[2027]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2028]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_277">[Pg.277]</span></p>*';
P_Tag[2029]='<p class="b1">&nbsp;*</p>*';
P_Tag[2030]='<p class="b1">&nbsp;*<span class="font10" id="P1207_147">[PTS.147]</span></p>*';
P_Tag[2031]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_278">[Pg.278]</span><span class="bld">*</span>*</p>*';
P_Tag[2032]='<p class="sc">&nbsp;*</p>*';
P_Tag[2033]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_148">[PTS.148]</span></p>*';
P_Tag[2034]='<p class="sc">&nbsp;*</p>*';
P_Tag[2035]='<p class="b1">&nbsp;*<span class="font10" id="M1207_279">[Pg.279]</span><span class="bld">*</span>*</p>*';
P_Tag[2036]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2037]='<p class="sc">&nbsp;*</p>*';
P_Tag[2038]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2039]='<p class="sc">&nbsp;*</p>*';
P_Tag[2040]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2041]='<p class="sc">&nbsp;*</p>*';
P_Tag[2042]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2043]='<p class="b1">&nbsp;*</p>*';
P_Tag[2044]='<p class="sc">&nbsp;*</p>*';
P_Tag[2045]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2046]='<p class="b1">&nbsp;*</p>*';
P_Tag[2047]='<p class="sc">&nbsp;*</p>*';
P_Tag[2048]='<p class="b1">&nbsp;*<span class="font10" id="M1207_280">[Pg.280]</span><span class="bld">*</span>*<span class="font10" id="P1207_149">[PTS.149]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2049]='<p class="sc">&nbsp;*</p>*';
P_Tag[2050]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2051]='<p class="sc">&nbsp;*</p>*';
P_Tag[2052]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2053]='<p class="sc">&nbsp;*</p>*';
P_Tag[2054]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2055]='<p class="sc">&nbsp;*</p>*';
P_Tag[2056]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2057]='<p class="sc">&nbsp;*</p>*';
P_Tag[2058]='<p class="b1">&nbsp;*<span class="font10" id="M1207_281">[Pg.281]</span><span class="bld">*</span>*</p>*';
P_Tag[2059]='<p class="c3">&nbsp;*</p>*';
P_Tag[2060]='<p class="sc">&nbsp;*</p>*';
P_Tag[2061]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2062]='<p class="sc">&nbsp;*</p>*';
P_Tag[2063]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2064]='<p class="sc">&nbsp;*</p>*';
P_Tag[2065]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2066]='<p class="sc">&nbsp;*</p>*';
P_Tag[2067]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_282">[Pg.282]</span><span class="font10" id="P1207_150">[PTS.150]</span></p>*';
P_Tag[2068]='<p class="sc">&nbsp;*</p>*';
P_Tag[2069]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2070]='<p class="sc">&nbsp;*</p>*';
P_Tag[2071]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2072]='<p class="sc">&nbsp;*</p>*';
P_Tag[2073]='<p class="b1">&nbsp;*</p>*';
P_Tag[2074]='<p class="sc">&nbsp;*</p>*';
P_Tag[2075]='<p class="b1">&nbsp;*</p>*';
P_Tag[2076]='<p class="sc">&nbsp;*</p>*';
P_Tag[2077]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2078]='<p class="sc">&nbsp;*</p>*';
P_Tag[2079]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2080]='<p class="sc">&nbsp;*</p>*';
P_Tag[2081]='<p class="b1">&nbsp;*<span class="font10" id="M1207_283">[Pg.283]</span><span class="bld">*</span>*</p>*';
P_Tag[2082]='<p class="sc">&nbsp;*</p>*';
P_Tag[2083]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2084]='<p class="sc">&nbsp;*</p>*';
P_Tag[2085]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2086]='<p class="sc">&nbsp;*</p>*';
P_Tag[2087]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2088]='<p class="sc">&nbsp;*</p>*';
P_Tag[2089]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2090]='<p class="sc">&nbsp;*</p>*';
P_Tag[2091]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2092]='<p class="sc">&nbsp;*</p>*';
P_Tag[2093]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2094]='<p class="sc">&nbsp;*</p>*';
P_Tag[2095]='<p class="b1">&nbsp;*<span class="font10" id="M1207_284">[Pg.284]</span><span class="bld">*</span>*</p>*';
P_Tag[2096]='<p class="sc">&nbsp;*</p>*';
P_Tag[2097]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2098]='<p class="sc">&nbsp;*</p>*';
P_Tag[2099]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2100]='<p class="sc">&nbsp;*</p>*';
P_Tag[2101]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_151">[PTS.151]</span></p>*';
P_Tag[2102]='<p class="sc">&nbsp;*</p>*';
P_Tag[2103]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2104]='<p class="sc">&nbsp;*</p>*';
P_Tag[2105]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_285">[Pg.285]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2106]='<p class="c3">&nbsp;*</p>*';
P_Tag[2107]='<p class="sc">&nbsp;*</p>*';
P_Tag[2108]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2109]='<p class="sc">&nbsp;*</p>*';
P_Tag[2110]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2111]='<p class="sc">&nbsp;*</p>*';
P_Tag[2112]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2113]='<p class="sc">&nbsp;*</p>*';
P_Tag[2114]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_286">[Pg.286]</span></p>*';
P_Tag[2115]='<p class="sc">&nbsp;*</p>*';
P_Tag[2116]='<p class="b1">&nbsp;*<span class="font10" id="P1207_152">[PTS.152]</span><span class="bld">*</span>*</p>*';
P_Tag[2117]='<p class="sc">&nbsp;*</p>*';
P_Tag[2118]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2119]='<p class="sc">&nbsp;*</p>*';
P_Tag[2120]='<p class="b1">&nbsp;*</p>*';
P_Tag[2121]='<p class="sc">&nbsp;*</p>*';
P_Tag[2122]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2123]='<p class="sc">&nbsp;*</p>*';
P_Tag[2124]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2125]='<p class="sc">&nbsp;*</p>*';
P_Tag[2126]='<p class="b1">&nbsp;*<span class="font10" id="M1207_287">[Pg.287]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2127]='<p class="sc">&nbsp;*</p>*';
P_Tag[2128]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2129]='<p class="sc">&nbsp;*</p>*';
P_Tag[2130]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2131]='<p class="sc">&nbsp;*</p>*';
P_Tag[2132]='<p class="b1">&nbsp;*</p>*';
P_Tag[2133]='<p class="sc">&nbsp;*</p>*';
P_Tag[2134]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2135]='<p class="sc">&nbsp;*</p>*';
P_Tag[2136]='<p class="b1">&nbsp;*</p>*';
P_Tag[2137]='<p class="sc">&nbsp;*</p>*';
P_Tag[2138]='<p class="b1">&nbsp;*<span class="font10" id="M1207_288">[Pg.288]</span><span class="font10" id="P1207_153">[PTS.153]</span></p>*';
P_Tag[2139]='<p class="sc">&nbsp;*</p>*';
P_Tag[2140]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2141]='<p class="b1">&nbsp;*</p>*';
P_Tag[2142]='<p class="c3">&nbsp;*</p>*';
P_Tag[2143]='<p class="c3">&nbsp;*</p>*';
P_Tag[2144]='<p class="c3">&nbsp;*</p>*';
P_Tag[2145]='<p class="sc">&nbsp;*</p>*';
P_Tag[2146]='<p class="b1">&nbsp;*<span class="font10" id="M1207_289">[Pg.289]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_154">[PTS.154]</span><span class="bld">*</span>*</p>*';
P_Tag[2147]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2148]='<p class="b1">&nbsp;*<span class="font10" id="M1207_290">[Pg.290]</span><span class="bld">*</span>*</p>*';
P_Tag[2149]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_155">[PTS.155]</span></p>*';
P_Tag[2150]='<p class="b1">&nbsp;*<span class="font10" id="M1207_291">[Pg.291]</span></p>*';
P_Tag[2151]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2152]='<p class="b1">&nbsp;*</p>*';
P_Tag[2153]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_292">[Pg.292]</span></p>*';
P_Tag[2154]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_156">[PTS.156]</span></p>*';
P_Tag[2155]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2156]='<p class="c3">&nbsp;*</p>*';
P_Tag[2157]='<p class="c3">&nbsp;*</p>*';
P_Tag[2158]='<p class="c3">&nbsp;*</p>*';
P_Tag[2159]='<p class="c3">&nbsp;*</p>*';
P_Tag[2160]='<p class="c4">&nbsp;*</p>*';
P_Tag[2161]='<p class="c4">&nbsp;*</p>*';
P_Tag[2162]='<p class="g5">&nbsp;*<span class="font10" id="P1207_157">[PTS.157]</span></p>*';
P_Tag[2163]='<p class="g8">&nbsp;*</p>*';
P_Tag[2164]='<p class="te">&nbsp;*</p>*';
P_Tag[2165]='<p class="sc">&nbsp;*</p>*';
P_Tag[2166]='<p class="b1">&nbsp;*<span class="font10" id="M1207_293">[Pg.293]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2167]='<p class="te">&nbsp;*</p>*';
P_Tag[2168]='<p class="sc">&nbsp;*</p>*';
P_Tag[2169]='<p class="b1">&nbsp;*<span class="font10" id="M1207_294">[Pg.294]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_158">[PTS.158]</span></p>*';
P_Tag[2170]='<p class="b1">&nbsp;*</p>*';
P_Tag[2171]='<p class="b1">&nbsp;*<span class="font10" id="M1207_295">[Pg.295]</span></p>*';
P_Tag[2172]='<p class="c3">&nbsp;*</p>*';
P_Tag[2173]='<p class="sc">&nbsp;*</p>*';
P_Tag[2174]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2175]='<p class="b1">&nbsp;*</p>*';
P_Tag[2176]='<p class="c3">&nbsp;*</p>*';
P_Tag[2177]='<p class="sc">&nbsp;*</p>*';
P_Tag[2178]='<p class="b1">&nbsp;*<span class="font10" id="P1207_159">[PTS.159]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_296">[Pg.296]</span><span class="bld">*</span>*</p>*';
P_Tag[2179]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2180]='<p class="c3">&nbsp;*</p>*';
P_Tag[2181]='<p class="sc">&nbsp;*</p>*';
P_Tag[2182]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_160">[PTS.160]</span><span class="font10" id="M1207_297">[Pg.297]</span><span class="bld">*</span>*</p>*';
P_Tag[2183]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2184]='<p class="c3">&nbsp;*</p>*';
P_Tag[2185]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2186]='<p class="c3">&nbsp;*</p>*';
P_Tag[2187]='<p class="c3">&nbsp;*</p>*';
P_Tag[2188]='<p class="c3">&nbsp;*</p>*';
P_Tag[2189]='<p class="c4">&nbsp;*</p>*';
P_Tag[2190]='<p class="sc">&nbsp;*</p>*';
P_Tag[2191]='<p class="b1">&nbsp;*<span class="font10" id="M1207_298">[Pg.298]</span><span class="bld">*</span>*<span class="font10" id="P1207_161">[PTS.161]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2192]='<p class="b1">&nbsp;*</p>*';
P_Tag[2193]='<p class="b1">&nbsp;*<span class="font10" id="M1207_299">[Pg.299]</span></p>*';
P_Tag[2194]='<p class="c3">&nbsp;*</p>*';
P_Tag[2195]='<p class="sc">&nbsp;*</p>*';
P_Tag[2196]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_162">[PTS.162]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2197]='<p class="b1">&nbsp;*</p>*';
P_Tag[2198]='<p class="c3">&nbsp;*</p>*';
P_Tag[2199]='<p class="sc">&nbsp;*</p>*';
P_Tag[2200]='<p class="b1">&nbsp;*<span class="font10" id="M1207_300">[Pg.300]</span><span class="bld">*</span>*</p>*';
P_Tag[2201]='<p class="b1">&nbsp;*<span class="font10" id="P1207_163">[PTS.163]</span></p>*';
P_Tag[2202]='<p class="b1">&nbsp;*</p>*';
P_Tag[2203]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2204]='<p class="b1">&nbsp;*<span class="font10" id="M1207_301">[Pg.301]</span></p>*';
P_Tag[2205]='<p class="g5">&nbsp;*</p>*';
P_Tag[2206]='<p class="g6">&nbsp;*</p>*';
P_Tag[2207]='<p class="g7">&nbsp;*</p>*';
P_Tag[2208]='<p class="g8">&nbsp;*</p>*';
P_Tag[2209]='<p class="b1">&nbsp;*</p>*';
P_Tag[2210]='<p class="c3">&nbsp;*</p>*';
P_Tag[2211]='<p class="sc">&nbsp;*</p>*';
P_Tag[2212]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_164">[PTS.164]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2213]='<p class="b1">&nbsp;*<span class="font10" id="M1207_302">[Pg.302]</span></p>*';
P_Tag[2214]='<p class="c3">&nbsp;*</p>*';
P_Tag[2215]='<p class="sc">&nbsp;*</p>*';
P_Tag[2216]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2217]='<p class="b1">&nbsp;*</p>*';
P_Tag[2218]='<p class="c3">&nbsp;*</p>*';
P_Tag[2219]='<p class="sc">&nbsp;*</p>*';
P_Tag[2220]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2221]='<p class="b1">&nbsp;*<span class="font10" id="M1207_303">[Pg.303]</span><span class="font10" id="P1207_165">[PTS.165]</span></p>*';
P_Tag[2222]='<p class="c3">&nbsp;*</p>*';
P_Tag[2223]='<p class="sc">&nbsp;*</p>*';
P_Tag[2224]='<p class="b1">&nbsp;*</p>*';
P_Tag[2225]='<p class="c3">&nbsp;*</p>*';
P_Tag[2226]='<p class="sc">&nbsp;*</p>*';
P_Tag[2227]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2228]='<p class="c3">&nbsp;*</p>*';
P_Tag[2229]='<p class="sc">&nbsp;*</p>*';
P_Tag[2230]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2231]='<p class="c3">&nbsp;*</p>*';
P_Tag[2232]='<p class="sc">&nbsp;*</p>*';
P_Tag[2233]='<p class="b1">&nbsp;*<span class="font10" id="M1207_304">[Pg.304]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2234]='<p class="b1">&nbsp;*<span class="font10" id="P1207_166">[PTS.166]</span></p>*';
P_Tag[2235]='<p class="c3">&nbsp;*</p>*';
P_Tag[2236]='<p class="sc">&nbsp;*</p>*';
P_Tag[2237]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2238]='<p class="b1">&nbsp;*</p>*';
P_Tag[2239]='<p class="c3">&nbsp;*</p>*';
P_Tag[2240]='<p class="sc">&nbsp;*</p>*';
P_Tag[2241]='<p class="b1">&nbsp;*<span class="font10" id="M1207_305">[Pg.305]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_167">[PTS.167]</span></p>*';
P_Tag[2242]='<p class="b1">&nbsp;*</p>*';
P_Tag[2243]='<p class="b1">&nbsp;*</p>*';
P_Tag[2244]='<p class="b1">&nbsp;*<span class="font10" id="M1207_306">[Pg.306]</span></p>*';
P_Tag[2245]='<p class="b1">&nbsp;*</p>*';
P_Tag[2246]='<p class="b1">&nbsp;*</p>*';
P_Tag[2247]='<p class="b1">&nbsp;*<span class="font10" id="P1207_168">[PTS.168]</span></p>*';
P_Tag[2248]='<p class="b1">&nbsp;*<span class="font10" id="M1207_307">[Pg.307]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2249]='<p class="c3">&nbsp;*</p>*';
P_Tag[2250]='<p class="c3">&nbsp;*</p>*';
P_Tag[2251]='<p class="c3">&nbsp;*</p>*';
P_Tag[2252]='<p class="c4">&nbsp;*</p>*';
P_Tag[2253]='<p class="sc">&nbsp;*</p>*';
P_Tag[2254]='<p class="b1">&nbsp;*<span class="font10" id="M1207_308">[Pg.308]</span><span class="bld">*</span>*</p>*';
P_Tag[2255]='<p class="b1">&nbsp;*</p>*';
P_Tag[2256]='<p class="c3">&nbsp;*</p>*';
P_Tag[2257]='<p class="sc">&nbsp;*</p>*';
P_Tag[2258]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2259]='<p class="b1">&nbsp;*<span class="font10" id="P1207_169">[PTS.169]</span></p>*';
P_Tag[2260]='<p class="c3">&nbsp;*</p>*';
P_Tag[2261]='<p class="sc">&nbsp;*</p>*';
P_Tag[2262]='<p class="b1">&nbsp;*<span class="font10" id="M1207_309">[Pg.309]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2263]='<p class="b1">&nbsp;*</p>*';
P_Tag[2264]='<p class="c3">&nbsp;*</p>*';
P_Tag[2265]='<p class="sc">&nbsp;*</p>*';
P_Tag[2266]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2267]='<p class="b1">&nbsp;*<span class="font10" id="P1207_170">[PTS.170]</span></p>*';
P_Tag[2268]='<p class="c3">&nbsp;*</p>*';
P_Tag[2269]='<p class="sc">&nbsp;*</p>*';
P_Tag[2270]='<p class="b1">&nbsp;*<span class="font10" id="M1207_310">[Pg.310]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2271]='<p class="c3">&nbsp;*</p>*';
P_Tag[2272]='<p class="sc">&nbsp;*</p>*';
P_Tag[2273]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2274]='<p class="b1">&nbsp;*</p>*';
P_Tag[2275]='<p class="c3">&nbsp;*</p>*';
P_Tag[2276]='<p class="sc">&nbsp;*</p>*';
P_Tag[2277]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2278]='<p class="c3">&nbsp;*</p>*';
P_Tag[2279]='<p class="sc">&nbsp;*</p>*';
P_Tag[2280]='<p class="b1">&nbsp;*<span class="font10" id="M1207_311">[Pg.311]</span><span class="bld">*</span>*</p>*';
P_Tag[2281]='<p class="c3">&nbsp;*</p>*';
P_Tag[2282]='<p class="sc">&nbsp;*</p>*';
P_Tag[2283]='<p class="b1">&nbsp;*<span class="font10" id="P1207_171">[PTS.171]</span><span class="bld">*</span>*</p>*';
P_Tag[2284]='<p class="c3">&nbsp;*</p>*';
P_Tag[2285]='<p class="sc">&nbsp;*</p>*';
P_Tag[2286]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2287]='<p class="b1">&nbsp;*</p>*';
P_Tag[2288]='<p class="c3">&nbsp;*</p>*';
P_Tag[2289]='<p class="c3">&nbsp;*</p>*';
P_Tag[2290]='<p class="sc">&nbsp;*</p>*';
P_Tag[2291]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2292]='<p class="b1">&nbsp;*<span class="font10" id="M1207_312">[Pg.312]</span></p>*';
P_Tag[2293]='<p class="c3">&nbsp;*</p>*';
P_Tag[2294]='<p class="sc">&nbsp;*</p>*';
P_Tag[2295]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2296]='<p class="c3">&nbsp;*</p>*';
P_Tag[2297]='<p class="b1">&nbsp;*<span class="font10" id="P1207_172">[PTS.172]</span></p>*';
P_Tag[2298]='<p class="c3">&nbsp;*</p>*';
P_Tag[2299]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2300]='<p class="c3">&nbsp;*</p>*';
P_Tag[2301]='<p class="c3">&nbsp;*</p>*';
P_Tag[2302]='<p class="c4">&nbsp;*</p>*';
P_Tag[2303]='<p class="te">&nbsp;*</p>*';
P_Tag[2304]='<p class="sc">&nbsp;*</p>*';
P_Tag[2305]='<p class="b1">&nbsp;*<span class="font10" id="M1207_313">[Pg.313]</span><span class="bld">*</span>*</p>*';
P_Tag[2306]='<p class="b1">&nbsp;*</p>*';
P_Tag[2307]='<p class="c3">&nbsp;*</p>*';
P_Tag[2308]='<p class="sc">&nbsp;*</p>*';
P_Tag[2309]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2310]='<p class="b1">&nbsp;*</p>*';
P_Tag[2311]='<p class="c3">&nbsp;*</p>*';
P_Tag[2312]='<p class="sc">&nbsp;*</p>*';
P_Tag[2313]='<p class="b1">&nbsp;*<span class="font10" id="M1207_314">[Pg.314]</span><span class="bld">*</span>*</p>*';
P_Tag[2314]='<p class="b1">&nbsp;*<span class="font10" id="P1207_173">[PTS.173]</span></p>*';
P_Tag[2315]='<p class="c3">&nbsp;*</p>*';
P_Tag[2316]='<p class="sc">&nbsp;*</p>*';
P_Tag[2317]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2318]='<p class="b1">&nbsp;*</p>*';
P_Tag[2319]='<p class="c3">&nbsp;*</p>*';
P_Tag[2320]='<p class="sc">&nbsp;*</p>*';
P_Tag[2321]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2322]='<p class="b1">&nbsp;*<span class="font10" id="M1207_315">[Pg.315]</span></p>*';
P_Tag[2323]='<p class="c3">&nbsp;*</p>*';
P_Tag[2324]='<p class="sc">&nbsp;*</p>*';
P_Tag[2325]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2326]='<p class="b1">&nbsp;*<span class="font10" id="P1207_174">[PTS.174]</span></p>*';
P_Tag[2327]='<p class="c3">&nbsp;*</p>*';
P_Tag[2328]='<p class="sc">&nbsp;*</p>*';
P_Tag[2329]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2330]='<p class="b1">&nbsp;*<span class="font10" id="M1207_316">[Pg.316]</span></p>*';
P_Tag[2331]='<p class="c3">&nbsp;*</p>*';
P_Tag[2332]='<p class="sc">&nbsp;*</p>*';
P_Tag[2333]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2334]='<p class="b1">&nbsp;*<span class="font10" id="P1207_175">[PTS.175]</span></p>*';
P_Tag[2335]='<p class="c3">&nbsp;*</p>*';
P_Tag[2336]='<p class="sc">&nbsp;*</p>*';
P_Tag[2337]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_317">[Pg.317]</span></p>*';
P_Tag[2338]='<p class="b1">&nbsp;*</p>*';
P_Tag[2339]='<p class="c3">&nbsp;*</p>*';
P_Tag[2340]='<p class="sc">&nbsp;*</p>*';
P_Tag[2341]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2342]='<p class="b1">&nbsp;*<span class="font10" id="P1207_176">[PTS.176]</span><span class="font10" id="M1207_318">[Pg.318]</span></p>*';
P_Tag[2343]='<p class="c3">&nbsp;*</p>*';
P_Tag[2344]='<p class="c3">&nbsp;*</p>*';
P_Tag[2345]='<p class="te">&nbsp;*</p>*';
P_Tag[2346]='<p class="sc">&nbsp;*</p>*';
P_Tag[2347]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2348]='<p class="b1">&nbsp;*</p>*';
P_Tag[2349]='<p class="c3">&nbsp;*</p>*';
P_Tag[2350]='<p class="sc">&nbsp;*</p>*';
P_Tag[2351]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2352]='<p class="c3">&nbsp;*</p>*';
P_Tag[2353]='<p class="sc">&nbsp;*</p>*';
P_Tag[2354]='<p class="b1">&nbsp;*<span class="font10" id="M1207_319">[Pg.319]</span><span class="bld">*</span>*</p>*';
P_Tag[2355]='<p class="c3">&nbsp;*</p>*';
P_Tag[2356]='<p class="sc">&nbsp;*</p>*';
P_Tag[2357]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_177">[PTS.177]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2358]='<p class="b1">&nbsp;*</p>*';
P_Tag[2359]='<p class="c3">&nbsp;*</p>*';
P_Tag[2360]='<p class="sc">&nbsp;*</p>*';
P_Tag[2361]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2362]='<p class="b1">&nbsp;*<span class="font10" id="M1207_320">[Pg.320]</span></p>*';
P_Tag[2363]='<p class="c3">&nbsp;*</p>*';
P_Tag[2364]='<p class="sc">&nbsp;*</p>*';
P_Tag[2365]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2366]='<p class="b1">&nbsp;*<span class="font10" id="P1207_178">[PTS.178]</span></p>*';
P_Tag[2367]='<p class="c3">&nbsp;*</p>*';
P_Tag[2368]='<p class="sc">&nbsp;*</p>*';
P_Tag[2369]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2370]='<p class="b1">&nbsp;*</p>*';
P_Tag[2371]='<p class="c3">&nbsp;*</p>*';
P_Tag[2372]='<p class="sc">&nbsp;*</p>*';
P_Tag[2373]='<p class="b1">&nbsp;*<span class="font10" id="M1207_321">[Pg.321]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2374]='<p class="b1">&nbsp;*</p>*';
P_Tag[2375]='<p class="c3">&nbsp;*</p>*';
P_Tag[2376]='<p class="sc">&nbsp;*</p>*';
P_Tag[2377]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2378]='<p class="b1">&nbsp;*<span class="font10" id="P1207_179">[PTS.179]</span></p>*';
P_Tag[2379]='<p class="c3">&nbsp;*</p>*';
P_Tag[2380]='<p class="sc">&nbsp;*</p>*';
P_Tag[2381]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2382]='<p class="b1">&nbsp;*<span class="font10" id="M1207_322">[Pg.322]</span></p>*';
P_Tag[2383]='<p class="c3">&nbsp;*</p>*';
P_Tag[2384]='<p class="c3">&nbsp;*</p>*';
P_Tag[2385]='<p class="te">&nbsp;*</p>*';
P_Tag[2386]='<p class="sc">&nbsp;*</p>*';
P_Tag[2387]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2388]='<p class="b1">&nbsp;*</p>*';
P_Tag[2389]='<p class="c3">&nbsp;*</p>*';
P_Tag[2390]='<p class="sc">&nbsp;*</p>*';
P_Tag[2391]='<p class="b1">&nbsp;*</p>*';
P_Tag[2392]='<p class="c3">&nbsp;*</p>*';
P_Tag[2393]='<p class="sc">&nbsp;*</p>*';
P_Tag[2394]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_323">[Pg.323]</span><span class="font10" id="P1207_180">[PTS.180]</span></p>*';
P_Tag[2395]='<p class="b1">&nbsp;*</p>*';
P_Tag[2396]='<p class="c3">&nbsp;*</p>*';
P_Tag[2397]='<p class="sc">&nbsp;*</p>*';
P_Tag[2398]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2399]='<p class="b1">&nbsp;*</p>*';
P_Tag[2400]='<p class="c3">&nbsp;*</p>*';
P_Tag[2401]='<p class="sc">&nbsp;*</p>*';
P_Tag[2402]='<p class="b1">&nbsp;*<span class="font10" id="P1207_181">[PTS.181]</span><span class="font10" id="M1207_324">[Pg.324]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2403]='<p class="b1">&nbsp;*</p>*';
P_Tag[2404]='<p class="c3">&nbsp;*</p>*';
P_Tag[2405]='<p class="sc">&nbsp;*</p>*';
P_Tag[2406]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2407]='<p class="b1">&nbsp;*</p>*';
P_Tag[2408]='<p class="c3">&nbsp;*</p>*';
P_Tag[2409]='<p class="sc">&nbsp;*</p>*';
P_Tag[2410]='<p class="b1">&nbsp;*<span class="font10" id="M1207_325">[Pg.325]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2411]='<p class="b1">&nbsp;*<span class="font10" id="P1207_182">[PTS.182]</span></p>*';
P_Tag[2412]='<p class="c3">&nbsp;*</p>*';
P_Tag[2413]='<p class="sc">&nbsp;*</p>*';
P_Tag[2414]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2415]='<p class="b1">&nbsp;*</p>*';
P_Tag[2416]='<p class="c3">&nbsp;*</p>*';
P_Tag[2417]='<p class="sc">&nbsp;*</p>*';
P_Tag[2418]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_326">[Pg.326]</span><span class="bld">*</span>*</p>*';
P_Tag[2419]='<p class="b1">&nbsp;*<span class="font10" id="P1207_183">[PTS.183]</span></p>*';
P_Tag[2420]='<p class="c3">&nbsp;*</p>*';
P_Tag[2421]='<p class="sc">&nbsp;*</p>*';
P_Tag[2422]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2423]='<p class="b1">&nbsp;*</p>*';
P_Tag[2424]='<p class="c3">&nbsp;*</p>*';
P_Tag[2425]='<p class="c3">&nbsp;*</p>*';
P_Tag[2426]='<p class="te">&nbsp;*</p>*';
P_Tag[2427]='<p class="sc">&nbsp;*</p>*';
P_Tag[2428]='<p class="b1">&nbsp;*<span class="font10" id="M1207_327">[Pg.327]</span><span class="bld">*</span>*</p>*';
P_Tag[2429]='<p class="b1">&nbsp;*</p>*';
P_Tag[2430]='<p class="c3">&nbsp;*</p>*';
P_Tag[2431]='<p class="sc">&nbsp;*</p>*';
P_Tag[2432]='<p class="b1">&nbsp;*<span class="font10" id="P1207_184">[PTS.184]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2433]='<p class="b1">&nbsp;*</p>*';
P_Tag[2434]='<p class="c3">&nbsp;*</p>*';
P_Tag[2435]='<p class="sc">&nbsp;*</p>*';
P_Tag[2436]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2437]='<p class="b1">&nbsp;*<span class="font10" id="M1207_328">[Pg.328]</span></p>*';
P_Tag[2438]='<p class="c3">&nbsp;*</p>*';
P_Tag[2439]='<p class="sc">&nbsp;*</p>*';
P_Tag[2440]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2441]='<p class="b1">&nbsp;*<span class="font10" id="P1207_185">[PTS.185]</span></p>*';
P_Tag[2442]='<p class="c3">&nbsp;*</p>*';
P_Tag[2443]='<p class="sc">&nbsp;*</p>*';
P_Tag[2444]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2445]='<p class="b1">&nbsp;*<span class="font10" id="M1207_329">[Pg.329]</span></p>*';
P_Tag[2446]='<p class="c3">&nbsp;*</p>*';
P_Tag[2447]='<p class="sc">&nbsp;*</p>*';
P_Tag[2448]='<p class="b1">&nbsp;*</p>*';
P_Tag[2449]='<p class="c3">&nbsp;*</p>*';
P_Tag[2450]='<p class="sc">&nbsp;*</p>*';
P_Tag[2451]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2452]='<p class="b1">&nbsp;*<span class="font10" id="P1207_186">[PTS.186]</span></p>*';
P_Tag[2453]='<p class="c3">&nbsp;*</p>*';
P_Tag[2454]='<p class="sc">&nbsp;*</p>*';
P_Tag[2455]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2456]='<p class="c3">&nbsp;*</p>*';
P_Tag[2457]='<p class="sc">&nbsp;*</p>*';
P_Tag[2458]='<p class="b1">&nbsp;*<span class="font10" id="M1207_330">[Pg.330]</span><span class="bld">*</span>*</p>*';
P_Tag[2459]='<p class="c3">&nbsp;*</p>*';
P_Tag[2460]='<p class="sc">&nbsp;*</p>*';
P_Tag[2461]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2462]='<p class="b1">&nbsp;*</p>*';
P_Tag[2463]='<p class="c3">&nbsp;*</p>*';
P_Tag[2464]='<p class="c3">&nbsp;*</p>*';
P_Tag[2465]='<p class="te">&nbsp;*</p>*';
P_Tag[2466]='<p class="sc">&nbsp;*</p>*';
P_Tag[2467]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_187">[PTS.187]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_331">[Pg.331]</span></p>*';
P_Tag[2468]='<p class="b1">&nbsp;*</p>*';
P_Tag[2469]='<p class="c3">&nbsp;*</p>*';
P_Tag[2470]='<p class="sc">&nbsp;*</p>*';
P_Tag[2471]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2472]='<p class="b1">&nbsp;*</p>*';
P_Tag[2473]='<p class="c3">&nbsp;*</p>*';
P_Tag[2474]='<p class="sc">&nbsp;*</p>*';
P_Tag[2475]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2476]='<p class="b1">&nbsp;*<span class="font10" id="M1207_332">[Pg.332]</span></p>*';
P_Tag[2477]='<p class="c3">&nbsp;*</p>*';
P_Tag[2478]='<p class="sc">&nbsp;*</p>*';
P_Tag[2479]='<p class="b1">&nbsp;*<span class="font10" id="P1207_188">[PTS.188]</span><span class="bld">*</span>*</p>*';
P_Tag[2480]='<p class="b1">&nbsp;*</p>*';
P_Tag[2481]='<p class="c3">&nbsp;*</p>*';
P_Tag[2482]='<p class="sc">&nbsp;*</p>*';
P_Tag[2483]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2484]='<p class="b1">&nbsp;*</p>*';
P_Tag[2485]='<p class="c3">&nbsp;*</p>*';
P_Tag[2486]='<p class="sc">&nbsp;*</p>*';
P_Tag[2487]='<p class="b1">&nbsp;*<span class="font10" id="M1207_333">[Pg.333]</span><span class="bld">*</span>*</p>*';
P_Tag[2488]='<p class="b1">&nbsp;*</p>*';
P_Tag[2489]='<p class="c3">&nbsp;*</p>*';
P_Tag[2490]='<p class="sc">&nbsp;*</p>*';
P_Tag[2491]='<p class="b1">&nbsp;*<span class="font10" id="P1207_189">[PTS.189]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2492]='<p class="b1">&nbsp;*</p>*';
P_Tag[2493]='<p class="c3">&nbsp;*</p>*';
P_Tag[2494]='<p class="sc">&nbsp;*</p>*';
P_Tag[2495]='<p class="b1">&nbsp;*<span class="font10" id="M1207_334">[Pg.334]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2496]='<p class="b1">&nbsp;*</p>*';
P_Tag[2497]='<p class="c3">&nbsp;*</p>*';
P_Tag[2498]='<p class="sc">&nbsp;*</p>*';
P_Tag[2499]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_190">[PTS.190]</span><span class="bld">*</span>*</p>*';
P_Tag[2500]='<p class="c3">&nbsp;*</p>*';
P_Tag[2501]='<p class="sc">&nbsp;*</p>*';
P_Tag[2502]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_335">[Pg.335]</span></p>*';
P_Tag[2503]='<p class="c3">&nbsp;*</p>*';
P_Tag[2504]='<p class="c3">&nbsp;*</p>*';
P_Tag[2505]='<p class="te">&nbsp;*</p>*';
P_Tag[2506]='<p class="sc">&nbsp;*</p>*';
P_Tag[2507]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2508]='<p class="b1">&nbsp;*<span class="font10" id="P1207_191">[PTS.191]</span></p>*';
P_Tag[2509]='<p class="c3">&nbsp;*</p>*';
P_Tag[2510]='<p class="sc">&nbsp;*</p>*';
P_Tag[2511]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2512]='<p class="b1">&nbsp;*<span class="font10" id="M1207_336">[Pg.336]</span></p>*';
P_Tag[2513]='<p class="c3">&nbsp;*</p>*';
P_Tag[2514]='<p class="sc">&nbsp;*</p>*';
P_Tag[2515]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2516]='<p class="b1">&nbsp;*</p>*';
P_Tag[2517]='<p class="c3">&nbsp;*</p>*';
P_Tag[2518]='<p class="sc">&nbsp;*</p>*';
P_Tag[2519]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2520]='<p class="b1">&nbsp;*<span class="font10" id="P1207_192">[PTS.192]</span><span class="font10" id="M1207_337">[Pg.337]</span></p>*';
P_Tag[2521]='<p class="c3">&nbsp;*</p>*';
P_Tag[2522]='<p class="sc">&nbsp;*</p>*';
P_Tag[2523]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2524]='<p class="b1">&nbsp;*</p>*';
P_Tag[2525]='<p class="c3">&nbsp;*</p>*';
P_Tag[2526]='<p class="sc">&nbsp;*</p>*';
P_Tag[2527]='<p class="b1">&nbsp;*<span class="font10" id="M1207_338">[Pg.338]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_193">[PTS.193]</span></p>*';
P_Tag[2528]='<p class="b1">&nbsp;*</p>*';
P_Tag[2529]='<p class="c3">&nbsp;*</p>*';
P_Tag[2530]='<p class="sc">&nbsp;*</p>*';
P_Tag[2531]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_339">[Pg.339]</span><span class="font10" id="P1207_194">[PTS.194]</span></p>*';
P_Tag[2532]='<p class="b1">&nbsp;*</p>*';
P_Tag[2533]='<p class="b1">&nbsp;*</p>*';
P_Tag[2534]='<p class="b1">&nbsp;*</p>*';
P_Tag[2535]='<p class="b1">&nbsp;*<span class="font10" id="P1207_195">[PTS.195]</span><span class="font10" id="M1207_340">[Pg.340]</span></p>*';
P_Tag[2536]='<p class="b1">&nbsp;*</p>*';
P_Tag[2537]='<p class="c3">&nbsp;*</p>*';
P_Tag[2538]='<p class="sc">&nbsp;*</p>*';
P_Tag[2539]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2540]='<p class="b1">&nbsp;*</p>*';
P_Tag[2541]='<p class="c3">&nbsp;*</p>*';
P_Tag[2542]='<p class="sc">&nbsp;*</p>*';
P_Tag[2543]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="M1207_341">[Pg.341]</span><span class="font10" id="P1207_196">[PTS.196]</span></p>*';
P_Tag[2544]='<p class="b1">&nbsp;*</p>*';
P_Tag[2545]='<p class="c3">&nbsp;*</p>*';
P_Tag[2546]='<p class="sc">&nbsp;*</p>*';
P_Tag[2547]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2548]='<p class="b1">&nbsp;*</p>*';
P_Tag[2549]='<p class="c3">&nbsp;*</p>*';
P_Tag[2550]='<p class="c3">&nbsp;*</p>*';
P_Tag[2551]='<p class="te">&nbsp;*</p>*';
P_Tag[2552]='<p class="sc">&nbsp;*</p>*';
P_Tag[2553]='<p class="b1">&nbsp;*<span class="font10" id="M1207_342">[Pg.342]</span><span class="bld">*</span>*</p>*';
P_Tag[2554]='<p class="b1">&nbsp;*<span class="font10" id="P1207_197">[PTS.197]</span></p>*';
P_Tag[2555]='<p class="c3">&nbsp;*</p>*';
P_Tag[2556]='<p class="sc">&nbsp;*</p>*';
P_Tag[2557]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2558]='<p class="c3">&nbsp;*</p>*';
P_Tag[2559]='<p class="sc">&nbsp;*</p>*';
P_Tag[2560]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2561]='<p class="b1">&nbsp;*<span class="font10" id="M1207_343">[Pg.343]</span></p>*';
P_Tag[2562]='<p class="c3">&nbsp;*</p>*';
P_Tag[2563]='<p class="sc">&nbsp;*</p>*';
P_Tag[2564]='<p class="b1">&nbsp;*<span class="font10" id="P1207_198">[PTS.198]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2565]='<p class="c3">&nbsp;*</p>*';
P_Tag[2566]='<p class="sc">&nbsp;*</p>*';
P_Tag[2567]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2568]='<p class="c3">&nbsp;*</p>*';
P_Tag[2569]='<p class="sc">&nbsp;*</p>*';
P_Tag[2570]='<p class="b1">&nbsp;*</p>*';
P_Tag[2571]='<p class="c3">&nbsp;*</p>*';
P_Tag[2572]='<p class="sc">&nbsp;*</p>*';
P_Tag[2573]='<p class="b1">&nbsp;*<span class="font10" id="M1207_344">[Pg.344]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2574]='<p class="b1">&nbsp;*</p>*';
P_Tag[2575]='<p class="c3">&nbsp;*</p>*';
P_Tag[2576]='<p class="sc">&nbsp;*</p>*';
P_Tag[2577]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2578]='<p class="b1">&nbsp;*<span class="font10" id="P1207_199">[PTS.199]</span></p>*';
P_Tag[2579]='<p class="c3">&nbsp;*</p>*';
P_Tag[2580]='<p class="sc">&nbsp;*</p>*';
P_Tag[2581]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2582]='<p class="b1">&nbsp;*<span class="font10" id="M1207_345">[Pg.345]</span></p>*';
P_Tag[2583]='<p class="c3">&nbsp;*</p>*';
P_Tag[2584]='<p class="c3">&nbsp;*</p>*';
P_Tag[2585]='<p class="te">&nbsp;*</p>*';
P_Tag[2586]='<p class="sc">&nbsp;*</p>*';
P_Tag[2587]='<p class="b1">&nbsp;*<span class="font10" id="P1207_200">[PTS.200]</span></p>*';
P_Tag[2588]='<p class="c3">&nbsp;*</p>*';
P_Tag[2589]='<p class="sc">&nbsp;*</p>*';
P_Tag[2590]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2591]='<p class="c3">&nbsp;*</p>*';
P_Tag[2592]='<p class="sc">&nbsp;*</p>*';
P_Tag[2593]='<p class="b1">&nbsp;*<span class="font10" id="M1207_346">[Pg.346]</span><span class="bld">*</span>*</p>*';
P_Tag[2594]='<p class="c3">&nbsp;*</p>*';
P_Tag[2595]='<p class="sc">&nbsp;*</p>*';
P_Tag[2596]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2597]='<p class="b1">&nbsp;*</p>*';
P_Tag[2598]='<p class="c3">&nbsp;*</p>*';
P_Tag[2599]='<p class="sc">&nbsp;*</p>*';
P_Tag[2600]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_201">[PTS.201]</span></p>*';
P_Tag[2601]='<p class="b1">&nbsp;*<span class="font10" id="M1207_347">[Pg.347]</span></p>*';
P_Tag[2602]='<p class="c3">&nbsp;*</p>*';
P_Tag[2603]='<p class="sc">&nbsp;*</p>*';
P_Tag[2604]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2605]='<p class="b1">&nbsp;*</p>*';
P_Tag[2606]='<p class="c3">&nbsp;*</p>*';
P_Tag[2607]='<p class="sc">&nbsp;*</p>*';
P_Tag[2608]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*<span class="font10" id="P1207_202">[PTS.202]</span></p>*';
P_Tag[2609]='<p class="b1">&nbsp;*<span class="font10" id="M1207_348">[Pg.348]</span></p>*';
P_Tag[2610]='<p class="c3">&nbsp;*</p>*';
P_Tag[2611]='<p class="sc">&nbsp;*</p>*';
P_Tag[2612]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2613]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2614]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2615]='<p class="b1">&nbsp;*<span class="font10" id="M1207_349">[Pg.349]</span><span class="font10" id="P1207_203">[PTS.203]</span><span class="bld">*</span>*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2616]='<p class="b1">&nbsp;*</p>*';
P_Tag[2617]='<p class="c3">&nbsp;*</p>*';
P_Tag[2618]='<p class="sc">&nbsp;*</p>*';
P_Tag[2619]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2620]='<p class="b1">&nbsp;*</p>*';
P_Tag[2621]='<p class="c3">&nbsp;*</p>*';
P_Tag[2622]='<p class="sc">&nbsp;*</p>*';
P_Tag[2623]='<p class="b1">&nbsp;*</p>*';
P_Tag[2624]='<p class="c3">&nbsp;*</p>*';
P_Tag[2625]='<p class="c3">&nbsp;*</p>*';
P_Tag[2626]='<p class="te">&nbsp;*</p>*';
P_Tag[2627]='<p class="sc">&nbsp;*</p>*';
P_Tag[2628]='<p class="b1">&nbsp;*<span class="font10" id="M1207_350">[Pg.350]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2629]='<p class="b1">&nbsp;*<span class="font10" id="P1207_204">[PTS.204]</span></p>*';
P_Tag[2630]='<p class="c3">&nbsp;*</p>*';
P_Tag[2631]='<p class="sc">&nbsp;*</p>*';
P_Tag[2632]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2633]='<p class="c3">&nbsp;*</p>*';
P_Tag[2634]='<p class="sc">&nbsp;*</p>*';
P_Tag[2635]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2636]='<p class="b1">&nbsp;*</p>*';
P_Tag[2637]='<p class="c3">&nbsp;*</p>*';
P_Tag[2638]='<p class="sc">&nbsp;*</p>*';
P_Tag[2639]='<p class="b1">&nbsp;*<span class="font10" id="M1207_351">[Pg.351]</span><span class="bld">*</span>*</p>*';
P_Tag[2640]='<p class="b1">&nbsp;*</p>*';
P_Tag[2641]='<p class="c3">&nbsp;*</p>*';
P_Tag[2642]='<p class="sc">&nbsp;*</p>*';
P_Tag[2643]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2644]='<p class="c3">&nbsp;*</p>*';
P_Tag[2645]='<p class="sc">&nbsp;*</p>*';
P_Tag[2646]='<p class="b1">&nbsp;*<span class="font10" id="P1207_205">[PTS.205]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2647]='<p class="c3">&nbsp;*</p>*';
P_Tag[2648]='<p class="sc">&nbsp;*</p>*';
P_Tag[2649]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2650]='<p class="b1">&nbsp;*<span class="font10" id="M1207_352">[Pg.352]</span></p>*';
P_Tag[2651]='<p class="c3">&nbsp;*</p>*';
P_Tag[2652]='<p class="sc">&nbsp;*</p>*';
P_Tag[2653]='<p class="b1">&nbsp;*</p>*';
P_Tag[2654]='<p class="c3">&nbsp;*</p>*';
P_Tag[2655]='<p class="sc">&nbsp;*</p>*';
P_Tag[2656]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2657]='<p class="b1">&nbsp;*</p>*';
P_Tag[2658]='<p class="c3">&nbsp;*</p>*';
P_Tag[2659]='<p class="sc">&nbsp;*</p>*';
P_Tag[2660]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="P1207_206">[PTS.206]</span></p>*';
P_Tag[2661]='<p class="b1">&nbsp;*<span class="font10" id="M1207_353">[Pg.353]</span></p>*';
P_Tag[2662]='<p class="c3">&nbsp;*</p>*';
P_Tag[2663]='<p class="sc">&nbsp;*</p>*';
P_Tag[2664]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2665]='<p class="b1">&nbsp;*</p>*';
P_Tag[2666]='<p class="c3">&nbsp;*</p>*';
P_Tag[2667]='<p class="c3">&nbsp;*</p>*';
P_Tag[2668]='<p class="te">&nbsp;*</p>*';
P_Tag[2669]='<p class="sc">&nbsp;*</p>*';
P_Tag[2670]='<p class="b1">&nbsp;*</p>*';
P_Tag[2671]='<p class="c3">&nbsp;*</p>*';
P_Tag[2672]='<p class="b1">&nbsp;*<span class="bld">*</span>*<span class="font10" id="M1207_354">[Pg.354]</span><span class="bld">*</span>*</p>*';
P_Tag[2673]='<p class="c3">&nbsp;*</p>*';
P_Tag[2674]='<p class="c3">&nbsp;*</p>*';
P_Tag[2675]='<p class="c3">&nbsp;*</p>*';
P_Tag[2676]='<p class="ia">&nbsp;*<span class="font10" id="P1207_207">[PTS.207]</span></p>*';
P_Tag[2677]='<p class="c4">&nbsp;*</p>*';
P_Tag[2678]='<p class="sc">&nbsp;*</p>*';
P_Tag[2679]='<p class="b1">&nbsp;*<span class="font10" id="M1207_355">[Pg.355]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2680]='<p class="b1">&nbsp;*</p>*';
P_Tag[2681]='<p class="c3">&nbsp;*</p>*';
P_Tag[2682]='<p class="sc">&nbsp;*</p>*';
P_Tag[2683]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2684]='<p class="c3">&nbsp;*</p>*';
P_Tag[2685]='<p class="c3">&nbsp;*</p>*';
P_Tag[2686]='<p class="c3">&nbsp;*</p>*';
P_Tag[2687]='<p class="c3">&nbsp;*</p>*';
P_Tag[2688]='<p class="sc">&nbsp;*</p>*';
P_Tag[2689]='<p class="b1">&nbsp;*<span class="font10" id="P1207_208">[PTS.208]</span><span class="font10" id="M1207_356">[Pg.356]</span></p>*';
P_Tag[2690]='<p class="c3">&nbsp;*</p>*';
P_Tag[2691]='<p class="c3">&nbsp;*</p>*';
P_Tag[2692]='<p class="sc">&nbsp;*</p>*';
P_Tag[2693]='<p class="b1">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2694]='<p class="g5">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2695]='<p class="g8">&nbsp;*</p>*';
P_Tag[2696]='<p class="g5">&nbsp;*</p>*';
P_Tag[2697]='<p class="g8">&nbsp;*</p>*';
P_Tag[2698]='<p class="g5">&nbsp;*</p>*';
P_Tag[2699]='<p class="g8">&nbsp;*</p>*';
P_Tag[2700]='<p class="g5">&nbsp;*</p>*';
P_Tag[2701]='<p class="g8">&nbsp;*</p>*';
P_Tag[2702]='<p class="g5">&nbsp;*</p>*';
P_Tag[2703]='<p class="g8">&nbsp;*<span class="bld">*</span>*</p>*';
P_Tag[2704]='<p class="g5">&nbsp;*</p>*';
P_Tag[2705]='<p class="g8">&nbsp;*</p>*';
P_Tag[2706]='<p class="g5">&nbsp;*</p>*';
P_Tag[2707]='<p class="g8">&nbsp;*</p>*';
P_Tag[2708]='<p class="b1">&nbsp;*<span class="font10" id="M1207_357">[Pg.357]</span><span class="bld">*</span>*<span class="bld">*</span>*</p>*';
P_Tag[2709]='<p class="g5">&nbsp;*</p>*';
P_Tag[2710]='<p class="g8">&nbsp;*</p>*';
P_Tag[2711]='<p class="g5">&nbsp;*</p>*';
P_Tag[2712]='<p class="g8">&nbsp;*</p>*';
P_Tag[2713]='<p class="c3">&nbsp;*</p>*';


P_Par[1]='p1046';
P_Par[2]='p1047';
P_Par[3]='p1049';
P_Par[4]='p1050';
P_Par[5]='p1052';
P_Par[6]='p1053';
P_Par[7]='p1055';
P_Par[8]='p1056';
P_Par[9]='p1058';
P_Par[10]='p1059';
P_Par[11]='p1062';
P_Par[12]='p1063';
P_Par[13]='p1065';
P_Par[14]='p1066';
P_Par[15]='p1068';
P_Par[16]='p1069';
P_Par[17]='p1071';
P_Par[18]='p1072';
P_Par[19]='p1074';
P_Par[20]='p1075';
P_Par[21]='p1078';
P_Par[22]='p1079';
P_Par[23]='p1081';
P_Par[24]='p1082';
P_Par[25]='p1084';
P_Par[26]='p1086';
P_Par[27]='p1088';
P_Par[28]='p1090';
P_Par[29]='p1092';
P_Par[30]='p1094';
P_Par[31]='p1097';
P_Par[32]='p1099';
P_Par[33]='p1101';
P_Par[34]='p1103';
P_Par[35]='p1105';
P_Par[36]='p1107';
P_Par[37]='p1109';
P_Par[38]='p1111';
P_Par[39]='p1113';
P_Par[40]='p1115';
P_Par[41]='p1118';
P_Par[42]='p1120';
P_Par[43]='p1122';
P_Par[44]='p1124';
P_Par[45]='p1126';
P_Par[46]='p1128';
P_Par[47]='p1130';
P_Par[48]='p1132';
P_Par[49]='p1134';
P_Par[50]='p1136';
P_Par[51]='p1139';
P_Par[52]='p1141';
P_Par[53]='p1143';
P_Par[54]='p1145';
P_Par[55]='p1147';
P_Par[56]='p1149';
P_Par[57]='p1151';
P_Par[58]='p1153';
P_Par[59]='p1155';
P_Par[60]='p1157';
P_Par[61]='p1160';
P_Par[62]='p1162';
P_Par[63]='p1164';
P_Par[64]='p1166';
P_Par[65]='p1168';
P_Par[66]='p1170';
P_Par[67]='p1172';
P_Par[68]='p1174';
P_Par[69]='p1176';
P_Par[70]='p1178';
P_Par[71]='p1180';
P_Par[72]='p1182';
P_Par[73]='p1184';
P_Par[74]='p1186';
P_Par[75]='p1188';
P_Par[76]='p830';
P_Par[77]='p832';
P_Par[78]='p834';
P_Par[79]='p836';
P_Par[80]='p838';
P_Par[81]='p840';
P_Par[82]='p842';
P_Par[83]='p844';
P_Par[84]='p847';
P_Par[85]='p849';
P_Par[86]='p851';
P_Par[87]='p853';
P_Par[88]='p855';
P_Par[89]='p857';
P_Par[90]='p859';
P_Par[91]='p861';
P_Par[92]='p863';
P_Par[93]='p865';
P_Par[94]='p867';
P_Par[95]='p869';
P_Par[96]='p871';
P_Par[97]='p874';
P_Par[98]='p876';
P_Par[99]='p878';
P_Par[100]='p880';
P_Par[101]='p882';
P_Par[102]='p884';
P_Par[103]='p886';
P_Par[104]='p888';
P_Par[105]='p890';
P_Par[106]='p892';
P_Par[107]='p895';
P_Par[108]='p897';
P_Par[109]='p899';
P_Par[110]='p901';
P_Par[111]='p903';
P_Par[112]='p905';
P_Par[113]='p907';
P_Par[114]='p909';
P_Par[115]='p911';
P_Par[116]='p913';
P_Par[117]='p916';
P_Par[118]='p918';
P_Par[119]='p920';
P_Par[120]='p922';
P_Par[121]='p924';
P_Par[122]='p926';
P_Par[123]='p928';
P_Par[124]='p930';
P_Par[125]='p932';
P_Par[126]='p934';
P_Par[127]='p937';
P_Par[128]='p939';
P_Par[129]='p941';
P_Par[130]='p943';
P_Par[131]='p945';
P_Par[132]='p947';
P_Par[133]='p949';
P_Par[134]='p951';
P_Par[135]='p953';
P_Par[136]='p955';
P_Par[137]='p958';
P_Par[138]='p960';
P_Par[139]='p962';
P_Par[140]='p964';
P_Par[141]='p966';
P_Par[142]='p968';
P_Par[143]='p970';
P_Par[144]='p972';
P_Par[145]='p974';
P_Par[146]='p976';
P_Par[147]='p979';
P_Par[148]='p981';
P_Par[149]='p983';
P_Par[150]='p985';
P_Par[151]='p987';
P_Par[152]='p989';
P_Par[153]='p991';
P_Par[154]='p993';
P_Par[155]='p995';
P_Par[156]='p997';
P_Par[157]='p1000';
P_Par[158]='p1002';
P_Par[159]='p1004';
P_Par[160]='p1006';
P_Par[161]='p1008';
P_Par[162]='p1010';
P_Par[163]='p1012';
P_Par[164]='p1014';
P_Par[165]='p1016';
P_Par[166]='p1018';


P_Toc[0]='p3';
P_Toc[1]='p15';
P_Toc[2]='p20';
P_Toc[3]='p32';
P_Toc[4]='p63';
P_Toc[5]='p72';
P_Toc[6]='p140';
P_Toc[7]='p338';
P_Toc[8]='p351';
P_Toc[9]='p500';
P_Toc[10]='p524';
P_Toc[11]='p536';
P_Toc[12]='p541';
P_Toc[13]='p561';
P_Toc[14]='p601';
P_Toc[15]='p669';
P_Toc[16]='p1022';
P_Toc[17]='p1043';
P_Toc[18]='p1192';
P_Toc[19]='p1215';
P_Toc[20]='p1229';
P_Toc[21]='p1297';
P_Toc[22]='p1299';
P_Toc[23]='p1342';
P_Toc[24]='p1355';
P_Toc[25]='p1364';
P_Toc[26]='p1371';
P_Toc[27]='p1373';
P_Toc[28]='p1377';
P_Toc[29]='p1381';
P_Toc[30]='p1385';
P_Toc[31]='p1389';
P_Toc[32]='p1395';
P_Toc[33]='p1399';
P_Toc[34]='p1403';
P_Toc[35]='p1407';
P_Toc[36]='p1410';
P_Toc[37]='p1414';
P_Toc[38]='p1418';
P_Toc[39]='p1422';
P_Toc[40]='p1426';
P_Toc[41]='p1435';
P_Toc[42]='p1436';
P_Toc[43]='p1440';
P_Toc[44]='p1446';
P_Toc[45]='p1448';
P_Toc[46]='p1449';
P_Toc[47]='p1457';
P_Toc[48]='p1462';
P_Toc[49]='p1475';
P_Toc[50]='p1479';
P_Toc[51]='p1483';
P_Toc[52]='p1487';
P_Toc[53]='p1492';
P_Toc[54]='p1496';
P_Toc[55]='p1499';
P_Toc[56]='p1507';
P_Toc[57]='p1508';
P_Toc[58]='p1512';
P_Toc[59]='p1515';
P_Toc[60]='p1519';
P_Toc[61]='p1523';
P_Toc[62]='p1527';
P_Toc[63]='p1531';
P_Toc[64]='p1534';
P_Toc[65]='p1538';
P_Toc[66]='p1542';
P_Toc[67]='p1547';
P_Toc[68]='p1548';
P_Toc[69]='p1552';
P_Toc[70]='p1557';
P_Toc[71]='p1561';
P_Toc[72]='p1566';
P_Toc[73]='p1570';
P_Toc[74]='p1574';
P_Toc[75]='p1578';
P_Toc[76]='p1582';
P_Toc[77]='p1587';
P_Toc[78]='p1594';
P_Toc[79]='p1595';
P_Toc[80]='p1596';
P_Toc[81]='p1600';
P_Toc[82]='p1604';
P_Toc[83]='p1608';
P_Toc[84]='p1612';
P_Toc[85]='p1616';
P_Toc[86]='p1620';
P_Toc[87]='p1624';
P_Toc[88]='p1628';
P_Toc[89]='p1632';
P_Toc[90]='p1637';
P_Toc[91]='p1638';
P_Toc[92]='p1643';
P_Toc[93]='p1647';
P_Toc[94]='p1651';
P_Toc[95]='p1656';
P_Toc[96]='p1660';
P_Toc[97]='p1664';
P_Toc[98]='p1669';
P_Toc[99]='p1673';
P_Toc[100]='p1678';
P_Toc[101]='p1683';
P_Toc[102]='p1684';
P_Toc[103]='p1688';
P_Toc[104]='p1692';
P_Toc[105]='p1696';
P_Toc[106]='p1700';
P_Toc[107]='p1703';
P_Toc[108]='p1707';
P_Toc[109]='p1711';
P_Toc[110]='p1715';
P_Toc[111]='p1719';
P_Toc[112]='p1723';
P_Toc[113]='p1724';
P_Toc[114]='p1728';
P_Toc[115]='p1732';
P_Toc[116]='p1736';
P_Toc[117]='p1740';
P_Toc[118]='p1750';
P_Toc[119]='p1754';
P_Toc[120]='p1758';
P_Toc[121]='p1763';
P_Toc[122]='p1767';
P_Toc[123]='p1774';
P_Toc[124]='p1775';
P_Toc[125]='p1779';
P_Toc[126]='p1783';
P_Toc[127]='p1787';
P_Toc[128]='p1790';
P_Toc[129]='p1794';
P_Toc[130]='p1798';
P_Toc[131]='p1802';
P_Toc[132]='p1806';
P_Toc[133]='p1810';
P_Toc[134]='p1811';
P_Toc[135]='p1815';
P_Toc[136]='p1819';
P_Toc[137]='p1823';
P_Toc[138]='p1827';
P_Toc[139]='p1831';
P_Toc[140]='p1835';
P_Toc[141]='p1839';
P_Toc[142]='p1843';
P_Toc[143]='p1848';
P_Toc[144]='p1853';
P_Toc[145]='p1854';
P_Toc[146]='p1858';
P_Toc[147]='p1862';
P_Toc[148]='p1866';
P_Toc[149]='p1870';
P_Toc[150]='p1874';
P_Toc[151]='p1878';
P_Toc[152]='p1881';
P_Toc[153]='p1885';
P_Toc[154]='p1889';
P_Toc[155]='p1894';
P_Toc[156]='p1895';
P_Toc[157]='p1899';
P_Toc[158]='p1903';
P_Toc[159]='p1907';
P_Toc[160]='p1911';
P_Toc[161]='p1914';
P_Toc[162]='p1918';
P_Toc[163]='p1922';
P_Toc[164]='p1926';
P_Toc[165]='p1935';
P_Toc[166]='p1939';
P_Toc[167]='p1958';
P_Toc[168]='p1962';
P_Toc[169]='p1963';
P_Toc[170]='p1967';
P_Toc[171]='p1972';
P_Toc[172]='p1976';
P_Toc[173]='p1980';
P_Toc[174]='p1984';
P_Toc[175]='p1988';
P_Toc[176]='p1992';
P_Toc[177]='p1996';
P_Toc[178]='p1999';
P_Toc[179]='p2005';
P_Toc[180]='p2006';
P_Toc[181]='p2010';
P_Toc[182]='p2014';
P_Toc[183]='p2018';
P_Toc[184]='p2024';
P_Toc[185]='p2025';
P_Toc[186]='p2032';
P_Toc[187]='p2034';
P_Toc[188]='p2037';
P_Toc[189]='p2039';
P_Toc[190]='p2041';
P_Toc[191]='p2044';
P_Toc[192]='p2047';
P_Toc[193]='p2049';
P_Toc[194]='p2051';
P_Toc[195]='p2053';
P_Toc[196]='p2055';
P_Toc[197]='p2057';
P_Toc[198]='p2060';
P_Toc[199]='p2062';
P_Toc[200]='p2064';
P_Toc[201]='p2066';
P_Toc[202]='p2068';
P_Toc[203]='p2070';
P_Toc[204]='p2072';
P_Toc[205]='p2074';
P_Toc[206]='p2076';
P_Toc[207]='p2078';
P_Toc[208]='p2080';
P_Toc[209]='p2082';
P_Toc[210]='p2084';
P_Toc[211]='p2086';
P_Toc[212]='p2088';
P_Toc[213]='p2090';
P_Toc[214]='p2092';
P_Toc[215]='p2094';
P_Toc[216]='p2096';
P_Toc[217]='p2098';
P_Toc[218]='p2100';
P_Toc[219]='p2102';
P_Toc[220]='p2104';
P_Toc[221]='p2107';
P_Toc[222]='p2109';
P_Toc[223]='p2111';
P_Toc[224]='p2113';
P_Toc[225]='p2115';
P_Toc[226]='p2117';
P_Toc[227]='p2119';
P_Toc[228]='p2121';
P_Toc[229]='p2123';
P_Toc[230]='p2125';
P_Toc[231]='p2127';
P_Toc[232]='p2129';
P_Toc[233]='p2131';
P_Toc[234]='p2133';
P_Toc[235]='p2135';
P_Toc[236]='p2137';
P_Toc[237]='p2139';
P_Toc[238]='p2145';
P_Toc[239]='p2160';
P_Toc[240]='p2161';
P_Toc[241]='p2164';
P_Toc[242]='p2165';
P_Toc[243]='p2167';
P_Toc[244]='p2168';
P_Toc[245]='p2173';
P_Toc[246]='p2177';
P_Toc[247]='p2181';
P_Toc[248]='p2189';
P_Toc[249]='p2190';
P_Toc[250]='p2195';
P_Toc[251]='p2199';
P_Toc[252]='p2211';
P_Toc[253]='p2215';
P_Toc[254]='p2219';
P_Toc[255]='p2223';
P_Toc[256]='p2226';
P_Toc[257]='p2229';
P_Toc[258]='p2232';
P_Toc[259]='p2236';
P_Toc[260]='p2240';
P_Toc[261]='p2252';
P_Toc[262]='p2253';
P_Toc[263]='p2257';
P_Toc[264]='p2261';
P_Toc[265]='p2265';
P_Toc[266]='p2269';
P_Toc[267]='p2272';
P_Toc[268]='p2276';
P_Toc[269]='p2279';
P_Toc[270]='p2282';
P_Toc[271]='p2285';
P_Toc[272]='p2290';
P_Toc[273]='p2294';
P_Toc[274]='p2302';
P_Toc[275]='p2303';
P_Toc[276]='p2304';
P_Toc[277]='p2308';
P_Toc[278]='p2312';
P_Toc[279]='p2316';
P_Toc[280]='p2320';
P_Toc[281]='p2324';
P_Toc[282]='p2328';
P_Toc[283]='p2332';
P_Toc[284]='p2336';
P_Toc[285]='p2340';
P_Toc[286]='p2345';
P_Toc[287]='p2346';
P_Toc[288]='p2350';
P_Toc[289]='p2353';
P_Toc[290]='p2356';
P_Toc[291]='p2360';
P_Toc[292]='p2364';
P_Toc[293]='p2368';
P_Toc[294]='p2372';
P_Toc[295]='p2376';
P_Toc[296]='p2380';
P_Toc[297]='p2385';
P_Toc[298]='p2386';
P_Toc[299]='p2390';
P_Toc[300]='p2393';
P_Toc[301]='p2397';
P_Toc[302]='p2401';
P_Toc[303]='p2405';
P_Toc[304]='p2409';
P_Toc[305]='p2413';
P_Toc[306]='p2417';
P_Toc[307]='p2421';
P_Toc[308]='p2426';
P_Toc[309]='p2427';
P_Toc[310]='p2431';
P_Toc[311]='p2435';
P_Toc[312]='p2439';
P_Toc[313]='p2443';
P_Toc[314]='p2447';
P_Toc[315]='p2450';
P_Toc[316]='p2454';
P_Toc[317]='p2457';
P_Toc[318]='p2460';
P_Toc[319]='p2465';
P_Toc[320]='p2466';
P_Toc[321]='p2470';
P_Toc[322]='p2474';
P_Toc[323]='p2478';
P_Toc[324]='p2482';
P_Toc[325]='p2486';
P_Toc[326]='p2490';
P_Toc[327]='p2494';
P_Toc[328]='p2498';
P_Toc[329]='p2501';
P_Toc[330]='p2505';
P_Toc[331]='p2506';
P_Toc[332]='p2510';
P_Toc[333]='p2514';
P_Toc[334]='p2518';
P_Toc[335]='p2522';
P_Toc[336]='p2526';
P_Toc[337]='p2530';
P_Toc[338]='p2538';
P_Toc[339]='p2542';
P_Toc[340]='p2546';
P_Toc[341]='p2551';
P_Toc[342]='p2552';
P_Toc[343]='p2556';
P_Toc[344]='p2559';
P_Toc[345]='p2563';
P_Toc[346]='p2566';
P_Toc[347]='p2569';
P_Toc[348]='p2572';
P_Toc[349]='p2576';
P_Toc[350]='p2580';
P_Toc[351]='p2585';
P_Toc[352]='p2586';
P_Toc[353]='p2589';
P_Toc[354]='p2592';
P_Toc[355]='p2595';
P_Toc[356]='p2599';
P_Toc[357]='p2603';
P_Toc[358]='p2607';
P_Toc[359]='p2611';
P_Toc[360]='p2618';
P_Toc[361]='p2622';
P_Toc[362]='p2626';
P_Toc[363]='p2627';
P_Toc[364]='p2631';
P_Toc[365]='p2634';
P_Toc[366]='p2638';
P_Toc[367]='p2642';
P_Toc[368]='p2645';
P_Toc[369]='p2648';
P_Toc[370]='p2652';
P_Toc[371]='p2655';
P_Toc[372]='p2659';
P_Toc[373]='p2663';
P_Toc[374]='p2668';
P_Toc[375]='p2669';
P_Toc[376]='p2677';
P_Toc[377]='p2678';
P_Toc[378]='p2682';
P_Toc[379]='p2688';
P_Toc[380]='p2692';


var TOC_Dropdown_Items = [
	'Bhikkhupātimokkhapāḷi',
	'____Nidānuddeso',
	'____Pārājikuddeso',
	'____Saṅghādisesuddeso',
	'____Aniyatuddeso',
	'____Nissaggiyapācittiyā',
	'____Suddhapācittiyā',
	'____Pāṭidesanīyā',
	'____Sekhiyā',
	'____Adhikaraṇasamathā',
	'Bhikkhunīpātimokkhapāḷi',
	'____Nidānuddeso',
	'____Pārājikuddeso',
	'____Saṅghādisesuddeso',
	'____Nissaggiya pācittiyā',
	'____Suddhapācittiyā',
	'____Pāṭidesanīyā',
	'____Sekhiyā',
	'____Adhikaraṇasamathā',
	'Kaṅkhāvitaraṇī-aṭṭhakathā',
	'Nidānavaṇṇanā',
	'Pārājikakaṇḍo',
	'____1. Paṭhamapārājikavaṇṇanā',
	'____2. Dutiyapārājikavaṇṇanā',
	'____3. Tatiyapārājikavaṇṇanā',
	'____4. Catutthapārājikavaṇṇanā',
	'Saṅghādisesakaṇḍo',
	'____1. Sukkavissaṭṭhisikkhāpadavaṇṇanā',
	'____2. Kāyasaṃsaggasikkhāpadavaṇṇanā',
	'____3. Duṭṭhullavācāsikkhāpadavaṇṇanā',
	'____4. Attakāmasikkhāpadavaṇṇanā',
	'____5. Sañcarittasikkhāpadavaṇṇanā',
	'____6. Kuṭikārasikkhāpadavaṇṇanā',
	'____7. Vihārakārasikkhāpadavaṇṇanā',
	'____8. Duṭṭhadosasikkhāpadavaṇṇanā',
	'____9. Aññabhāgiyasikkhāpadavaṇṇanā',
	'____10. Saṅghabhedasikkhāpadavaṇṇanā',
	'____11. Bhedānuvattakasikkhāpadavaṇṇanā',
	'____12. Dubbacasikkhāpadavaṇṇanā',
	'____13. Kuladūsakasikkhāpadavaṇṇanā',
	'____Nigamanavaṇṇanā',
	'Aniyatakaṇḍo',
	'____1. Paṭhamāniyatasikkhāpadavaṇṇanā',
	'____2. Dutiyāniyatasikkhāpadavaṇṇanā',
	'Nissaggiyakaṇḍo',
	'__1. Cīvaravaggo',
	'____1. Kathinasikkhāpadavaṇṇanā',
	'____2. Udositasikkhāpadavaṇṇanā',
	'____3. Akālacīvarasikkhāpadavaṇṇanā',
	'____4. Purāṇacīvarasikkhāpadavaṇṇanā',
	'____5. Cīvarappaṭiggahaṇasikkhāpadavaṇṇanā',
	'____6. Aññātakaviññattisikkhāpadavaṇṇanā',
	'____7. Tatuttarisikkhāpadavaṇṇanā',
	'____8. Upakkhaṭasikkhāpadavaṇṇanā',
	'____9. Dutiyaupakkhaṭasikkhāpadavaṇṇanā',
	'____10. Rājasikkhāpadavaṇṇanā',
	'__2. Eḷakalomavaggo',
	'____1. Kosiyasikkhāpadavaṇṇanā',
	'____2. Suddhakāḷakasikkhāpadavaṇṇanā',
	'____3. Dvebhāgasikkhāpadavaṇṇanā',
	'____4. Chabbassasikkhāpadavaṇṇanā',
	'____5. Nisīdanasikkhāpadavaṇṇanā',
	'____6. Eḷakalomasikkhāpadavaṇṇanā',
	'____7. Eḷakalomadhovāpanasikkhāpadavaṇṇanā',
	'____8. Jātarūpasikkhāpadavaṇṇanā',
	'____9. Rūpiyasaṃvohārasikkhāpadavaṇṇanā',
	'____10. Kayavikkayasikkhāpadavaṇṇanā',
	'__3. Pattavaggo',
	'____1. Pattasikkhāpadavaṇṇanā',
	'____2. Ūnapañcabandhanasikkhāpadavaṇṇanā',
	'____3. Bhesajjasikkhāpadavaṇṇanā',
	'____4. Vassikasāṭikasikkhāpadavaṇṇanā',
	'____5. Cīvaraacchindanasikkhāpadavaṇṇanā',
	'____6. Suttaviññattisikkhāpadavaṇṇanā',
	'____7. Mahāpesakārasikkhāpadavaṇṇanā',
	'____8. Accekacīvarasikkhāpadavaṇṇanā',
	'____9. Sāsaṅkasikkhāpadavaṇṇanā',
	'____10. Pariṇatasikkhāpadavaṇṇanā',
	'Pācittiyakaṇḍo',
	'__1. Musāvādavaggo',
	'____1. Musāvādasikkhāpadavaṇṇanā',
	'____2. Omasavādasikkhāpadavaṇṇanā',
	'____3. Pesuññasikkhāpadavaṇṇanā',
	'____4. Padasodhammasikkhāpadavaṇṇanā',
	'____5. Paṭhamasahaseyyasikkhāpadavaṇṇanā',
	'____6. Dutiyasahaseyyasikkhāpadavaṇṇanā',
	'____7. Dhammadesanāsikkhāpadavaṇṇanā',
	'____8. Bhūtārocanasikkhāpadavaṇṇanā',
	'____9. Duṭṭhullārocanasikkhāpadavaṇṇanā',
	'____10. Pathavīkhaṇanasikkhāpadavaṇṇanā',
	'__2. Bhūtagāmavaggo',
	'____1. Bhūtagāmasikkhāpadavaṇṇanā',
	'____2. Aññavādakasikkhāpadavaṇṇanā',
	'____3. Ujjhāpanakasikkhāpadavaṇṇanā',
	'____4. Paṭhamasenāsanasikkhāpadavaṇṇanā',
	'____5. Dutiyasenāsanasikkhāpadavaṇṇanā',
	'____6. Anupakhajjasikkhāpadavaṇṇanā',
	'____7. Nikkaḍḍhanasikkhāpadavaṇṇanā',
	'____8. Vehāsakuṭisikkhāpadavaṇṇanā',
	'____9. Mahallakavihārasikkhāpadavaṇṇanā',
	'____10. Sappāṇakasikkhāpadavaṇṇanā',
	'__3. Ovādavaggo',
	'____1. Ovādasikkhāpadavaṇṇanā',
	'____2. Atthaṅgatasikkhāpadavaṇṇanā',
	'____3. Bhikkhunupassayasikkhāpadavaṇṇanā',
	'____4. Āmisasikkhāpadavaṇṇanā',
	'____5. Cīvaradānasikkhāpadavaṇṇanā',
	'____6. Cīvarasibbanasikkhāpadavaṇṇanā',
	'____7. Saṃvidhānasikkhāpadavaṇṇanā',
	'____8. Nāvābhiruhanasikkhāpadavaṇṇanā',
	'____9. Paripācitasikkhāpadavaṇṇanā',
	'____10. Rahonisajjasikkhāpadavaṇṇanā',
	'__4. Bhojanavaggo',
	'____1. Āvasathasikkhāpadavaṇṇanā',
	'____2. Gaṇabhojanasikkhāpadavaṇṇanā',
	'____3. Paramparabhojanasikkhāpadavaṇṇanā',
	'____4. Kāṇamātāsikkhāpadavaṇṇanā',
	'____5. Paṭhamapavāraṇāsikkhāpadavaṇṇanā',
	'____6. Dutiyapavāraṇāsikkhāpadavaṇṇanā',
	'____7. Vikālabhojanasikkhāpadavaṇṇanā',
	'____8. Sannidhikārakasikkhāpadavaṇṇanā',
	'____9. Paṇītabhojanasikkhāpadavaṇṇanā',
	'____10. Dantaponasikkhāpadavaṇṇanā',
	'__5. Acelakavaggo',
	'____1. Acelakasikkhāpadavaṇṇanā',
	'____2. Uyyojanasikkhāpadavaṇṇanā',
	'____3. Sabhojanasikkhāpadavaṇṇanā',
	'____4-5. Rahopaṭicchanna-rahonisajjasikkhāpadavaṇṇanā',
	'____6. Cārittasikkhāpadavaṇṇanā',
	'____7. Mahānāmasikkhāpadavaṇṇanā',
	'____8. Uyyuttasenāsikkhāpadavaṇṇanā',
	'____9. Senāvāsasikkhāpadavaṇṇanā',
	'____10. Uyyodhikasikkhāpadavaṇṇanā',
	'__6. Surāpānavaggo',
	'____1. Surāpānasikkhāpadavaṇṇanā',
	'____2. Aṅgulipatodakasikkhāpadavaṇṇanā',
	'____3. Hasadhammasikkhāpadavaṇṇanā',
	'____4. Anādariyasikkhāpadavaṇṇanā',
	'____5. Bhiṃsāpanasikkhāpadavaṇṇanā',
	'____6. Jotisikkhāpadavaṇṇanā',
	'____7. Nahānasikkhāpadavaṇṇanā',
	'____8. Dubbaṇṇakaraṇasikkhāpadavaṇṇanā',
	'____9. Vikappanasikkhāpadavaṇṇanā',
	'____10. Apanidhānasikkhāpadavaṇṇanā',
	'__7. Sappāṇakavaggo',
	'____1. Sañciccasikkhāpadavaṇṇanā',
	'____2. Sappāṇakasikkhāpadavaṇṇanā',
	'____3. Ukkoṭanasikkhāpadavaṇṇanā',
	'____4. Duṭṭhullasikkhāpadavaṇṇanā',
	'____5. Ūnavīsativassasikkhāpadavaṇṇanā',
	'____6. Theyyasatthasikkhāpadavaṇṇanā',
	'____7. Saṃvidhānasikkhāpadavaṇṇanā',
	'____8. Ariṭṭhasikkhāpadavaṇṇanā',
	'____9. Ukkhittasambhogasikkhāpadavaṇṇanā',
	'____10. Kaṇṭakasikkhāpadavaṇṇanā',
	'__8. Sahadhammikavaggo',
	'____1. Sahadhammikasikkhāpadavaṇṇanā',
	'____2. Vilekhanasikkhāpadavaṇṇanā',
	'____3. Mohanasikkhāpadavaṇṇanā',
	'____4. Pahārasikkhāpadavaṇṇanā',
	'____5. Talasattikasikkhāpadavaṇṇanā',
	'____6. Amūlakasikkhāpadavaṇṇanā',
	'____7. Sañciccasikkhāpadavaṇṇanā',
	'____8. Upassutisikkhāpadavaṇṇanā',
	'____9. Kammappaṭibāhanasikkhāpadavaṇṇanā',
	'____10. Chandaṃadatvāgamanasikkhāpadavaṇṇanā',
	'____11. Dubbalasikkhāpadavaṇṇanā',
	'____12. Pariṇāmanasikkhāpadavaṇṇanā',
	'__9. Ratanavaggo',
	'____1. Antepurasikkhāpadavaṇṇanā',
	'____2. Ratanasikkhāpadavaṇṇanā',
	'____3. Vikālagāmappavesanasikkhāpadavaṇṇanā',
	'____4. Sūcigharasikkhāpadavaṇṇanā',
	'____5. Mañcapīṭhasikkhāpadavaṇṇanā',
	'____6. Tūlonaddhasikkhāpadavaṇṇanā',
	'____7. Nisīdanasikkhāpadavaṇṇanā',
	'____8. Kaṇḍuppaṭicchādisikkhāpadavaṇṇanā',
	'____9. Vassikasāṭikasikkhāpadavaṇṇanā',
	'____10. Nandasikkhāpadavaṇṇanā',
	'Pāṭidesanīyakaṇḍo',
	'____1. Paṭhamapāṭidesanīyasikkhāpadavaṇṇanā',
	'____2. Dutiyapāṭidesanīyasikkhāpadavaṇṇanā',
	'____3. Tatiyapāṭidesanīyasikkhāpadavaṇṇanā',
	'____4. Catutthapāṭidesanīyasikkhāpadavaṇṇanā',
	'Sekhiyakaṇḍo',
	'____1. Parimaṇḍalasikkhāpadavaṇṇanā',
	'____2. Dutiyaparimaṇḍalasikkhāpadavaṇṇanā',
	'____3-4. Suppaṭicchannasikkhāpadavaṇṇanā',
	'____5-6. Susaṃvutasikkhāpadavaṇṇanā',
	'____7-8. Okkhittacakkhusikkhāpadavaṇṇanā',
	'____9-10. Ukkhittakasikkhāpadavaṇṇanā',
	'____11-12. Ujjagghikasikkhāpadavaṇṇanā',
	'____13-14. Uccasaddasikkhāpadavaṇṇanā',
	'____15…Pe…20. kāyappacālakādisikkhāpadavaṇṇanā',
	'____21-22. Khambhakatasikkhāpadavaṇṇanā',
	'____23-24. Oguṇṭhitasikkhāpadavaṇṇanā',
	'____25. Ukkuṭikasikkhāpadavaṇṇanā',
	'____26. Pallatthikasikkhāpadavaṇṇanā',
	'____27. Sakkaccapaṭiggahaṇasikkhāpadavaṇṇanā',
	'____28. Pattasaññīpaṭiggahaṇasikkhāpadavaṇṇanā',
	'____29. Samasūpakapaṭiggahaṇasikkhāpadavaṇṇanā',
	'____30…Pe…32. samatittikasikkhāpadavaṇṇanā',
	'____33-34. Sapadānasikkhāpadavaṇṇanā',
	'____35. Thūpakatasikkhāpadavaṇṇanā',
	'____36. Odanappaṭicchādanasikkhāpadavaṇṇanā',
	'____37. Sūpodanaviññattisikkhāpadavaṇṇanā',
	'____38. Ujjhānasaññīsikkhāpadavaṇṇanā',
	'____39. Kabaḷasikkhāpadavaṇṇanā',
	'____40. Ālopasikkhāpadavaṇṇanā',
	'____41-42. Anāhaṭasikkhāpadavaṇṇanā',
	'____43. Sakabaḷasikkhāpadavaṇṇanā',
	'____44. Piṇḍukkhepakasikkhāpadavaṇṇanā',
	'____45. Kabaḷāvacchedakasikkhāpadavaṇṇanā',
	'____46. Avagaṇḍakārakasikkhāpadavaṇṇanā',
	'____47. Hatthaniddhunakasikkhāpadavaṇṇanā',
	'____48. Sitthāvakārakasikkhāpadavaṇṇanā',
	'____49. Jivhānicchārakasikkhāpadavaṇṇanā',
	'____50-51. Capucapukārakasikkhāpadavaṇṇanā',
	'____52…Pe…54. hatthanillehakādisikkhāpadavaṇṇanā',
	'____55. Sāmisasikkhāpadavaṇṇanā',
	'____56. Sasitthakasikkhāpadavaṇṇanā',
	'____57. Chattapāṇisikkhāpadavaṇṇanā',
	'____58-59. Daṇḍapāṇisikkhāpadavaṇṇanā',
	'____60. Āvudhapāṇisikkhāpadavaṇṇanā',
	'____61-62. Pādukasikkhāpadavaṇṇanā',
	'____63. Yānasikkhāpadavaṇṇanā',
	'____64. Sayanasikkhāpadavaṇṇanā',
	'____65. Pallatthikasikkhāpadavaṇṇanā',
	'____66. Veṭhitasikkhāpadavaṇṇanā',
	'____67. Oguṇṭhitasikkhāpadavaṇṇanā',
	'____68. Chamāsikkhāpadavaṇṇanā',
	'____69. Nīcāsanasikkhāpadavaṇṇanā',
	'____70. Ṭhitasikkhāpadavaṇṇanā',
	'____71. Pacchatogamanasikkhāpadavaṇṇanā',
	'____72. Uppathenagamanasikkhāpadavaṇṇanā',
	'____73. Ṭhitouccārasikkhāpadavaṇṇanā',
	'____74. Hariteuccārasikkhāpadavaṇṇanā',
	'____75. Udakeuccārasikkhāpadavaṇṇanā',
	'____Adhikaraṇasamathavaṇṇanā',
	'Bhikkhunīpātimokkhavaṇṇanā',
	'Pārājikakaṇḍo',
	'__Sādhāraṇapārājikaṃ',
	'____1…Pe…4. methunadhammasikkhāpadavaṇṇanā',
	'__Asādhāraṇapārājikaṃ',
	'____5. Ubbhajāṇumaṇḍalikāsikkhāpadavaṇṇanā',
	'____6. Vajjappaṭicchādikāsikkhāpadavaṇṇanā',
	'____7. Ukkhittānuvattikāsikkhāpadavaṇṇanā',
	'____8. Aṭṭhavatthukāsikkhāpadavaṇṇanā',
	'Saṅghādisesakaṇḍo',
	'____1. Ussayavādikāsikkhāpadavaṇṇanā',
	'____2. Corivuṭṭhāpikāsikkhāpadavaṇṇanā',
	'____3. Ekagāmantaragamanasikkhāpadavaṇṇanā',
	'____4. Ukkhittakaosāraṇasikkhāpadavaṇṇanā',
	'____5. Bhojanappaṭiggahaṇapaṭhamasikkhāpadavaṇṇanā',
	'____6. Bhojanappaṭiggahaṇadutiyasikkhāpadavaṇṇanā',
	'____7-8-9. Sañcarittādisikkhāpadavaṇṇanā',
	'____10. Sikkhaṃpaccācikkhaṇasikkhāpadavaṇṇanā',
	'____11. Adhikaraṇakupitasikkhāpadavaṇṇanā',
	'____12. Pāpasamācārapaṭhamasikkhāpadavaṇṇanā',
	'____13. Pāpasamācāradutiyasikkhāpadavaṇṇanā',
	'____14. Saṅghabhedakādisikkhāpadavaṇṇanā',
	'Nissaggiyakaṇḍo',
	'____1. Pattasannicayasikkhāpadavaṇṇanā',
	'____2. Akālacīvarasikkhāpadavaṇṇanā',
	'____3. Cīvaraparivattanasikkhāpadavaṇṇanā',
	'____4. Aññaviññāpanasikkhāpadavaṇṇanā',
	'____5. Aññacetāpanasikkhāpadavaṇṇanā',
	'____6. Paṭhamasaṅghikacetāpanasikkhāpadavaṇṇanā',
	'____7. Dutiyasaṅghikacetāpanasikkhāpadavaṇṇanā',
	'____8. Paṭhamagaṇikacetāpanasikkhāpadavaṇṇanā',
	'____9. Dutiyagaṇikacetāpanasikkhāpadavaṇṇanā',
	'____10. Puggalikacetāpanasikkhāpadavaṇṇanā',
	'____11. Garupāvuraṇasikkhāpadavaṇṇanā',
	'____12. Lahupāvuraṇasikkhāpadavaṇṇanā',
	'Pācittiyakaṇḍo',
	'__1. Lasuṇavaggo',
	'____1. Lasuṇasikkhāpadavaṇṇanā',
	'____2. Sambādhalomasikkhāpadavaṇṇanā',
	'____3. Talaghātakasikkhāpadavaṇṇanā',
	'____4. Jatumaṭṭhakasikkhāpadavaṇṇanā',
	'____5. Udakasuddhikasikkhāpadavaṇṇanā',
	'____6. Upatiṭṭhanasikkhāpadavaṇṇanā',
	'____7. Āmakadhaññasikkhāpadavaṇṇanā',
	'____8. Paṭhamauccārachaḍḍanasikkhāpadavaṇṇanā',
	'____9. Dutiyauccārachaḍḍanasikkhāpadavaṇṇanā',
	'____10. Naccagītasikkhāpadavaṇṇanā',
	'__2. Rattandhakāravaggo',
	'____1. Rattandhakārasikkhāpadavaṇṇanā',
	'____2. Paṭicchannokāsasikkhāpadavaṇṇanā',
	'____3. Ajjhokāsasallapanasikkhāpadavaṇṇanā',
	'____4. Dutiyikauyyojanasikkhāpadavaṇṇanā',
	'____5. Anāpucchāpakkamanasikkhāpadavaṇṇanā',
	'____6. Anāpucchāabhinisīdanasikkhāpadavaṇṇanā',
	'____7. Anāpucchāsantharaṇasikkhāpadavaṇṇanā',
	'____8. Paraujjhāpanakasikkhāpadavaṇṇanā',
	'____9. Paraabhisapanasikkhāpadavaṇṇanā',
	'____10. Rodanasikkhāpadavaṇṇanā',
	'__3. Naggavaggo',
	'____1. Naggasikkhāpadavaṇṇanā',
	'____2. Udakasāṭikasikkhāpadavaṇṇanā',
	'____3. Cīvarasibbanasikkhāpadavaṇṇanā',
	'____4. Saṅghāṭicārasikkhāpadavaṇṇanā',
	'____5. Cīvarasaṅkamanīyasikkhāpadavaṇṇanā',
	'____6. Gaṇacīvarasikkhāpadavaṇṇanā',
	'____7. Paṭibāhanasikkhāpadavaṇṇanā',
	'____8. Cīvaradānasikkhāpadavaṇṇanā',
	'____9. Kālaatikkamanasikkhāpadavaṇṇanā',
	'____10. Kathinuddhārasikkhāpadavaṇṇanā',
	'__4. Tuvaṭṭavaggo',
	'____1. Ekamañcatuvaṭṭanasikkhāpadavaṇṇanā',
	'____2. Ekattharaṇatuvaṭṭanasikkhāpadavaṇṇanā',
	'____3. Aphāsukaraṇasikkhāpadavaṇṇanā',
	'____4. Naupaṭṭhāpanasikkhāpadavaṇṇanā',
	'____5. Nikkaḍḍhanasikkhāpadavaṇṇanā',
	'____6. Saṃsaṭṭhasikkhāpadavaṇṇanā',
	'____7. Antoraṭṭhasikkhāpadavaṇṇanā',
	'____8. Tiroraṭṭhasikkhāpadavaṇṇanā',
	'____9. Antovassasikkhāpadavaṇṇanā',
	'____10. Cārikanapakkamanasikkhāpadavaṇṇanā',
	'__5. Cittāgāravaggo',
	'____1. Rājāgārasikkhāpadavaṇṇanā',
	'____2. Āsandiparibhuñjanasikkhāpadavaṇṇanā',
	'____3. Suttakantanasikkhāpadavaṇṇanā',
	'____4. Gihiveyyāvaccasikkhāpadavaṇṇanā',
	'____5. Adhikaraṇasikkhāpadavaṇṇanā',
	'____6. Bhojanadānasikkhāpadavaṇṇanā',
	'____7. Āvasathacīvarasikkhāpadavaṇṇanā',
	'____8. Āvasathavihārasikkhāpadavaṇṇanā',
	'____9. Tiracchānavijjāpariyāpuṇanasikkhāpadavaṇṇanā',
	'____10. Tiracchānavijjāvācanasikkhāpadavaṇṇanā',
	'__6. Ārāmavaggo',
	'____1. Ārāmapavisanasikkhāpadavaṇṇanā',
	'____2. Bhikkhuakkosanasikkhāpadavaṇṇanā',
	'____3. Gaṇaparibhāsanasikkhāpadavaṇṇanā',
	'____4. Pavāritasikkhāpadavaṇṇanā',
	'____5. Kulamaccharinīsikkhāpadavaṇṇanā',
	'____6. Abhikkhukāvāsasikkhāpadavaṇṇanā',
	'____7. Apavāraṇāsikkhāpadavaṇṇanā',
	'____8. Ovādasikkhāpadavaṇṇanā',
	'____9. Ovādūpasaṅkamanasikkhāpadavaṇṇanā',
	'____10. Pasākhejātasikkhāpadavaṇṇanā',
	'__7. Gabbhinīvaggo',
	'____1. Gabbhinīsikkhāpadavaṇṇanā',
	'____2. Pāyantīsikkhāpadavaṇṇanā',
	'____3. Paṭhamasikkhamānasikkhāpadavaṇṇanā',
	'____4. Dutiyasikkhamānasikkhāpadavaṇṇanā',
	'____5. Paṭhamagihigatasikkhāpadavaṇṇanā',
	'____6-7. Dutiyatatiyagihigatasikkhāpadavaṇṇanā',
	'____8. Paṭhamasahajīvinisikkhāpadavaṇṇanā',
	'____9. Nānubandhanasikkhāpadavaṇṇanā',
	'____10. Dutiyasahajīvinisikkhāpadavaṇṇanā',
	'__8. Kumāribhūtavaggo',
	'____1-2-3. Paṭhamakumāribhūtādisikkhāpadavaṇṇanā',
	'____4. Ūnadvādasavassasikkhāpadavaṇṇanā',
	'____5. Paripuṇṇadvādasavassasikkhāpadavaṇṇanā',
	'____6. Khīyanadhammasikkhāpadavaṇṇanā',
	'____7-8. Sikkhamānanavuṭṭhāpanapaṭhamadutiyasikkhāpadavaṇṇanā',
	'____9. Sokāvāsasikkhāpadavaṇṇanā',
	'____10. Ananuññātasikkhāpadavaṇṇanā',
	'____11. Pārivāsikasikkhāpadavaṇṇanā',
	'____12. Anuvassasikkhāpadavaṇṇanā',
	'____13. Ekavassasikkhāpadavaṇṇanā',
	'__9. Chattupāhanavaggo',
	'____1. Chattupāhanasikkhāpadavaṇṇanā',
	'____2. Yānasikkhāpadavaṇṇanā',
	'____3. Saṅghāṇisikkhāpadavaṇṇanā',
	'____4. Itthālaṅkārasikkhāpadavaṇṇanā',
	'____5. Gandhavaṇṇakasikkhāpadavaṇṇanā',
	'____6. Vāsitakasikkhāpadavaṇṇanā',
	'____7. Bhikkhuniummaddāpanasikkhāpadavaṇṇanā',
	'____8-9-10. Sikkhamānaummaddāpanādisikkhāpadavaṇṇanā',
	'____11. Anāpucchāsikkhāpadavaṇṇanā',
	'____12. Pañhāpucchanasikkhāpadavaṇṇanā',
	'____13. Asaṃkaccikasikkhāpadavaṇṇanā',
	'__10…Pe…16. musāvādādivaggo',
	'____Musāvādādisikkhāpadavaṇṇanā',
	'Pāṭidesanīyakaṇḍo',
	'____1. Sappiviññāpanasikkhāpadavaṇṇanā',
	'____2. Telaviññāpanādisikkhāpadavaṇṇanā',
	'____1. Parimaṇḍalādisikkhāpadavaṇṇanā',
	'____Nigamanakathā',
];

SetupToc();
